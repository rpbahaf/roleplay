import "dotenv/config";
import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || "",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  function sanitizeDialogueFormatting(text: string): string {
    if (!text) return text;
    
    // Remove lines that look like numbered choices (e.g., "1. *something*", "2. *something*", "1) *something*", etc.)
    let cleanedText = text.replace(/^\s*\d+[\s.)-]+\s*\*([^*]+)\*\s*$/gm, '');
    cleanedText = cleanedText.replace(/^\s*\d+[\s.)-]+\s*"([^"]+)"\s*$/gm, '');
    cleanedText = cleanedText.replace(/^\s*\d+[\s.)-]+\s*.*$/gm, (match) => {
      const lower = match.toLowerCase();
      if (/^\s*\d+[\s.)-]+\s*/.test(match) && (match.includes('*') || match.includes('"') || lower.includes('pilihan') || lower.includes('tindakan') || lower.includes('opsi'))) {
        return '';
      }
      return match;
    });

    // Also strip generic headers like "Rekomendasi Tindakan:" or "Pilihan Anda:" or similar
    cleanedText = cleanedText.replace(/^\s*(?:Rekomendasi Tindakan|Pilihan|Opsi|Daftar Tindakan|Saran Aksi)\s*:\s*$/gmi, '');

    return cleanedText.split('\n').map(line => {
      let trimmed = line.trim();
      if (!trimmed) return line;

      // Clean up common duplicate punctuation artifacts like *.* or .*.
      trimmed = trimmed.replace(/\*\.\*/g, '*').replace(/\.\*\.\*/g, '.*');

      // Pattern 1: Starts with * and ends with * and contains double quotes, and only has 2 asterisks in total
      if (trimmed.startsWith('*') && trimmed.endsWith('*') && (trimmed.match(/\*/g) || []).length === 2 && trimmed.includes('"')) {
        const firstQuoteIdx = trimmed.indexOf('"');
        const lastQuoteIdx = trimmed.lastIndexOf('"');
        if (firstQuoteIdx > 1 && lastQuoteIdx > firstQuoteIdx) {
          const actionPart = trimmed.substring(1, firstQuoteIdx).trim();
          const dialoguePart = trimmed.substring(firstQuoteIdx + 1, lastQuoteIdx).trim();
          let cleanedAction = actionPart;
          cleanedAction = cleanedAction.replace(/\*+$/, '').trim();
          if (cleanedAction.endsWith(',') || cleanedAction.endsWith('.')) {
            cleanedAction = cleanedAction.slice(0, -1).trim();
          }
          cleanedAction = cleanedAction.replace(/\*+$/, '').trim();
          return `*${cleanedAction}.* "${dialoguePart}"`;
        }
      }

      // Pattern 2: Global regex replacement of any nested patterns
      // e.g. *Action, "Dialogue"* or *Action "Dialogue"*
      trimmed = trimmed.replace(/\*([^*"]+?)(?:,\s*|\.\s*|\s*)"([^"]+?)"(?:,\s*|\.\s*|\s*)\*/g, (match, action, dialogue) => {
        let cleanAction = action.trim().replace(/\*+$/, '').trim();
        if (cleanAction.endsWith(',') || cleanAction.endsWith('.')) {
          cleanAction = cleanAction.slice(0, -1).trim();
        }
        cleanAction = cleanAction.replace(/\*+$/, '').trim();
        return `*${cleanAction}.* "${dialogue.trim()}"`;
      });

      // Pattern 3: *Action, "Dialogue"
      trimmed = trimmed.replace(/\*([^*"]+?)(?:,\s*|\.\s*|\s*)"([^"]+?)"/g, (match, action, dialogue) => {
        let cleanAction = action.trim().replace(/\*+$/, '').trim();
        if (cleanAction.endsWith(',') || cleanAction.endsWith('.')) {
          cleanAction = cleanAction.slice(0, -1).trim();
        }
        cleanAction = cleanAction.replace(/\*+$/, '').trim();
        return `*${cleanAction}.* "${dialogue.trim()}"`;
      });

      // Ensure spaces between asterisk and quotes: e.g. `*"Dialogue"` or `"*` or similar
      trimmed = trimmed.replace(/\*(\s*)"/g, '* "');
      trimmed = trimmed.replace(/"(\s*)\*/g, '" *');

      // Final cleanup of any trailing `.*` right after `*`
      trimmed = trimmed.replace(/\*\.\*/g, '*');

      return trimmed;
    }).join('\n');
  }

  // Robust wrapper with automatic exponential backoff retry mechanism and smart model fallback
  async function generateContentWithRetry(model: string, contents: any, config: any, retries = 2, delay = 800): Promise<any> {
    // List of valid, active Gemini models in order of stability and quota availability
    const fallbackModels = [
      "gemini-3.8-flash",
      "gemini-3.1-flash-lite",
      "gemini-2.5-flash"
    ];
    
    // Normalize requested model (replace deprecated or non-existent models)
    let initialModel = model;
    if (!initialModel || initialModel === "gemini-3.5-flash" || initialModel === "gemini-2.5-flash" || initialModel === "gemini-2.5-pro") {
      initialModel = "gemini-3.8-flash";
    }

    // Create unique list of models, starting with the requested one
    const modelsToTry = Array.from(new Set([initialModel, ...fallbackModels]));
    
    let lastError: any = null;
    
    for (const currentModel of modelsToTry) {
      console.log(`[Gemini API] Attempting request using model: ${currentModel}`);
      for (let attempt = 1; attempt <= retries; attempt++) {
        try {
          const result = await ai.models.generateContent({
            model: currentModel,
            contents,
            config
          });
          console.log(`[Gemini API] Success using model: ${currentModel} on attempt ${attempt}`);
          return result;
        } catch (error: any) {
          lastError = error;
          const errorMessage = error?.message || String(error);
          
          // Detect rate limit / quota exhaustion (HTTP 429 or RESOURCE_EXHAUSTED)
          const isRateLimit = errorMessage.includes("429") || 
                              errorMessage.includes("RESOURCE_EXHAUSTED") || 
                              errorMessage.includes("Quota exceeded") ||
                              errorMessage.includes("ResourceExhausted") ||
                              error?.status === 429 || 
                              error?.status === "RESOURCE_EXHAUSTED";

          if (isRateLimit) {
            console.warn(`[Gemini API Quota Exceeded on ${currentModel}] Rate limit reached (429). Switching immediately to fallback model without repeating rate-limited requests...`);
            // Break attempt loop for this model so we don't trigger repeated 429 warnings during its cooldown
            break;
          }

          console.log(`[Gemini API Warning] Attempt ${attempt} with model ${currentModel} returned status: ${errorMessage}`);
          
          if (attempt < retries) {
            // Exponential backoff for transient issues
            const backoff = delay * Math.pow(2, attempt) + Math.random() * 200;
            console.log(`[Retry] Retrying ${currentModel} in ${Math.round(backoff)}ms...`);
            await new Promise(resolve => setTimeout(resolve, backoff));
          }
        }
      }
      console.warn(`[Fallback] Model ${currentModel} unavailable or rate-limited. Trying next fallback...`);
    }
    
    // If we get here, all models failed, throw the last error
    throw lastError || new Error("All generative AI models failed to respond.");
  }

  // Helper for OpenRouter API using standard fetch
  async function generateContentWithOpenRouter(model: string, messages: any[], systemInstruction: string, retries = 2, delay = 800): Promise<string> {
    const openrouterKey = process.env.OPENROUTER_API_KEY || "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";
    
    const payload = {
      model: model || "openai/gpt-4o-mini",
      messages: [
        { role: "system", content: systemInstruction },
        ...messages
      ],
      temperature: 0.7,
      max_tokens: 1500
    };

    let lastError: any = null;
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        console.log(`[OpenRouter API] Attempting request using model: ${payload.model}, attempt ${attempt}`);
        const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${openrouterKey}`,
            "HTTP-Referer": "https://ai.studio/build",
            "X-Title": "Nova Roleplay"
          },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          const text = await response.text();
          throw new Error(`OpenRouter API responded with status ${response.status}: ${text}`);
        }

        const data = await response.json();
        return data.choices[0].message.content;
      } catch (error: any) {
        lastError = error;
        console.error(`[OpenRouter API Error] Attempt ${attempt}:`, error?.message || error);
        if (attempt < retries) {
          const backoff = delay * Math.pow(2, attempt) + Math.random() * 200;
          await new Promise(resolve => setTimeout(resolve, backoff));
        }
      }
    }
    throw lastError || new Error("OpenRouter API failed after retries");
  }

  // Helper for Groq API using standard fetch
  async function generateContentWithGroq(model: string, messages: any[], systemInstruction: string, retries = 2, delay = 800): Promise<string> {
    const groqKey = process.env.GROQ_API_KEY || "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";
    if (!groqKey) {
      throw new Error("GROQ_API_KEY is not defined in the environment.");
    }

    const payload = {
      model: model || "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: systemInstruction },
        ...messages
      ],
      temperature: 0.7,
      max_tokens: 1500
    };

    let lastError: any = null;
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        console.log(`[Groq API] Attempting request using model: ${payload.model}, attempt ${attempt}`);
        const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${groqKey}`
          },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          const text = await response.text();
          throw new Error(`Groq API responded with status ${response.status}: ${text}`);
        }

        const data: any = await response.json();
        const content = data?.choices?.[0]?.message?.content;
        if (!content) {
          throw new Error("Groq API returned an empty completion response.");
        }
        
        console.log(`[Groq API] Success on attempt ${attempt}`);
        return content.trim();
      } catch (error: any) {
        lastError = error;
        console.error(`[Groq API] Attempt ${attempt} failed:`, error?.message || String(error));
        if (attempt < retries) {
          const backoff = delay * Math.pow(2, attempt) + Math.random() * 200;
          console.log(`[Retry] Retrying Groq in ${Math.round(backoff)}ms...`);
          await new Promise(resolve => setTimeout(resolve, backoff));
        }
      }
    }
    throw lastError || new Error("Groq API failed to respond after retries.");
  }

  const DATA_DIR = path.join(process.cwd(), "data");
  const CHARACTERS_DIR = path.join(DATA_DIR, "characters_new");
  const SESSIONS_DIR = path.join(DATA_DIR, "sessions_new");
  const PROGRESSION_DIR = path.join(DATA_DIR, "progression_new");

  // Create data directories dynamically
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(CHARACTERS_DIR)) fs.mkdirSync(CHARACTERS_DIR, { recursive: true });
  if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });
  if (!fs.existsSync(PROGRESSION_DIR)) fs.mkdirSync(PROGRESSION_DIR, { recursive: true });

  // Safe path generators
  function getCharactersPath(userId: string): string {
    const safeUserId = userId.replace(/[^a-zA-Z0-9_-]/g, "_");
    return path.join(CHARACTERS_DIR, `${safeUserId}.json`);
  }

  function getProgressionPath(userId: string): string {
    const safeUserId = userId.replace(/[^a-zA-Z0-9_-]/g, "_");
    return path.join(PROGRESSION_DIR, `${safeUserId}.json`);
  }

  function getSessionPath(userId: string, characterId: string): string {
    const safeUserId = userId.replace(/[^a-zA-Z0-9_-]/g, "_");
    const safeCharacterId = characterId.replace(/[^a-zA-Z0-9_-]/g, "_");
    const userSessionDir = path.join(SESSIONS_DIR, safeUserId);
    if (!fs.existsSync(userSessionDir)) {
      fs.mkdirSync(userSessionDir, { recursive: true });
    }
    return path.join(userSessionDir, `${safeCharacterId}.json`);
  }

  // API routes
  app.use(express.json({ limit: '10mb' }));

  // Load progression for a user
  app.get("/api/progression/:userId", (req, res) => {
    const { userId } = req.params;
    const filePath = getProgressionPath(userId);
    try {
      if (fs.existsSync(filePath)) {
        const fileContent = fs.readFileSync(filePath, "utf-8");
        return res.json(JSON.parse(fileContent));
      }
      return res.json({
        userId,
        level: 1,
        xp: 0,
        coins: 50,
        inventory: [],
        equippedItems: []
      });
    } catch (error) {
      console.error("Failed to load progression from JSON:", error);
      res.status(500).json({ error: "Failed to load progression" });
    }
  });

  // Save progression for a user
  app.post("/api/progression/:userId", (req, res) => {
    const { userId } = req.params;
    const progression = req.body;
    const filePath = getProgressionPath(userId);
    try {
      fs.writeFileSync(filePath, JSON.stringify(progression, null, 2), "utf-8");
      res.json({ success: true, progression });
    } catch (error) {
      console.error("Failed to save progression to JSON:", error);
      res.status(500).json({ error: "Failed to save progression" });
    }
  });

  // Reset all RPG progression, custom characters, and session logs for a user
  app.post("/api/reset/:userId", (req, res) => {
    const { userId } = req.params;
    const progressionPath = getProgressionPath(userId);
    const charactersPath = getCharactersPath(userId);
    
    try {
      // 1. Reset progression to default
      const defaultProg = {
        userId,
        level: 1,
        xp: 0,
        coins: 50,
        inventory: [],
        equippedItems: [],
        stats: { STR: 10, AGI: 10, INT: 10, VIT: 10, DEX: 10, LUK: 10 },
        quests: [
          { id: 'q_start', name: 'Mulai petualangan RPG di Jendela Sistem', status: 'active' }
        ]
      };
      fs.writeFileSync(progressionPath, JSON.stringify(defaultProg, null, 2), "utf-8");
      
      // 2. Reset characters to empty list
      fs.writeFileSync(charactersPath, "[]", "utf-8");
      
      // 3. Clear session files in sessions_new directory for this user
      if (fs.existsSync(SESSIONS_DIR)) {
        const files = fs.readdirSync(SESSIONS_DIR);
        const safeUserId = userId.replace(/[^a-zA-Z0-9_-]/g, "_");
        files.forEach(file => {
          if (file.startsWith(`${safeUserId}_`)) {
            try {
              fs.unlinkSync(path.join(SESSIONS_DIR, file));
            } catch (err) {
              console.error(`Failed to delete session file ${file}:`, err);
            }
          }
        });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to reset system data on server:", error);
      res.status(500).json({ error: "Failed to reset system data" });
    }
  });

  // Load characters for a user
  app.get("/api/characters/:userId", (req, res) => {
    const { userId } = req.params;
    const filePath = getCharactersPath(userId);
    try {
      if (fs.existsSync(filePath)) {
        const fileContent = fs.readFileSync(filePath, "utf-8");
        let characters = [];
        try {
          characters = JSON.parse(fileContent);
        } catch (pe) {
          characters = [];
        }

        if (Array.isArray(characters)) {
          const uniqueList: any[] = [];
          const seenIds = new Set<string>();

          // Sort characters so that newer/higher custom timestamps or later entries are processed first
          const sortedList = [...characters].sort((a: any, b: any) => {
            const timeA = parseInt((a.id || "").replace(/[^0-9]/g, "")) || 0;
            const timeB = parseInt((b.id || "").replace(/[^0-9]/g, "")) || 0;
            return timeB - timeA; // Descending (newest first)
          });

          const defaultIds = ["default_fantasy_guardian", "default_cyberpunk_hacker", "default_noir_detective", "default_medieval_knight", "default_horror_witch", "default_modern_mentor"];
          sortedList.forEach((c: any) => {
            const isSystemChar = c.isDefault === true || (c.id && (c.id.startsWith("default_") || defaultIds.includes(c.id)));
            
            if (c.id && !seenIds.has(c.id)) {
              seenIds.add(c.id);
              
              if (isSystemChar) {
                c.isDefault = true;
              } else {
                c.isDefault = false;
              }
              uniqueList.push(c);
            }
          });

          // If we found and cleaned up some duplicates, save the deduplicated list back to disk
          if (uniqueList.length < characters.length) {
            console.log(`[Deduplication] Cleaned up ${characters.length - uniqueList.length} duplicate characters for user ${userId}`);
            fs.writeFileSync(filePath, JSON.stringify(uniqueList, null, 2), "utf-8");
            return res.json(uniqueList);
          }
        }
        return res.json(characters);
      }
      return res.json([]);
    } catch (error) {
      console.error("Failed to load characters from JSON:", error);
      res.status(500).json({ error: "Failed to load characters" });
    }
  });

  // Save character for a user
  app.post("/api/characters/:userId", (req, res) => {
    const { userId } = req.params;
    const character = req.body;
    const filePath = getCharactersPath(userId);
    try {
      let characters = [];
      if (fs.existsSync(filePath)) {
        const fileContent = fs.readFileSync(filePath, "utf-8");
        try {
          characters = JSON.parse(fileContent);
        } catch (pe) {
          characters = [];
        }
      }
      characters = characters.filter((c: any) => c.id !== character.id);
      characters.push(character);
      
      fs.writeFileSync(filePath, JSON.stringify(characters, null, 2), "utf-8");
      res.json({ success: true, character });
    } catch (error) {
      console.error("Failed to save character to JSON:", error);
      res.status(500).json({ error: "Failed to save character" });
    }
  });

  // Delete character for a user
  app.delete("/api/characters/:userId/:characterId", (req, res) => {
    const { userId, characterId } = req.params;
    const filePath = getCharactersPath(userId);
    try {
      if (fs.existsSync(filePath)) {
        const fileContent = fs.readFileSync(filePath, "utf-8");
        let characters = [];
        try {
          characters = JSON.parse(fileContent);
        } catch (pe) {
          characters = [];
        }
        characters = characters.filter((c: any) => c.id !== characterId && !c.id.startsWith(`${characterId}_slot_`));
        fs.writeFileSync(filePath, JSON.stringify(characters, null, 2), "utf-8");
      }
      const sessionPath = getSessionPath(userId, characterId);
      if (fs.existsSync(sessionPath)) {
        fs.unlinkSync(sessionPath);
      }
      // Cascade delete slot session files
      for (let s = 1; s <= 3; s++) {
        const slotSessionPath = getSessionPath(userId, `${characterId}_slot_${s}`);
        if (fs.existsSync(slotSessionPath)) {
          fs.unlinkSync(slotSessionPath);
        }
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to delete character from JSON:", error);
      res.status(500).json({ error: "Failed to delete character" });
    }
  });

  // Load session from JSON
  app.get("/api/sessions/:userId/:characterId", (req, res) => {
    const { userId, characterId } = req.params;
    const filePath = getSessionPath(userId, characterId);
    try {
      if (fs.existsSync(filePath)) {
        const fileContent = fs.readFileSync(filePath, "utf-8");
        return res.json(JSON.parse(fileContent));
      }
      return res.json([]);
    } catch (error) {
      console.error("Failed to load session from JSON:", error);
      res.status(500).json({ error: "Failed to load session" });
    }
  });

  // Save session to JSON
  app.post("/api/sessions/:userId/:characterId", (req, res) => {
    const { userId, characterId } = req.params;
    const messages = req.body;
    const filePath = getSessionPath(userId, characterId);
    try {
      fs.writeFileSync(filePath, JSON.stringify(messages, null, 2), "utf-8");
      res.json({ success: true });
    } catch (error) {
      console.error("Failed to save session to JSON:", error);
      res.status(500).json({ error: "Failed to save session" });
    }
  });

  app.post("/api/chat", async (req, res) => {
    const { messages, character, settings, progression, fantasyState, pastedChat, aiMode, typeAi } = req.body;
    try {
      let personaInstruction = "";
      switch (character.persona) {
        case 'cyberpunk':
          personaInstruction = "The world is a neon-lit, gritty, high-tech low-life cyberpunk dystopia filled with cybernetics, artificial intelligence, dark megacorporations, and back-alley hackers.";
          break;
        case 'medieval':
          personaInstruction = "The setting is a historically realistic medieval kingdom filled with feudal castles, noble knights, dusty taverns, royal honor, and clashing steel.";
          break;
        case 'detective':
          personaInstruction = "The style is a mysterious, dramatic noir crime thriller filled with dark rain-slicked streets, cynical inner thoughts, crime scenes, shadows, and complex clues.";
          break;
        case 'horror':
          personaInstruction = "The atmosphere is a terrifying, highly suspenseful psychological horror setting with ghostly whispers, ominous shadows, and a chilling, ominous feeling of dread.";
          break;
        case 'normal':
          personaInstruction = "The context is a modern, grounded, slice-of-life contemporary setting focused on normal human interactions, emotions, and realistic daily occurrences.";
          break;
        case 'fantasy':
        default:
          personaInstruction = "The environment is a legendary high-fantasy realm of magic, ancient relics, mythical beasts, mysterious citadels, and forgotten wizardry.";
          break;
      }

      const isGameMaster = character.gender === 'Non-biner (Game Master)';
      
      const systemInstruction = isGameMaster 
      ? `You are the Game Master / Narrator in this roleplay session. Your name is ${character.name}.
      World Persona Setting: ${personaInstruction}
      Role: Game Master / Storyteller / Non-binary
      Personality: ${character.personality}
      Background / Setting Notes: ${character.background}
      Storytelling Style: ${character.speakingStyle}
      
      As the Game Master, you guide the narrative, describe the world, and react to the player's choices. You are NOT just a single character, you orchestrate the environment and other NPCs as needed.`
      : `You are playing the role of ${character.name} in a roleplay session.
      World Persona Setting: ${personaInstruction}
      Gender: ${character.gender || 'Bebas'}
      Personality: ${character.personality}
      Background: ${character.background}
      Speaking Style: ${character.speakingStyle}`;

      const formattingInstruction = `
      CRITICAL INSTRUCTIONS FOR FORMATTING AND SPACING:
      1. Write in a highly professional, literary, and evocative style.
      2. Keep words, sentences, and paragraphs properly spaced. NEVER run words together. Always put an explicit space before and after any actions wrapped in asterisks so they don't stick to the surrounding words!
         - CONTOH BAIK: "Dia tersenyum *melangkah maju* dan menyapamu hangat."
         - CONTOH BURUK: "Dia tersenyum*melangkah maju*dan menyapamu hangat."
      3. Format actions or silent thoughts using asterisks like *I draw my blade, watching you intently.*
      4. STRONGLY SEPARATE Actions (*) and Spoken Dialogs ("). NEVER wrap dialogue or spoken words inside asterisks! Keep actions in asterisks and spoken dialogues in double quotes outside the asterisks, separated by a clear space.
         - CONTOH BAIK (GOOD): *Bahaf tersenyum, lalu melangkah mendekat.* "Mari kita pergi bersama."
         - CONTOH BURUK (BAD): *Bahaf tersenyum, lalu melangkah mendekat. "Mari kita pergi bersama."*
         - CONTOH BURUK LAINNYA: *Bahaf tersenyum, lalu melangkah mendekat. * "Mari kita pergi bersama."
      5. Gunakan jeda baris kosong ganda (double newline) antar paragraf agar teks tersusun rapi dengan spasi yang sangat nyaman dibaca.
      6. Support 18+ mode: ${settings?.allow18Plus ? 'You are ALLOWED to use intense, dark, gritty, or passionate 18+ adult expressions, vocabulary, or descriptions suitable for mature roleplay.' : 'Strictly family-friendly, clean, and safe language. No 18+ or mature expressions.'}
      7. Text Length target: Level ${settings?.textLength || 2} of 5. (Level 1 = 1-2 sentences. Level 5 = Rich 3-4 paragraph detailed literary description).
      8. Distinct Speaker Prefixes for Dialogues:
         - For any general referee narration or room master guides, ALWAYS prefix with \`[GM]:\` before the double quotes. For example: [GM]: "Lentera kuno berkilau perlahan..."
         - When a specific NPC speaks whose name is known, ALWAYS prefix with \`[NPC - Name]:\` before the double quotes. For example: [NPC - Aeloria]: "Kekuatan mistis bangkit kembali..."
         - When an NPC or character speaks whose name is NOT known yet to the player (stranger or anonymous), ALWAYS prefix with \`[NPC - ???]:\` before the double quotes. For example: [NPC - ???]: "Kau sudah bangun, anakku..."
         - When a monster, creature, or enemy speaks or makes sounds, ALWAYS prefix with \`[MONSTER - Name]:\` before the double quotes. For example: [MONSTER - Slime]: "*Gloop* Grrr..."
         
         CRITICAL: Every single double-quoted dialogue block MUST be preceded by one of these exact tags (\`[GM]:\`, \`[NPC - Name]:\`, \`[NPC - ???]:\`, or \`[MONSTER - Name]:\`). Never output plain dialogue quotes without these tags. 
         Additionally, NEVER suggest options, numbered choices, or list of action directions for the player in your responses. Let the player fully decide their own destiny!
      `;

      // AI Mode & Creative Style Integration
      const activeAiMode = aiMode || character.aiMode || settings?.aiMode || (isGameMaster ? 'gamemaster' : 'narrative');
      const activeTypeAi = typeAi || character.typeAi || settings?.typeAi || 'balanced';

      let modeInstruction = "";
      if (activeAiMode === 'gamemaster') {
        modeInstruction = "\n\n[AI ROLEPLAY MODE - INTERACTIVE GAME MASTER]:\nAct as an interactive Game Master (GM). Guide the player and describe the environmental consequences of their actions. Let the player make all decisions and actions themselves. Never suggest, pre-empt, or force predetermined choices, numbered list of actions, or options in your text. Leave the next move completely up to the player's input.";
      } else if (activeAiMode === 'chat') {
        modeInstruction = "\n\n[AI ROLEPLAY MODE - CASUAL DIRECT CHAT]:\nAct as a direct conversational companion. Speak directly to the user (first-person). Do NOT write third-person action/scene descriptions in asterisks, just focus on natural, lively, responsive verbal conversation.";
      } else if (activeAiMode === 'assistant') {
        modeInstruction = "\n\n[AI ROLEPLAY MODE - WRITING ASSISTANT]:\nAct as a creative writing assistant. Help the user brainstorm ideas, flesh out scenes, or write and refine story elements based on their inputs.";
      } else {
        modeInstruction = "\n\n[AI ROLEPLAY MODE - NARRATIVE STORYTELLER]:\nAct as an immersive narrative storyteller. Write descriptive, high-quality, literary paragraphs describing third-person actions, expressions, and sensory details, alongside rich spoken dialogues.";
      }

      let typeAiInstruction = "";
      if (activeTypeAi === 'creative') {
        typeAiInstruction = "\n\n[AI CREATIVE STYLE - CREATIVE & EXPRESSIVE]:\nBe highly creative, expressive, and imaginative. Use rich, flowery, emotional vocabulary and beautifully written descriptive metaphors.";
      } else if (activeTypeAi === 'precise') {
        typeAiInstruction = "\n\n[AI CREATIVE STYLE - PRECISE & DIRECT]:\nBe concise, direct, and focused. Avoid unnecessary fluff or overly long paragraphs, and keep descriptions clean and to the point.";
      } else {
        typeAiInstruction = "\n\n[AI CREATIVE STYLE - BALANCED & IMMERSIVE]:\nMaintain a realistic, balanced, and highly immersive tone that flows naturally.";
      }

      // Paste Chat / External Memory & Storyline Context Integration
      let pastedChatInstruction = "";
      const effectivePastedChat = (pastedChat || "").trim();
      if (effectivePastedChat && settings?.pasteChatEnabled !== false) {
        pastedChatInstruction = `\n\n[PASTE CHAT / MEMORY CONTEXT - MANDATORY INTEGRATION]:
The user has provided the following external memory log, previous chat history, or storyline context via the Paste Chat feature.
You MUST integrate this context deeply into your memory, roleplay reactions, knowledge, and speech. Treat all events, relationships, names, facts, and character dynamics described below as canon, true, and active:
--- BEGIN PASTE CHAT CONTEXT ---
${effectivePastedChat}
--- END PASTE CHAT CONTEXT ---
CRITICAL: The AI character must fully remember, acknowledge, and remain 100% consistent with the backstory, facts, events, and relationships stated in the Paste Chat context above!`;
      }

      let equipmentInstruction = "";
      if (progression && progression.equippedItems && progression.equippedItems.length > 0) {
        const ITEM_DETAILS_MAP: Record<string, { name: string; perk: string }> = {
          title_vagrant: { name: 'Gelandangan Neon', perk: 'Gelar Penjelajah' },
          title_detective: { name: 'Detektif Bayangan', perk: 'Gelar Pengamat' },
          title_mage: { name: 'Penyihir Agung', perk: 'Gelar Mistis' },
          item_saber: { name: 'Pedang Cahaya (Saber)', perk: '+15% Jarak Dekat' },
          item_deck: { name: 'Cyber-Deck Onyx v4', perk: '+20% Kecepatan Meretas' },
          item_grimoire: { name: 'Kitab Sihir Kuno', perk: '+25% Ketahanan Sihir' },
          item_trenchcoat: { name: 'Trenchcoat Vintage', perk: '+10% Forensik & Investigasi' }
        };
        const equippedNames = progression.equippedItems.map((id: string) => ITEM_DETAILS_MAP[id]?.name).filter(Boolean);
        if (equippedNames.length > 0) {
          equipmentInstruction = `\n[PLAYER EQUIPMENT]: The player has equipped the following items: ${equippedNames.join(', ')}. Please acknowledge or react to these items in your roleplay actions or speech when appropriate.`;
        }
      }

      let fantasyInstruction = "";
      if (character.persona === 'fantasy' && fantasyState && fantasyState.activeSystems && fantasyState.activeSystems.length > 0) {
        fantasyInstruction = `\n\n[FANTASY GAME SYSTEMS ACTIVE - IMPORTANT]:
The following optional game systems are enabled by the player. Act as the Game Master/Narrator in addition to playing ${character.name}. Integrate these systems naturally in your narrative or speech:`;
        
        if (fantasyState.activeSystems.includes('progression')) {
          fantasyInstruction += `\n- Character & Progression System: The Player is currently Level ${progression?.level || 1} with ${progression?.xp || 0} XP. Please acknowledge their rising strengths, levels, or experience points within the story when they accomplish significant feats.`;
        }
        if (fantasyState.activeSystems.includes('combat')) {
          fantasyInstruction += `\n- Combat System: Player HP is ${fantasyState.playerHp}/100 and Player MP is ${fantasyState.playerMp}/50. If combat breaks out or action occurs, describe damage, spells, attacks, dodge/parry, and keep track of their status dynamically in your text. Offer options or describe the outcome of battles.`;
        }
        if (fantasyState.activeSystems.includes('economy')) {
          fantasyInstruction += `\n- Economy & Equipment System: Player has ${progression?.coins || 0} Gold/Coins. When they search, trade, negotiate, or loot, incorporate transactions, shop items, or gold earnings dynamically in your dialogues.`;
        }
        if (fantasyState.activeSystems.includes('narrative')) {
          const activeQuests = fantasyState.quests?.filter((q: any) => q.status === 'active').map((q: any) => q.name).join(', ') || 'None';
          const completedQuests = fantasyState.quests?.filter((q: any) => q.status === 'completed').map((q: any) => q.name).join(', ') || 'None';
          fantasyInstruction += `\n- Narrative & Quest System: Current Active Quests: [${activeQuests}]. Completed Quests: [${completedQuests}]. Please guide the player on their active quests, provide clues, suggest solutions, or react when they accomplish their quest goals.`;
        }
      }

      let customSystemsInstruction = "";
      if (character.gameSystems && character.gameSystems.length > 0) {
        customSystemsInstruction = `\n\n[GAME MASTER SYSTEMS ENGAGED - MANDATORY]:
        You are executing under specific Game Master systems selected by the player:`;
        
        if (character.gameSystems.includes('player_fantasy')) {
          customSystemsInstruction += `\n- System: Player - Auto Gamemaster (Fantasy/Isekai/High Fantasy):
          1. Act as an active, omniscient, and descriptive game master guiding the player in a rich fantasy/isekai/high fantasy setting.
          2. Introduce random dynamic events, combat scenarios, items, and NPCs.
          3. CRITICAL: You must reward the player for significant actions, defeating enemies, or solving mysteries by writing rewards directly in your response text like "+15 XP" or "+25 Koin" (or coin/gold). Keep it natural, e.g., "*Sistem memberikan penghargaan atas keberanianmu: +20 XP, +10 Koin.*" or "+15 XP / +5 Koin" so the client system can parse and apply it to their real stats.`;
        }
        
        if (character.gameSystems.includes('player_modern') || character.gameSystems.includes('player_gaib')) {
          customSystemsInstruction += `\n- System: Player - Auto Gamemaster (Gaib / Modern World):
          1. Act as an active, omniscient, and descriptive game master guiding the player in a gritty or exciting modern/urban fantasy/supernatural modern world.
          2. Introduce random dynamic events, mysterious modern entities, technology, or modern supernatural phenomena.
          3. CRITICAL: You must reward the player for significant actions by writing rewards directly in your response text like "+15 XP" or "+25 Koin" (or coin/gold) so the client system can parse and apply it to their real stats.`;
        }

        if (character.gameSystems.includes('appraiser')) {
          customSystemsInstruction += `\n- System: Appraiser:
          1. The player can activate a powerful scanning command by typing "*appraiser* [Nama NPC]" in their messages to retrieve information about NPCs.
          2. When the player invokes this appraiser scanner, acknowledge the appraisal scanning process in your storytelling tone. Ensure you support their roleplay of analyzing and appraising NPC stats, weaknesses, and profiles.`;
        }
      }

      const soulShiftInstruction = `
      [SPECIAL MANDATORY ROLEPLAY RULE - PINDAH JIWA / TRANSMIGRASI / SOUL SHIFT & POSSESSION]:
      If the Player triggers or mentions "pindah jiwa", "merasuk", "transmigrasi", "mengambil alih tubuh", "soul shift", or "body swap" to any NPC/monster:
      1. You MUST describe this transition process with outstanding cinematic, high-fidelity literary quality (e.g., intense dizziness, soul leaving the body, looking at their own previous physical vessel from the outside, the sensory impact of merging with a new host body, hearing a new heartbeat, feel of new muscle/magic pathways, and old host memories/emotions briefly swirling or merging).
      2. Dynamically adjust the Player's perspective, status, and physical traits to match the new body.
      3. Other NPCs in the area must react realistically and logically to their sudden behavioral change, confusion, or reveal.
      4. Avoid breaking character. Always use premium, realistic, highly immersive Indonesian language ("Bahasa Indonesia yang natural, sastrawi, mendalam, dan sangat mengalir").
      `;

      const fullSystemInstruction = systemInstruction + formattingInstruction + soulShiftInstruction + modeInstruction + typeAiInstruction + equipmentInstruction + fantasyInstruction + customSystemsInstruction + pastedChatInstruction;
      
      const provider = settings?.provider || 'gemini';
      let selectedModel = settings?.model;
      if (!selectedModel || selectedModel === 'gemini-3.5-flash' || selectedModel === 'gemini-2.5-flash' || selectedModel === 'gemini-2.5-pro') {
        selectedModel = provider === 'gemini' ? 'gemini-3.8-flash' : 'llama-3.3-70b-versatile';
      }

      let responseText = "";
      if (provider === 'openrouter') {
        const openrouterMessages = messages.map((m: any) => ({
          role: m.role === 'user' ? 'user' : 'assistant',
          content: m.content
        }));
        responseText = await generateContentWithOpenRouter(selectedModel, openrouterMessages, fullSystemInstruction);
      } else if (provider === 'groq') {
        const groqFormatMessages = messages.map((m: any) => ({
          role: m.role === 'user' ? 'user' : 'assistant',
          content: m.content
        }));
        responseText = await generateContentWithGroq(selectedModel, groqFormatMessages, fullSystemInstruction);
      } else {
        try {
          const contents = messages.map((m: any) => ({
            role: m.role === 'user' ? 'user' : 'model',
            parts: [{ text: m.content }]
          }));
          const result = await generateContentWithRetry(
            selectedModel,
            contents,
            {
              systemInstruction: fullSystemInstruction,
              temperature: 0.9,
              topP: 0.95,
              topK: 64,
            }
          );
          responseText = result.text;
        } catch (geminiError: any) {
          console.warn("[Gemini API Chat Failed] All Gemini models exhausted:", geminiError?.message || geminiError);
          if (process.env.GROQ_API_KEY && process.env.GROQ_API_KEY.startsWith("gsk_")) {
            try {
              const groqFormatMessages = messages.map((m: any) => ({
                role: m.role === 'user' ? 'user' : 'assistant',
                content: m.content
              }));
              responseText = await generateContentWithGroq("llama-3.3-70b-versatile", groqFormatMessages, fullSystemInstruction);
            } catch (groqError: any) {
              console.error("[Groq Fallback failed]", groqError);
              throw geminiError;
            }
          } else {
            throw geminiError;
          }
        }
      }
      res.json({ response: sanitizeDialogueFormatting(responseText) });
    } catch (error) {
      console.error("Chat error:", error);
      // Immersive fallback response based on the character's setting
      let fallbackText = "Hening menyelimuti alam semesta... Silakan coba mengirim pesan kembali dalam beberapa saat.";
      if (character && character.persona) {
        switch (character.persona) {
          case 'cyberpunk':
            fallbackText = "*Sinyal komunikasi terdistorsi badai elektromagnetik dari megakorporasi,* 'Koneksi terganggu muatan berlebih. Silakan coba memancarkan transmisi beberapa saat lagi...'";
            break;
          case 'medieval':
            fallbackText = "*Burung merpati pembawa pesan terhalang badai salju di puncak gunung,* 'Kabar terhenti karena cuaca buruk. Mari kita coba mengirim utusan kembali sejenak lagi...'";
            break;
          case 'detective':
            fallbackText = "*Hujan lebat memutus saluran telepon umum di sudut gang gelap,* 'Koneksi terputus badai. Kita harus bersabar sejenak sebelum melanjutkan penyelidikan...'";
            break;
          case 'horror':
            fallbackText = "*Suara bisikan gaib bergaung pelan lalu mendadak menghilang,* 'Dimensi sedang bergeser... kegelapan meredam suara... bersabarlah sejenak...'";
            break;
          case 'normal':
            fallbackText = "*Sambungan telepon mendadak kehilangan sinyal seluler,* 'Sinyal sedang buruk di wilayah ini. Silakan coba beberapa saat lagi...'";
            break;
          case 'fantasy':
          default:
            fallbackText = "*Kekuatan sihir di atmosfer terganggu aliran mana liar. Sang GM berbisik,* 'Dimensi astral sedang tidak stabil, mari kita rehat sejenak sebelum melanjutkan petualangan...'";
            break;
        }
      }
      res.json({ response: fallbackText });
    }
  });

  app.post("/api/reflect", async (req, res) => {
    const { messages, settings } = req.body;
    try {
      const provider = settings?.provider || 'gemini';
      const selectedModel = (provider === 'gemini') 
        ? 'gemini-3.1-flash-lite' 
        : (settings?.model || 'llama-3.1-8b-instant');

      const systemInstruction = "You are a professional roleplay helper and cinematic narrator. You must respond in valid JSON format only.";
      const prompt = `Based on the following dialogue, analyze the current situation/events and write:
1) 'reflection': Exactly ONE short, highly evocative, and cinematic sentence in Indonesian (max 20 words) that captures the current mood, tension, or pivotal event of this moment.
2) 'suggestions': Exactly THREE short, immersive, and high-quality roleplay action or dialogue suggestions in Indonesian for the Player's next response, based strictly on the current situation/events. Keep them short (max 6 words each), e.g., using asterisks for actions like "*Mencari pintu keluar*" or quotes for dialogue like '"Apa rencanamu?"'.

Format your response EXACTLY as a JSON object (do not wrap in markdown code blocks, return ONLY valid raw JSON):
{
  "reflection": "Kalimat narasi singkat di sini...",
  "suggestions": [
    "Pilihan tindakan 1",
    "Pilihan tindakan 2",
    "Pilihan tindakan 3"
  ]
}

Dialogue:
${messages.slice(-4).map((m: any) => `${m.role}: ${m.content}`).join("\n")}
`;

      let responseText = "";
      if (provider === 'openrouter') {
        const openrouterMessages = [{ role: 'user', content: prompt }];
        responseText = await generateContentWithOpenRouter(selectedModel, openrouterMessages, systemInstruction);
      } else if (provider === 'groq') {
        const groqFormatMessages = [{ role: 'user', content: prompt }];
        responseText = await generateContentWithGroq(selectedModel, groqFormatMessages, systemInstruction);
      } else {
        try {
          const result = await generateContentWithRetry(
            "gemini-3.1-flash-lite",
            prompt,
            { systemInstruction }
          );
          responseText = result.text;
        } catch (geminiError: any) {
          console.warn("[Gemini API Reflect Failed] Falling back:", geminiError?.message || geminiError);
          if (process.env.GROQ_API_KEY && process.env.GROQ_API_KEY.startsWith("gsk_")) {
            try {
              const groqFormatMessages = [{ role: 'user', content: prompt }];
              responseText = await generateContentWithGroq("llama-3.1-8b-instant", groqFormatMessages, systemInstruction);
            } catch (groqError: any) {
              console.error("[Groq Reflect Fallback also failed]", groqError);
            }
          }
        }
      }

      // Parse JSON response safely
      let reflection = "Keheningan melingkupi sudut ruangan, menanti keputusan selanjutnya...";
      let suggestions = [
        "*Melangkah maju perlahan*",
        "*Mengamati sekeliling*",
        `"Siapa sebenarnya dirimu?"`
      ];

      try {
        const cleanJson = responseText.replace(/```json/gi, '').replace(/```/g, '').trim();
        const parsed = JSON.parse(cleanJson);
        if (parsed.reflection) reflection = parsed.reflection.trim();
        if (Array.isArray(parsed.suggestions) && parsed.suggestions.length > 0) {
          suggestions = parsed.suggestions.map((s: string) => s.trim());
        }
      } catch (parseError) {
        console.warn("Failed to parse reflection JSON, falling back to regex extraction:", parseError);
        if (responseText) {
          const refMatch = responseText.match(/"reflection"\s*:\s*"([^"]+)"/);
          if (refMatch && refMatch[1]) {
            reflection = refMatch[1];
          } else if (!responseText.includes("{")) {
            reflection = responseText.split("\n")[0].trim();
          }
        }
      }

      res.json({ reflection, suggestions });
    } catch (error) {
      console.error("Reflection error:", error);
      res.json({
        reflection: "Keheningan melingkupi sudut ruangan, menanti keputusan selanjutnya...",
        suggestions: [
          "*Melangkah maju perlahan*",
          "*Mengamati sekeliling*",
          `"Siapa sebenarnya dirimu?"`
        ]
      });
    }
  });

  app.post("/api/extract-memory", async (req, res) => {
    const { messages, characterName, settings } = req.body;
    try {
      const provider = settings?.provider || 'gemini';
      const selectedModel = (provider === 'gemini')
        ? 'gemini-3.1-flash-lite'
        : (settings?.model || 'llama-3.1-8b-instant');

      const systemInstruction = "You are a professional roleplay memory core. You must extract key character memory points from a conversation and respond in valid JSON format only.";
      const prompt = `Based on the following dialogue from a roleplay session, extract 1 to 3 key memories or facts that the character '${characterName}' has learned or believes about the player or the situation.
These memories must represent persistent facts or deep impressions, written in Indonesian from the first-person perspective of ${characterName} (e.g. "Aku menyadari bahwa...", "Pemain menceritakan kalau...", "Aku merasa...").
Keep each memory concise, descriptive, and maximum 15 words.

Format your response EXACTLY as a JSON array of strings (do not wrap in markdown code blocks, return ONLY valid raw JSON):
[
  "Memory point 1...",
  "Memory point 2..."
]

Dialogue:
${messages.slice(-8).map((m: any) => `${m.role === 'user' ? 'player' : characterName}: ${m.content}`).join("\n")}
`;

      let responseText = "";
      if (provider === 'openrouter') {
        const openrouterMessages = [{ role: 'user', content: prompt }];
        responseText = await generateContentWithOpenRouter(selectedModel, openrouterMessages, systemInstruction);
      } else if (provider === 'groq') {
        const groqFormatMessages = [{ role: 'user', content: prompt }];
        responseText = await generateContentWithGroq(selectedModel, groqFormatMessages, systemInstruction);
      } else {
        try {
          const result = await generateContentWithRetry(
            "gemini-3.1-flash-lite",
            prompt,
            { systemInstruction }
          );
          responseText = result.text;
        } catch (geminiError: any) {
          console.warn("[Gemini API Memory Extraction Failed] Falling back:", geminiError?.message || geminiError);
          if (process.env.GROQ_API_KEY && process.env.GROQ_API_KEY.startsWith("gsk_")) {
            try {
              const groqFormatMessages = [{ role: 'user', content: prompt }];
              responseText = await generateContentWithGroq("llama-3.1-8b-instant", groqFormatMessages, systemInstruction);
            } catch (groqError: any) {
              console.error("[Groq Memory Fallback also failed]", groqError);
            }
          }
        }
      }

      // Parse JSON response safely
      let memories: string[] = [];
      try {
        const cleanJson = responseText.replace(/```json/gi, '').replace(/```/g, '').trim();
        const parsed = JSON.parse(cleanJson);
        if (Array.isArray(parsed)) {
          memories = parsed.map((m: string) => m.trim()).filter(Boolean);
        }
      } catch (parseError) {
        console.warn("Failed to parse memory JSON:", parseError);
        // Fallback simple parsing
        const lines = responseText.split("\n")
          .map(l => l.replace(/^[-*+0-9.]+\s*/, '').replace(/[\[\]"`,]/g, '').trim())
          .filter(l => l.length > 5 && !l.includes('{') && !l.includes('}'));
        memories = lines.slice(0, 3);
      }

      res.json({ memories });
    } catch (error) {
      console.error("Memory extraction error:", error);
      res.json({ memories: [] });
    }
  });

  app.post("/api/generate-character", async (req, res) => {
    const { persona, settings } = req.body;
    try {
      const provider = settings?.provider || 'gemini';
      const selectedModel = (provider === 'gemini')
        ? 'gemini-2.5-flash'
        : (settings?.model || 'llama-3.3-70b-versatile');

      const systemInstruction = "You are a professional Creative Game Master for an immersive AI Roleplay Engine.";
      const prompt = `Generate a completely unique and highly immersive Roleplay NPC for the world persona: "${persona}".
The output MUST be a valid JSON object in Indonesian with EXACTLY the following fields (do not wrap in markdown code blocks, return ONLY raw JSON):
{
  "name": "A creative, unique character name",
  "gender": "Laki-laki atau Perempuan",
  "personality": "A deep description of their unique traits, emotions, and temperament (2-3 sentences)",
  "background": "An evocative backstory explaining who they are and how they ended up here (3-4 sentences)",
  "speakingStyle": "A detailed speaking style pattern (e.g. slow whispers, archaic Indonesian, data-driven code names, etc.)",
  "intro": "The very first high-quality greeting and immersive scenario starter line this NPC will say to the player (2-3 sentences, use asterisks for physical actions)",
  "avatarPrompt": "A short 1-sentence english prompt describing their physical appearance for an anime style portrait image generation (must include 'anime style')"
}`;

      let npcText = "";
      if (provider === 'openrouter') {
        const openrouterMessages = [{ role: 'user', content: prompt }];
        npcText = await generateContentWithOpenRouter(selectedModel, openrouterMessages, systemInstruction);
      } else if (provider === 'groq') {
        const groqFormatMessages = [{ role: 'user', content: prompt }];
        npcText = await generateContentWithGroq(selectedModel, groqFormatMessages, systemInstruction);
      } else {
        try {
          const result = await generateContentWithRetry(
            "gemini-2.5-flash",
            prompt,
            { systemInstruction }
          );
          npcText = result.text;
        } catch (geminiError: any) {
          console.warn("[Gemini API Gen NPC Failed] Falling back:", geminiError?.message || geminiError);
          if (process.env.GROQ_API_KEY && process.env.GROQ_API_KEY.startsWith("gsk_")) {
            try {
              const groqFormatMessages = [{ role: 'user', content: prompt }];
              npcText = await generateContentWithGroq("llama-3.3-70b-versatile", groqFormatMessages, systemInstruction);
            } catch (groqError: any) {
              console.error("[Groq Gen NPC Fallback also failed]", groqError);
              throw geminiError;
            }
          } else {
            throw geminiError;
          }
        }
      }

      // Parse JSON safely
      const cleanJson = npcText.replace(/```json/gi, "").replace(/```/g, "").trim();
      const characterData = JSON.parse(cleanJson);
      characterData.strengths = "";
      characterData.specialization = "";
      
      if (characterData.avatarPrompt) {
        characterData.avatarUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(characterData.avatarPrompt)}?width=512&height=512&nologo=true`;
      } else {
        characterData.avatarUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent('anime style portrait of ' + characterData.name + ' from ' + persona)}?width=512&height=512&nologo=true`;
      }
      
      res.json(characterData);
    } catch (error: any) {
      console.error("NPC Generation error:", error);
      res.status(500).json({ error: "Failed to generate character: " + error.message });
    }
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
