import { CreateMLCEngine } from "@mlc-ai/web-llm";

let activeEngine: any = null;
let activeModelId: string | null = null;

export interface ProgressReport {
  progress: number;
  text: string;
}

export async function getWebLLMEngine(
  modelId: string,
  onProgress?: (report: ProgressReport) => void
): Promise<any> {
  if (activeEngine && activeModelId === modelId) {
    return activeEngine;
  }

  // If there's an existing engine running a different model, we can unload/stop it
  if (activeEngine) {
    try {
      await activeEngine.unload();
    } catch (e) {
      console.warn("Unloading previous engine failed:", e);
    }
    activeEngine = null;
    activeModelId = null;
  }

  console.log(`Initializing WebLLM engine for model: ${modelId}`);
  const engine = await CreateMLCEngine(modelId, {
    initProgressCallback: (report) => {
      if (onProgress) {
        onProgress({
          progress: report.progress,
          text: report.text,
        });
      }
    },
  });

  activeEngine = engine;
  activeModelId = modelId;
  return engine;
}

export async function resetWebLLMChat(): Promise<void> {
  if (activeEngine) {
    try {
      await activeEngine.resetChat();
    } catch (e) {
      console.warn("Failed to reset WebLLM chat state:", e);
    }
  }
}
