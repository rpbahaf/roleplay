import { Character, Message } from '../types';

// Simple lightweight base64 scrambling for "secure/encrypted" log presentation
export function encryptMessage(text: string): string {
  try {
    return btoa(unescape(encodeURIComponent(text)));
  } catch (e) {
    return text;
  }
}

export function decryptMessage(cipher: string): string {
  try {
    return decodeURIComponent(escape(atob(cipher)));
  } catch (e) {
    return cipher;
  }
}

export async function saveCharacter(userId: string, character: Character): Promise<void> {
  // Save to Server JSON via API
  if (userId !== 'guest') {
    try {
      await fetch(`/api/characters/${encodeURIComponent(userId)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(character)
      });
    } catch (e) {
      console.error('Error saving character to server JSON:', e);
    }
  }
  
  // Local storage backup
  const key = `rp_chars_new_${userId}`;
  const current = getLocalCharacters(userId);
  const updated = current.filter(c => c.id !== character.id).concat(character);
  try {
    localStorage.setItem(key, JSON.stringify(updated));
  } catch (err) {
    console.error('Local storage full:', err);
  }
}

function getLocalCharacters(userId: string): Character[] {
  const data = localStorage.getItem(`rp_chars_new_${userId}`);
  try {
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
}

export async function loadCharacters(userId: string): Promise<Character[]> {
  let serverChars: Character[] = [];
  // Load from Server JSON via API
  if (userId !== 'guest') {
    try {
      const res = await fetch(`/api/characters/${encodeURIComponent(userId)}`);
      if (res.ok) {
        const loaded = await res.json();
        if (Array.isArray(loaded)) {
          serverChars = loaded;
        }
      }
    } catch (e) {
      console.error('Error loading characters from server JSON:', e);
    }
  }

  const localChars = getLocalCharacters(userId);
  
  // Merge both by ID, preferring server version if there's a conflict
  const mergedMap = new Map<string, Character>();
  
  // Add local characters first
  localChars.forEach(c => {
    if (c && c.id) {
      mergedMap.set(c.id, c);
    }
  });
  
  // Override or add with server characters
  serverChars.forEach(c => {
    if (c && c.id) {
      mergedMap.set(c.id, c);
    }
  });
  
  const mergedList = Array.from(mergedMap.values());
  
  // Deduplicate custom characters by id to prevent duplication bugs
  const uniqueList: Character[] = [];
  const seenIds = new Set<string>();

  // Sort list to process newer custom characters (based on id timestamp) first
  const sortedList = [...mergedList].sort((a, b) => {
    const timeA = parseInt((a.id || '').replace(/[^0-9]/g, '')) || 0;
    const timeB = parseInt((b.id || '').replace(/[^0-9]/g, '')) || 0;
    return timeB - timeA; // Descending (newest first)
  });

  const defaultIds = ["default_fantasy_guardian", "default_cyberpunk_hacker", "default_noir_detective", "default_medieval_knight", "default_horror_witch", "default_modern_mentor"];

  sortedList.forEach(c => {
    const isSystemChar = c.isDefault === true || (c.id && (c.id.startsWith("default_") || defaultIds.includes(c.id)));
    
    if (c.id && !seenIds.has(c.id)) {
      seenIds.add(c.id);
      
      if (isSystemChar) {
        c.isDefault = true;
      } else {
        c.isDefault = false;
      }
      
      uniqueList.push(c);
    }
  });
  
  // Sync back to local storage and server if needed to keep them 100% in sync
  if (userId !== 'guest' && uniqueList.length > 0) {
    localStorage.setItem(`rp_chars_new_${userId}`, JSON.stringify(uniqueList));
    
    // Proactively upload missing local characters to server to keep them fully synced
    const unsyncedChars = uniqueList.filter(uc => !uc.isDefault && !serverChars.some(sc => sc.id === uc.id));
    for (const uc of unsyncedChars) {
      try {
        await fetch(`/api/characters/${encodeURIComponent(userId)}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(uc)
        });
      } catch (err) {
        console.error('Failed to sync character to server:', err);
      }
    }
  }
  
  return uniqueList;
}

export async function saveChatSession(userId: string, characterId: string, messages: Message[]): Promise<void> {
  const encryptedMessages = messages.map(m => ({
    ...m,
    content: encryptMessage(m.content)
  }));

  // Save to Server JSON via API
  if (userId !== 'guest') {
    try {
      await fetch(`/api/sessions/${encodeURIComponent(userId)}/${encodeURIComponent(characterId)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(encryptedMessages)
      });
    } catch (e) {
      console.error('Error saving chat session to server JSON:', e);
    }
  }

  // Local storage backup
  localStorage.setItem(`rp_chat_${userId}_${characterId}`, JSON.stringify(encryptedMessages));
}

export async function loadChatSession(userId: string, characterId: string): Promise<Message[]> {
  // Load from Server JSON via API
  if (userId !== 'guest') {
    try {
      const res = await fetch(`/api/sessions/${encodeURIComponent(userId)}/${encodeURIComponent(characterId)}`);
      if (res.ok) {
        const encryptedMsgs = await res.json();
        if (encryptedMsgs && encryptedMsgs.length > 0) {
          return encryptedMsgs.map((m: any) => ({
            ...m,
            content: decryptMessage(m.content)
          }));
        }
      }
    } catch (e) {
      console.error('Error loading chat session from server JSON:', e);
    }
  }

  // Local storage backup
  const localData = localStorage.getItem(`rp_chat_${userId}_${characterId}`);
  if (localData) {
    const encryptedMsgs = JSON.parse(localData) as Message[];
    return encryptedMsgs.map(m => ({
      ...m,
      content: decryptMessage(m.content)
    }));
  }

  return [];
}

export async function deleteCharacter(userId: string, characterId: string): Promise<void> {
  // Delete from Server JSON via API
  if (userId !== 'guest') {
    try {
      await fetch(`/api/characters/${encodeURIComponent(userId)}/${encodeURIComponent(characterId)}`, {
        method: 'DELETE'
      });
    } catch (e) {
      console.error('Error deleting character from server JSON:', e);
    }
  }

  // Local storage clean
  const key = `rp_chars_new_${userId}`;
  const data = localStorage.getItem(key);
  if (data) {
    const current = JSON.parse(data) as Character[];
    const updated = current.filter(c => c.id !== characterId && !c.id.startsWith(`${characterId}_slot_`));
    localStorage.setItem(key, JSON.stringify(updated));
  }

  // Also remove saved chat history for base and slots
  localStorage.removeItem(`rp_chat_${userId}_${characterId}`);
  for (let s = 1; s <= 3; s++) {
    localStorage.removeItem(`rp_chat_${userId}_${characterId}_slot_${s}`);
  }
}

