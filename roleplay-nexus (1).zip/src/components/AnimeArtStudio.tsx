import { useState } from 'react';
import { Image as ImageIcon, Download, RefreshCw, Sparkles, Wand2, ArrowRight } from 'lucide-react';

interface AnimeArtStudioProps {
  playAudioCue?: (type: 'click' | 'receive' | 'reflect') => void;
  showToast?: (msg: string) => void;
}

export default function AnimeArtStudio({ playAudioCue, showToast }: AnimeArtStudioProps) {
  const [prompt, setPrompt] = useState('');
  const [useAnimeStyle, setUseAnimeStyle] = useState(true);
  const [generatedUrl, setGeneratedUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [imgLoading, setImgLoading] = useState(false);

  const PRESETS = [
    { title: "Cyber-Vixen", text: "cyberpunk girl with neon goggles, pink hair, holding katana" },
    { title: "Magical Elf", text: "fantasy elf princess casting star magic spell in ancient forest" },
    { title: "Noir Detective", text: "detective in trenchcoat walking down wet streets in rain, neon glowing lights" },
    { title: "Samurai Mecha", text: "futuristic mecha robot with classic samurai armor, neon outline" }
  ];

  const handleGenerate = () => {
    if (!prompt.trim()) {
      if (showToast) showToast("⚠️ Masukkan prompt terlebih dahulu!");
      return;
    }

    if (playAudioCue) playAudioCue('reflect');
    setIsGenerating(true);
    setImgLoading(true);

    const randomSeed = Math.floor(Math.random() * 9999999);
    // Construct final prompt
    let finalPrompt = prompt.trim();
    if (useAnimeStyle) {
      finalPrompt += ", gorgeous anime style illustration, masterpiece, detailed line art, vivid colors, 4k resolution, pixiv art";
    }

    // Use Pollinations AI image generator API
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(finalPrompt)}?width=512&height=512&nologo=true&seed=${randomSeed}`;
    setGeneratedUrl(url);
  };

  const handleDownload = async () => {
    if (!generatedUrl) return;
    if (playAudioCue) playAudioCue('click');
    setIsDownloading(true);

    try {
      const response = await fetch(generatedUrl);
      const blob = await response.blob();
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = `nova_anime_${Date.now()}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);
      if (showToast) showToast("🎉 Gambar berhasil diunduh!");
    } catch (err) {
      console.error("Gagal mengunduh gambar:", err);
      // Fallback: open in new tab
      window.open(generatedUrl, '_blank');
      if (showToast) showToast("Membuka gambar di tab baru untuk diunduh...");
    } finally {
      setIsDownloading(false);
    }
  };

  const applyPreset = (presetText: string) => {
    if (playAudioCue) playAudioCue('click');
    setPrompt(presetText);
  };

  return (
    <div className="flex flex-col gap-5 text-gray-100">
      {/* Header Title */}
      <div className="space-y-1">
        <span className="text-[9px] bg-purple-500/10 text-purple-400 border border-purple-500/20 px-2.5 py-1 rounded-full uppercase font-bold tracking-widest inline-flex items-center gap-1.5 animate-pulse">
          <Sparkles size={11} className="text-purple-400" /> Studio Seni Anime AI
        </span>
        <h4 className="text-lg font-black text-white tracking-tight uppercase">AI Anime Art Canvas</h4>
        <p className="text-xs text-gray-400">
          Buat ilustrasi anime berkualitas tinggi dengan kekuatan AI Pollinations secara instan!
        </p>
      </div>

      {/* Grid Layout to split canvas and settings on md+ screen widths */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        {/* Column 1: Canvas Display Area */}
        <div className="space-y-3">
          <div className="relative aspect-square w-full max-w-[380px] mx-auto rounded-2xl bg-[#0f0b21]/70 border border-purple-500/15 overflow-hidden flex flex-col items-center justify-center group shadow-2xl">
            {generatedUrl ? (
              <>
                {/* Actual Image */}
                <img
                  src={generatedUrl}
                  alt="AI Generated Art"
                  className={`w-full h-full object-cover transition-opacity duration-500 ${imgLoading ? 'opacity-30' : 'opacity-100'}`}
                  onLoad={() => {
                    setImgLoading(false);
                    setIsGenerating(false);
                  }}
                  onError={() => {
                    setImgLoading(false);
                    setIsGenerating(false);
                    if (showToast) showToast("❌ Gagal memuat gambar dari server AI.");
                  }}
                />

                {/* Subtle Hover Info overlay */}
                {!imgLoading && (
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity">
                    <p className="text-[10px] text-gray-300 line-clamp-2 leading-relaxed italic">
                      "{prompt}"
                    </p>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center p-6 flex flex-col items-center space-y-3">
                <div className="p-4 bg-purple-500/10 rounded-2xl border border-purple-500/20 text-gray-400">
                  <ImageIcon size={32} className="text-purple-400 animate-pulse" />
                </div>
                <p className="text-xs text-gray-400 max-w-[200px] leading-relaxed">
                  Ketik konsep impian Anda di panel kanan, lalu tekan tombol generator!
                </p>
              </div>
            )}

            {/* Generator Overlay Spinner */}
            {(isGenerating || imgLoading) && (
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center space-y-3">
                <RefreshCw size={28} className="animate-spin text-purple-500" />
                <span className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase animate-pulse font-bold">
                  MELUKIS PIXEL...
                </span>
              </div>
            )}
          </div>

          {/* Dedicated Download Button - ALWAYS VISIBLE for UX clarity (especially mobile) */}
          {generatedUrl && !imgLoading && (
            <div className="flex justify-center">
              <button
                onClick={handleDownload}
                disabled={isDownloading}
                className="w-full max-w-[380px] py-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold rounded-xl text-xs transition flex items-center justify-center gap-2 shadow-lg shadow-purple-500/10 cursor-pointer disabled:opacity-50"
              >
                {isDownloading ? (
                  <RefreshCw size={14} className="animate-spin" />
                ) : (
                  <Download size={14} />
                )}
                UNDUH GAMBAR ANIME (JPG)
              </button>
            </div>
          )}
        </div>

        {/* Column 2: Controls and Options */}
        <div className="space-y-4">
          {/* Prompt Input Form */}
          <div className="space-y-1.5">
            <label className="text-[10px] text-gray-400 uppercase tracking-widest font-black font-mono">
              Deskripsi Gambar / Prompt
            </label>
            <div className="relative flex items-center bg-black/50 border border-white/10 rounded-xl focus-within:border-cyan-400/40 transition">
              <input
                type="text"
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="cth: ksatria naga berkepala putih di kastil es..."
                className="w-full bg-transparent p-3.5 pr-12 text-xs outline-none text-white placeholder-gray-600"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleGenerate();
                }}
              />
              <button
                onClick={handleGenerate}
                disabled={isGenerating || !prompt.trim()}
                className="absolute right-2 p-2 bg-purple-600/10 hover:bg-purple-600 text-purple-400 hover:text-white rounded-lg transition disabled:opacity-20 cursor-pointer"
                title="Hasilkan Gambar"
              >
                <Wand2 size={14} />
              </button>
            </div>
          </div>

          {/* Anime Style Switch */}
          <div className="flex items-center justify-between bg-white/[0.02] border border-white/5 p-3 rounded-xl">
            <div className="space-y-0.5">
              <span className="text-xs text-gray-200 font-bold tracking-wide block">Terapkan Gaya Anime</span>
              <span className="text-[10px] text-gray-500 block">Menambahkan bumbu ilustrasi khas masterpiece anime</span>
            </div>
            <button
              onClick={() => {
                if (playAudioCue) playAudioCue('click');
                setUseAnimeStyle(!useAnimeStyle);
              }}
              className={`text-[10px] px-3 py-1.5 rounded-lg font-bold uppercase tracking-wider transition ${
                useAnimeStyle
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                  : 'bg-white/5 text-gray-500 border border-white/5'
              }`}
            >
              {useAnimeStyle ? "Aktif" : "Nonaktif"}
            </button>
          </div>

          {/* Preset Prompts Block */}
          <div className="space-y-2">
            <span className="text-[10px] text-gray-500 uppercase tracking-widest font-black font-mono block">
              Inspirasi Tema Instan
            </span>
            <div className="grid grid-cols-2 gap-2">
              {PRESETS.map((p, i) => (
                <button
                  key={i}
                  onClick={() => applyPreset(p.text)}
                  className="text-[10px] text-left p-2.5 bg-white/[0.01] border border-white/5 rounded-xl text-gray-400 hover:text-cyan-400 hover:bg-white/5 hover:border-cyan-400/30 transition line-clamp-1 truncate"
                  title={p.text}
                >
                  ✨ {p.title}
                </button>
              ))}
            </div>
          </div>

          {/* Instruction helper */}
          <div className="text-[10px] text-gray-500 leading-relaxed flex items-center gap-2 bg-white/[0.01] p-3 rounded-xl border border-white/5">
            <ArrowRight size={12} className="shrink-0 text-cyan-500/60" />
            <span>Karya seni AI yang Anda buat bebas hak cipta & dapat langsung digunakan sebagai profil karakter kustom!</span>
          </div>
        </div>
      </div>
    </div>
  );
}
