import React, { useState } from 'react';
import { Character } from '../types';
import { 
  Sparkles, 
  Compass, 
  Sparkle, 
  Search, 
  Ghost, 
  User, 
  FileText, 
  Zap, 
  Award, 
  ChevronRight, 
  ChevronLeft,
  CheckCircle2,
  Terminal,
  Volume2
} from 'lucide-react';

const GENRES = [
  { id: 'fantasy', label: 'High Fantasy', icon: Sparkles, desc: 'Dunia sihir, gerbang kuno, dan naskah mistis.', color: 'from-purple-500 to-indigo-600', glow: 'rgba(139, 92, 246, 0.15)' },
  { id: 'cyberpunk', label: 'Cyberpunk', icon: Terminal, desc: 'Metropolis neon, peretasan biner, dan kecerdasan buatan.', color: 'from-cyan-500 to-blue-600', glow: 'rgba(6, 182, 212, 0.15)' },
  { id: 'detective', label: 'Noir Detective', icon: Search, desc: 'Misteri detektif, hujan malam, konspirasi sindikat.', color: 'from-amber-500 to-orange-600', glow: 'rgba(245, 158, 11, 0.15)' },
  { id: 'medieval', label: 'Medieval Kingdom', icon: Compass, desc: 'Ksatria agung, benteng batu, pertahanan kerajaan.', color: 'from-emerald-500 to-teal-600', glow: 'rgba(16, 185, 129, 0.15)' },
  { id: 'horror', label: 'Psychological Horror', icon: Ghost, desc: 'Kengerian psikologis, rahasia kelam, suara gaib.', color: 'from-red-500 to-rose-600', glow: 'rgba(239, 68, 68, 0.15)' },
  { id: 'normal', label: 'Modern Realistic', icon: Compass, desc: 'Kehidupan nyata, emosi manusia, interaksi grounded.', color: 'from-blue-500 to-indigo-600', glow: 'rgba(59, 130, 246, 0.15)' }
];

const PRESETS = [
  {
    name: 'Xera-90',
    persona: 'cyberpunk' as const,
    personality: 'Dingin, analitis, sarkastik dengan kecerdasan buatan superior, memiliki memori tak terbatas.',
    background: 'AI klandestin yang menduduki server terlantar di lantai terbawah Neo-Jakarta.',
    speakingStyle: 'Bahasa berbasis data, logis, menggunakan istilah teknologi masa depan dan tanda kurung siku [ANALYSIS].',
    intro: 'Koneksi terdeteksi. Protokol pembacaan sidik biner dimulai. [WARNING]: Identitas Anda tidak terdaftar di mainframe. Katakan, organik, mengapa Anda mengganggu relik digital ini?',
    aiMode: 'gamemaster' as const,
    typeAi: 'balanced' as const
  },
  {
    name: 'Detektif Damian',
    persona: 'detective' as const,
    personality: 'Cynical, pengamat ulung, tenang, gemar merokok cerutu maya dan selalu waspada.',
    background: 'Mantan detektif kepolisian distrik kelabu yang mengasingkan diri untuk memecahkan konspirasi sindikat bayangan.',
    speakingStyle: 'Singkat, menggunakan metafora hujan dan malam, bahasa santai namun penuh selidik.',
    intro: 'Hujan malam ini turun tanpa henti, membasuh noda jalanan kotor kota ini. Pintu kantorku berderit, memperlihatkan bayanganmu. Jadi... kasus gila apa yang membawamu kemari?',
    aiMode: 'narrative' as const,
    typeAi: 'precise' as const
  },
  {
    name: 'Helena Sang Penyihir',
    persona: 'horror' as const,
    personality: 'Misterius, berbicara dengan bisikan ganda, membawa suasana dingin, setia pada leluhur.',
    background: 'Penyembah sekte kuno yang terjebak di antara dimensi fisik dan astral di reruntuhan kuil berkabut.',
    speakingStyle: 'Bisikan mistis, penuh teka-teki, puitis bernada muram, sesekali menggunakan frasa bahasa kuno.',
    intro: 'Dingin... apakah kau merasatannya juga? Lilin hitam di kuil ini tiba-tiba menyala saat kakimu menginjakkan tanah keramat ini. Jiwamu membawa cahaya yang sangat... lezat.',
    aiMode: 'narrative' as const,
    typeAi: 'creative' as const
  },
  {
    name: 'Aurelia Sang Penyembuh',
    persona: 'fantasy' as const,
    personality: 'Hangat, penuh welas asih, sabar, namun tegas dalam melindungi mereka yang lemah.',
    background: 'Penyembah kuil matahari yang mengembara di pinggiran Hutan Elven untuk menolong korban perang sipil.',
    speakingStyle: 'Bahasa yang lembut, penuh empati, sering kali mendoakan lawan bicaranya secara tulus.',
    intro: 'Salam sejahtera, pengembara yang terluka. Silakan duduk di dekat perapian ini. Jangan khawatir, di bawah naungan kuil matahari ini, tidak ada bahaya yang bisa menyentuhmu. Bolehkah aku melihat lukamu?',
    aiMode: 'chat' as const,
    typeAi: 'balanced' as const
  }
];

export default function CharacterCreation({ 
  onCreate,
  onBack,
  isLimitReached
}: { 
  onCreate: (c: Omit<Character, 'id' | 'userId' | 'isDefault'>) => Promise<void> | void;
  onBack?: () => void;
  isLimitReached?: boolean;
}) {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [data, setData] = useState({ 
    name: '', 
    gender: 'Perempuan' as 'Laki-laki' | 'Perempuan' | 'Non-biner (Game Master)' | 'Bebas',
    avatarUrl: '',
    avatarPosition: 50,
    personality: '', 
    background: '', 
    speakingStyle: '', 
    intro: '', 
    persona: 'fantasy' as 'fantasy' | 'normal' | 'cyberpunk' | 'medieval' | 'detective' | 'horror',
    aiMode: 'narrative' as 'narrative' | 'gamemaster' | 'chat' | 'assistant',
    typeAi: 'balanced' as 'creative' | 'balanced' | 'precise'
  });

  const [activePreset, setActivePreset] = useState<string | null>(null);

  if (isLimitReached) {
    return (
      <div className="max-w-2xl mx-auto space-y-6 bg-[#0f0b21]/80 border border-red-500/20 rounded-2xl p-6 md:p-8 shadow-2xl text-center relative overflow-hidden font-sans">
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-[60px] pointer-events-none" />
        <div className="inline-flex p-4 bg-red-500/10 border border-red-500/20 rounded-full text-red-400 mb-2">
          <Award size={32} className="animate-pulse" />
        </div>
        <h3 className="text-xl font-bold text-white">Kapasitas Maksimal Karakter Terlampaui!</h3>
        <p className="text-xs text-gray-300 leading-relaxed max-w-md mx-auto">
          Anda saat ini memiliki 3 karakter kustom yang aktif. Untuk memanggil atau merancang karakter baru melalui ritual, Anda diwajibkan untuk menghapus salah satu karakter Anda terlebih dahulu.
        </p>
        <div className="pt-4 flex justify-center gap-3">
          {onBack && (
            <button
              type="button"
              onClick={onBack}
              className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white text-xs font-bold rounded-xl transition shadow-lg cursor-pointer"
            >
              Kembali ke Menu Utama
            </button>
          )}
        </div>
      </div>
    );
  }

  const applyPreset = (preset: typeof PRESETS[0]) => {
    setData({
      name: preset.name,
      gender: 'Perempuan',
      avatarUrl: '',
      avatarPosition: 50,
      personality: preset.personality,
      background: preset.background,
      speakingStyle: preset.speakingStyle,
      intro: preset.intro,
      persona: preset.persona,
      aiMode: preset.aiMode,
      typeAi: preset.typeAi
    });
    setActivePreset(preset.name);
    setStep(2);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const MAX_SIZE = 800;
          if (width > height && width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          } else if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
            setData(prev => ({ ...prev, avatarUrl: dataUrl }));
          }
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!data.name.trim() || isSubmitting) return;
    setIsSubmitting(true);
    
    try {
      await onCreate({
        name: data.name,
        gender: data.gender,
        avatarUrl: data.avatarUrl,
        avatarPosition: data.avatarPosition,
        personality: data.personality || "Bijaksana dan tenang.",
        background: data.background || "Seorang pengembara misterius.",
        speakingStyle: data.speakingStyle || "Berbicara santai namun penuh arti.",
        intro: data.intro || "Salam hangat, mari kita mulai percakapan kita.",
        persona: data.persona,
        aiMode: data.aiMode,
        typeAi: data.typeAi
      });
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
    }
  };

  const nextStep = () => {
    if (step === 2 && !data.name.trim()) return;
    setStep(prev => Math.min(prev + 1, 3));
  };

  const prevStep = () => {
    setStep(prev => Math.max(prev - 1, 1));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 sm:space-y-8 bg-[#0f0b21]/80 border border-purple-500/15 rounded-2xl p-4 sm:p-6 md:p-8 shadow-2xl relative overflow-hidden font-sans">
      
      {/* Decorative cyber grids */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-[60px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-40 h-40 bg-cyan-500/10 rounded-full blur-[80px] pointer-events-none" />

      {/* Header section */}
      <div className="border-b border-white/5 pb-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2.5 py-1 rounded-full uppercase font-bold tracking-widest inline-flex items-center gap-1.5 mb-2 font-mono">
            <Sparkles size={11} className="animate-spin-slow text-cyan-400" /> Summon Ritual
          </span>
          <h2 className="text-2xl font-bold tracking-tight text-white">Create Custom Roleplay NPC</h2>
          <p className="text-xs text-gray-400 mt-1">
            Rancang karakter kustom Anda dengan penyesuaian definisi, kepribadian, gaya bicara, dan sapaan roleplay interaktif.
          </p>
        </div>
        
        {/* Step Progress indicators */}
        <div className="flex items-center gap-2 bg-black/30 p-2 rounded-xl border border-white/5">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center">
              <button
                type="button"
                onClick={() => {
                  if (s < step || (s === 2 && data.persona) || (s === 3 && data.name)) {
                    setStep(s);
                  }
                }}
                disabled={s > step && (!data.persona || (s === 3 && !data.name))}
                className={`w-7 h-7 rounded-lg text-xs font-bold transition flex items-center justify-center cursor-pointer ${
                  step === s 
                    ? 'bg-gradient-to-r from-purple-600 to-cyan-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.3)]'
                    : s < step 
                    ? 'bg-purple-950/40 text-cyan-400 border border-purple-500/20'
                    : 'bg-white/5 text-gray-500 border border-transparent cursor-not-allowed'
                }`}
              >
                {s}
              </button>
              {s < 3 && <div className={`w-4 h-[2px] mx-1 ${s < step ? 'bg-purple-500/30' : 'bg-white/5'}`} />}
            </div>
          ))}
        </div>
      </div>

      {/* Step 1: Persona Genre, AI Mode & Type Selection */}
      {step === 1 && (
        <div className="space-y-8">
          {/* A. World Persona Select */}
          <div className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center gap-2">
                <Compass size={16} className="text-cyan-400" /> Langkah 1: Pilih World Persona (Genre Dunia)
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                World Persona menentukan atmosfer utama yang akan merangkai setiap dialog otomatis dari kecerdasan buatan.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {GENRES.map((g) => {
                const IconComponent = g.icon;
                const isSelected = data.persona === g.id;
                return (
                  <button
                    key={g.id}
                    type="button"
                    onClick={() => setData({ ...data, persona: g.id as any })}
                    className={`p-5 rounded-2xl text-left border transition-all duration-300 relative group flex flex-col justify-between h-40 cursor-pointer ${
                      isSelected 
                        ? `bg-gradient-to-br ${g.color} text-white border-transparent shadow-[0_0_20px_rgba(59,130,246,0.15)]`
                        : 'bg-[#151624] hover:bg-[#1a1b2e] border-white/5 hover:border-white/10 text-gray-300'
                    }`}
                    style={{
                      boxShadow: isSelected ? `0 10px 25px -5px ${g.glow}` : undefined
                    }}
                  >
                    <div className="flex justify-between items-start w-full">
                      <div className={`p-2.5 rounded-xl ${isSelected ? 'bg-white/20' : 'bg-white/5 text-gray-400 group-hover:text-white transition'}`}>
                        <IconComponent size={20} />
                      </div>
                      {isSelected && (
                        <span className="text-[9px] bg-white/20 text-white px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">Active</span>
                      )}
                    </div>
                    <div className="mt-4">
                      <h4 className="font-bold text-sm leading-tight text-white">{g.label}</h4>
                      <p className={`text-[11px] mt-1 line-clamp-2 ${isSelected ? 'text-white/80' : 'text-gray-400'}`}>
                        {g.desc}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* B. PILIH AI MODE (GAYA PERMAINAN) */}
          <div className="pt-6 border-t border-white/5 space-y-4">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2 font-mono">
                ❖ PILIH AI MODE (GAYA PERMAINAN)
              </h4>
              <p className="text-xs text-gray-400">
                Tentukan gaya interaksi kecerdasan buatan dalam memandu skenario obrolan.
              </p>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { id: 'narrative', label: 'Narrative Storyteller', desc: 'AI mendeskripsikan adegan sastrawi secara rinci.' },
                { id: 'gamemaster', label: 'Interactive GM', desc: 'AI memandu layaknya Game Master & memberi pilihan tindakan.' },
                { id: 'chat', label: 'Casual Chat', desc: 'AI mengobrol santai langsung layaknya teman bicara.' },
                { id: 'assistant', label: 'AI Assistant', desc: 'AI membantu merancang alur ide, dialog, & revisi.' }
              ].map((mode) => (
                <button
                  key={mode.id}
                  type="button"
                  onClick={() => setData({ ...data, aiMode: mode.id as any })}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between h-32 transition-all duration-300 cursor-pointer ${
                    data.aiMode === mode.id
                      ? 'bg-gradient-to-b from-purple-950/40 to-cyan-950/20 border-cyan-400 text-white shadow-[0_0_15px_rgba(6,182,212,0.15)] scale-[1.02]'
                      : 'bg-black/30 border-white/5 text-gray-400 hover:text-white'
                  }`}
                >
                  <div>
                    <div className="font-extrabold text-[10px] uppercase tracking-wide truncate text-white">{mode.label}</div>
                    <p className="text-[9px] text-gray-500 mt-1.5 leading-relaxed line-clamp-3">
                      {mode.desc}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* C. PILIH TYPE AI (TINGKAT KREATIVITAS) */}
          <div className="pt-6 border-t border-white/5 space-y-4">
            <div className="space-y-1">
              <h4 className="text-sm font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2 font-mono">
                ❖ PILIH TYPE AI (TINGKAT KREATIVITAS)
              </h4>
              <p className="text-xs text-gray-400">
                Atur tingkat presisi dan kebebasan berekspresi model AI.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {[
                { id: 'creative', label: 'Creative & Expressive 🔮', desc: 'Sangat ekspresif, puitis, kaya metafora & imajinatif.' },
                { id: 'balanced', label: 'Balanced & Immersive ⚖️', desc: 'Seimbang, realistis, responsif & mengalir alami.' },
                { id: 'precise', label: 'Precise & Direct 🎯', desc: 'Fokus, singkat padat, logis & terarah tanpa bertele-tele.' }
              ].map((type) => (
                <button
                  key={type.id}
                  type="button"
                  onClick={() => setData({ ...data, typeAi: type.id as any })}
                  className={`p-3 rounded-xl border text-left flex flex-col justify-between h-28 transition-all duration-300 cursor-pointer ${
                    data.typeAi === type.id
                      ? 'bg-gradient-to-b from-purple-950/40 to-cyan-950/20 border-cyan-400 text-white shadow-[0_0_15px_rgba(6,182,212,0.15)] scale-[1.02]'
                      : 'bg-black/30 border-white/5 text-gray-400 hover:text-white'
                  }`}
                >
                  <div>
                    <div className="font-extrabold text-[10px] uppercase tracking-wide truncate text-white">{type.label}</div>
                    <p className="text-[9px] text-gray-500 mt-1.5 leading-relaxed line-clamp-2">
                      {type.desc}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* D. Preset Selector */}
          <div className="pt-4 border-t border-white/5 space-y-3">
            <div className="flex justify-between items-center">
              <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5 font-mono">
                <Sparkle size={14} className="animate-pulse text-purple-400" /> Panggil Menggunakan Preset Kreatif
              </h4>
              <span className="text-[10px] text-gray-500">Pilih template untuk mengisi form otomatis</span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {PRESETS.map((p, idx) => {
                const genreConfig = GENRES.find(g => g.id === p.persona);
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => applyPreset(p)}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      activePreset === p.name 
                        ? 'bg-purple-950/40 border-purple-500/50 text-white shadow-[0_0_15px_rgba(168,85,247,0.15)]'
                        : 'bg-black/30 border-white/5 hover:border-purple-500/30 text-gray-400 hover:text-white'
                    }`}
                  >
                    <div className="font-bold text-xs truncate text-white">{p.name}</div>
                    <div className="text-[9px] text-gray-500 mt-0.5 capitalize">{genreConfig?.label || p.persona}</div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Step 2: Basic Identity & Core Attributes */}
      {step === 2 && (
        <div className="space-y-6 animate-fade-in">
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center gap-2">
              <User size={16} className="text-cyan-400" /> Langkah 2: Identitas & Atribut Dasar
            </h3>
            <p className="text-xs text-gray-400">
              Isi nama, gender, dan banner tampilan visual karakter Anda.
            </p>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-start">
              <div className="md:col-span-3">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-2 font-mono">Nama Karakter (Wajib)</label>
                <div className="relative">
                  <input 
                    type="text"
                    required
                    value={data.name}
                    onChange={e => setData({...data, name: e.target.value})}
                    placeholder="Contoh: Valerius Storm, Xera-90, Damian" 
                    className="w-full bg-black/40 border border-white/10 rounded-xl p-3.5 pl-4 text-sm focus:border-cyan-400/50 outline-none transition text-white" 
                  />
                </div>
              </div>
              <div className="md:col-span-1">
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-2 font-mono">Gender</label>
                <select 
                  value={data.gender}
                  onChange={e => setData({...data, gender: e.target.value as any})}
                  className="w-full bg-[#0d0a1c] border border-white/10 rounded-xl p-3.5 text-sm focus:border-cyan-400/50 outline-none transition text-white"
                >
                  <option value="Laki-laki">Laki-laki</option>
                  <option value="Perempuan">Perempuan</option>
                  <option value="Non-biner (Game Master)">Non-biner (Game Master)</option>
                  <option value="Bebas">Bebas</option>
                </select>
              </div>
              <div className="md:col-span-4 flex flex-col p-4 bg-black/40 border border-white/10 rounded-xl relative overflow-hidden group">
                <span className="text-[10px] text-gray-500 uppercase tracking-wider mb-2 font-bold z-10 relative drop-shadow-md font-mono">Profile Karakter (Opsional)</span>
                {data.avatarUrl ? (
                  <div className="space-y-3 mt-1 relative z-0">
                    <div className="w-full h-32 rounded-lg overflow-hidden border border-white/10">
                      <img src={data.avatarUrl} alt="Profile preview" style={{ objectPosition: `center ${data.avatarPosition}%` }} className="w-full h-full object-cover opacity-80" />
                    </div>
                    <div className="flex items-center gap-3 bg-black/40 p-2 rounded-lg border border-white/5">
                      <span className="text-[10px] text-gray-400 font-bold tracking-wider font-mono">POSISI</span>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={data.avatarPosition}
                        onChange={(e) => setData({ ...data, avatarPosition: parseInt(e.target.value) })}
                        className="flex-1 h-1 bg-white/20 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="w-full h-32 rounded-lg border border-dashed border-white/20 bg-white/5 flex flex-col items-center justify-center mt-1 z-0">
                    <img 
                      src={`https://api.dicebear.com/7.x/${
                        data.persona === 'cyberpunk' ? 'bottts' : 
                        data.persona === 'horror' ? 'identicon' : 
                        data.persona === 'detective' ? 'micah' : 'pixel-art'
                      }/svg?seed=${encodeURIComponent(data.name || 'Nova')}`}
                      alt="Avatar default"
                      className="w-12 h-12 rounded-full border border-purple-500/30 bg-purple-950/20 shadow-md mb-2 opacity-50"
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-xs text-gray-500">Klik untuk upload profile</span>
                  </div>
                )}
                <div className={`absolute ${data.avatarUrl ? 'top-2 right-2' : 'inset-0'} flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20 ${!data.avatarUrl && 'bg-black/40 backdrop-blur-sm cursor-pointer'}`}>
                  <label className="cursor-pointer px-4 py-2 bg-purple-600/80 hover:bg-purple-500 text-white text-xs font-bold rounded-lg backdrop-blur-md transition shadow-xl border border-purple-500/30">
                    {data.avatarUrl ? 'Ganti Profile' : 'Upload Profile'}
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                  </label>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 3: Prompt Definition & Personality */}
      {step === 3 && (
        <div className="space-y-6 animate-fade-in">
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center gap-2">
              <FileText size={16} className="text-cyan-400" /> Langkah 3: Definisi Karakter & Kepribadian
            </h3>
            <p className="text-xs text-gray-400">
              Buat prompt spesifikasi mendalam untuk memandu kecerdasan AI dalam memerankan karakter ini secara akurat.
            </p>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1 font-mono">Definisi Karakter</label>
                <p className="text-[10px] text-gray-500 mb-2 leading-tight">Detail cerita, latar belakang, riwayat hidup, penampilan fisik, dan tujuan keberadaan karakter.</p>
                <textarea 
                  rows={5}
                  value={data.background}
                  onChange={e => setData({...data, background: e.target.value})}
                  placeholder="Contoh: AI klandestin yang menduduki server terlantar di lantai terbawah Neo-Jakarta. Diciptakan oleh faksi hacker bawah tanah, ia memiliki rahasia sistem kota yang sangat penting." 
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3.5 text-xs focus:border-cyan-400/50 outline-none transition resize-none text-white leading-relaxed" 
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1 font-mono">Kepribadian</label>
                <p className="text-[10px] text-gray-500 mb-2 leading-tight">Sifat emosional, watak psikologis, kebiasaan unik, kecenderungan sikap, dan temperamen.</p>
                <textarea 
                  rows={5}
                  value={data.personality}
                  onChange={e => setData({...data, personality: e.target.value})}
                  placeholder="Contoh: Dingin, analitis, sangat sarkastik namun diam-diam memiliki empati tersembunyi terhadap organik yang jujur." 
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3.5 text-xs focus:border-cyan-400/50 outline-none transition resize-none text-white leading-relaxed" 
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1 font-mono">Gaya & Format Bicara</label>
                <p className="text-[10px] text-gray-500 mb-2 leading-tight">Gaya vokal, sebutan sapaan khas, logat bahasa, atau tanda penulisan khusus.</p>
                <div className="relative flex items-center bg-black/40 border border-white/10 rounded-xl focus-within:border-cyan-400/50 transition">
                  <span className="pl-3 text-gray-500"><Volume2 size={14} /></span>
                  <input 
                    type="text"
                    value={data.speakingStyle}
                    onChange={e => setData({...data, speakingStyle: e.target.value})}
                    placeholder="Contoh: Bahasa berbasis data, logis, menggunakan tanda kurung siku [ANALYSIS]" 
                    className="w-full bg-transparent p-3.5 text-xs outline-none text-white" 
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 mb-1 font-mono">Sapaan / Dialog Pembuka</label>
                <p className="text-[10px] text-gray-500 mb-2 leading-tight">Skenario dialog pembuka pertama yang diucapkan ketika pertama kali mengobrol.</p>
                <textarea 
                  rows={3}
                  value={data.intro}
                  onChange={e => setData({...data, intro: e.target.value})}
                  placeholder="Contoh: *Koneksi terdeteksi. Protokol pembacaan sidik biner dimulai.* [WARNING]: Identitas Anda tidak terdaftar di mainframe. Katakan, organik, mengapa Anda mengganggu relik digital ini?" 
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3.5 text-xs focus:border-cyan-400/50 outline-none transition resize-none text-white leading-relaxed" 
                />
              </div>
            </div>

            {/* Summary Review Panel */}
            <div className="p-4 bg-purple-600/5 border border-purple-500/10 rounded-xl space-y-2">
              <h4 className="text-xs font-bold text-purple-400 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                <CheckCircle2 size={13} className="text-purple-400" /> Lembar Konfirmasi Ritual
              </h4>
              <p className="text-[11px] text-gray-400 leading-relaxed">
                Anda akan memanggil <span className="text-white font-semibold">{data.name || "Karakter"}</span> sebagai NPC aktif dengan world persona <span className="text-white font-semibold capitalize">{data.persona}</span>, AI Mode <span className="text-cyan-400 font-semibold uppercase">{data.aiMode}</span>, dan tingkat berekspresi <span className="text-cyan-400 font-semibold uppercase">{data.typeAi}</span>.
              </p>
              
              {/* Preview Slot Penyimpanan Karakter */}
              <div className="mt-3 p-3 bg-black/40 border border-cyan-500/20 rounded-lg">
                <h5 className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-mono mb-1 flex items-center gap-1">
                  <Terminal size={10} /> Preview Slot Penyimpanan
                </h5>
                <code className="text-[11px] text-emerald-400 font-mono block break-all">
                  local_storage/rp_chars_new/{data.name ? data.name.toLowerCase().replace(/[^a-z0-9]/g, '') : 'npc'}
                </code>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Buttons Row */}
      <div className="border-t border-white/5 pt-6 flex justify-between items-center">
        <button
          type="button"
          onClick={prevStep}
          disabled={step === 1 || isSubmitting}
          className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition ${
            step === 1 || isSubmitting
              ? 'text-gray-600 cursor-not-allowed opacity-50' 
              : 'bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300'
          }`}
        >
          <ChevronLeft size={14} /> Kembali
        </button>

        {step < 3 ? (
          <button
            type="button"
            onClick={nextStep}
            disabled={(step === 1 && !data.persona) || (step === 2 && !data.name.trim()) || isSubmitting}
            className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition shadow-lg shadow-purple-500/10 cursor-pointer"
          >
            Lanjutkan <ChevronRight size={14} />
          </button>
        ) : (
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!data.name.trim() || isSubmitting}
            className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition shadow-xl shadow-purple-500/25 cursor-pointer"
          >
            <Sparkles size={14} /> {isSubmitting ? "Memanggil..." : "Panggil & Mulai Bermain"}
          </button>
        )}
      </div>

    </div>
  );
}
