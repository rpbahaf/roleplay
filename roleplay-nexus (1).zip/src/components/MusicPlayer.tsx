import React, { useState, useEffect, useRef } from "react";
import {
  Music,
  Play,
  Pause,
  Trash2,
  Disc,
  Volume2,
  Upload,
  Loader2,
  Check,
  VolumeX,
} from "lucide-react";
import { getAllTracks, saveTrack, deleteTrack, MusicTrack } from "../lib/musicDB";

export default function MusicPlayer() {
  const [tracks, setTracks] = useState<Array<{ id: string; name: string; url?: string; isCustom: boolean }>>([]);
  const [selectedTrackId, setSelectedTrackId] = useState<string>("");
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.5);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const customUrlsRef = useRef<Record<string, string>>({});

  // 1. Initialise global Audio instance and load cached custom tracks from IndexedDB
  useEffect(() => {
    audioRef.current = new Audio();
    audioRef.current.loop = true; // Ambient loop mode
    audioRef.current.volume = volume;

    loadAllTracks();

    // Close dropdown on click outside
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleOutsideClick);

    return () => {
      document.removeEventListener("mousedown", handleOutsideClick);
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      // Revoke any created Blob URLs to prevent memory leak
      Object.values(customUrlsRef.current).forEach((url) => {
        URL.revokeObjectURL(url);
      });
    };
  }, []);

  // Sync volume state
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  // Toast auto dismiss
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 4000);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  const loadAllTracks = async () => {
    try {
      const customTracks = await getAllTracks();
      
      // Revoke old blob URLs before generating new ones
      Object.values(customUrlsRef.current).forEach((url) => {
        URL.revokeObjectURL(url);
      });
      customUrlsRef.current = {};

      const customTracksWithUrls = customTracks.map((track) => {
        const objectUrl = URL.createObjectURL(track.data);
        customUrlsRef.current[track.id] = objectUrl;
        return {
          id: track.id,
          name: track.name,
          url: objectUrl,
          isCustom: true,
        };
      });

      setTracks(customTracksWithUrls);

      // Restore previously selected track if it still exists
      const savedTrackId = localStorage.getItem("nova_rp_selected_music_id");
      if (savedTrackId && customTracksWithUrls.some((t) => t.id === savedTrackId)) {
        setSelectedTrackId(savedTrackId);
        if (audioRef.current) {
          const track = customTracksWithUrls.find((t) => t.id === savedTrackId);
          if (track?.url) {
            audioRef.current.src = track.url;
          }
        }
      } else if (customTracksWithUrls.length > 0) {
        setSelectedTrackId(customTracksWithUrls[0].id);
        if (audioRef.current && customTracksWithUrls[0].url) {
          audioRef.current.src = customTracksWithUrls[0].url;
        }
      } else {
        setSelectedTrackId("");
        if (audioRef.current) {
          audioRef.current.src = "";
        }
      }
    } catch (e) {
      console.error("Failed to load tracks from IndexedDB:", e);
    }
  };

  // 2. Play / Pause handle
  const handleTogglePlay = () => {
    if (!audioRef.current || tracks.length === 0) {
      showToast("📢 Silakan unggah musik kustom Anda terlebih dahulu!");
      return;
    }

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch((e) => {
          console.error("Audio playback failed:", e);
          showToast("⚠️ Silakan pilih musik kustom lain atau unggah musik baru.");
        });
    }
  };

  // 3. Track selection handle
  const handleSelectTrack = (trackId: string) => {
    const track = tracks.find((t) => t.id === trackId);
    if (!track || !audioRef.current) return;

    setSelectedTrackId(trackId);
    localStorage.setItem("nova_rp_selected_music_id", trackId);

    const wasPlaying = isPlaying;
    audioRef.current.src = track.url || "";
    
    if (wasPlaying) {
      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch((e) => {
          console.error("Playback transition error:", e);
          setIsPlaying(false);
        });
    }
  };

  // 4. Custom local file upload track (Up to 20MB limit)
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Enforce 20MB size limit (1024 * 1024 * 20 bytes)
    const MAX_SIZE = 1024 * 1024 * 20;
    if (file.size > MAX_SIZE) {
      showToast("❌ File terlalu besar! Ukuran audio maksimal adalah 20MB.");
      return;
    }

    setIsUploading(true);
    try {
      const trackId = `custom-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const cleanName = file.name.replace(/\.[^/.]+$/, ""); // Strip file extension for cleaner look
      
      const newTrack: MusicTrack = {
        id: trackId,
        name: `${cleanName} 🎵`,
        data: file,
        isCustom: true,
      };

      await saveTrack(newTrack);
      
      // Generate objectUrl immediately for instant feedback to bypass state update delays
      const objectUrl = URL.createObjectURL(file);
      customUrlsRef.current[trackId] = objectUrl;

      const trackObj = {
        id: trackId,
        name: `${cleanName} 🎵`,
        url: objectUrl,
        isCustom: true,
      };

      setTracks(prev => {
        const exists = prev.some(t => t.id === trackId);
        if (exists) return prev;
        return [...prev, trackObj];
      });

      // Select and play this track directly without waiting for state re-render cycles!
      setSelectedTrackId(trackId);
      localStorage.setItem("nova_rp_selected_music_id", trackId);

      if (audioRef.current) {
        audioRef.current.src = objectUrl;
        audioRef.current.play()
          .then(() => {
            setIsPlaying(true);
          })
          .catch((err) => {
            console.error("Auto play error:", err);
            setIsPlaying(false);
          });
      }

      showToast("🚀 Berhasil menambahkan musik ke daftar putar!");
    } catch (e) {
      console.error("Failed to save audio file to IndexedDB:", e);
      showToast("❌ Gagal menyimpan file audio ke database lokal.");
    } finally {
      setIsUploading(false);
      e.target.value = ""; // Reset file input
    }
  };

  // 5. Delete custom track
  const handleDeleteTrack = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation(); // Avoid triggering track selection on click
    try {
      // If we are deleting the track currently playing, stop playback first
      if (selectedTrackId === id) {
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current.src = "";
        }
        setIsPlaying(false);
      }

      await deleteTrack(id);
      await loadAllTracks();
      showToast("🗑️ Berhasil menghapus musik kustom.");
    } catch (e) {
      console.error("Failed to delete track from IndexedDB:", e);
      showToast("❌ Gagal menghapus musik.");
    }
  };

  const selectedTrack = tracks.find((t) => t.id === selectedTrackId);

  return (
    <div className="relative" ref={dropdownRef}>
      {/* Floating Mini Music Bar next to roleplay Stage button */}
      <div className="flex items-center gap-1.5 bg-[#0e0a1c] border border-purple-500/30 rounded-xl px-2.5 py-1.5 hover:border-cyan-400/50 transition shadow-inner">
        <button
          onClick={handleTogglePlay}
          className={`p-1 rounded-lg transition shrink-0 ${
            isPlaying
              ? "text-cyan-400 bg-cyan-500/10 hover:bg-cyan-500/20 animate-pulse"
              : "text-gray-400 hover:text-white hover:bg-white/5"
          }`}
          title={isPlaying ? "Jeda Musik" : "Putar Musik"}
        >
          {isPlaying ? (
            <Disc size={15} className="animate-spin text-cyan-400" style={{ animationDuration: "3s" }} />
          ) : (
            <Play size={15} className="fill-gray-400 text-gray-400" />
          )}
        </button>

        {/* Selected Track Name Display Trigger */}
        <button
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          className="flex items-center gap-1.5 max-w-[100px] xs:max-w-[130px] md:max-w-[160px] text-left truncate cursor-pointer focus:outline-none"
        >
          <div className="truncate">
            <p className="text-[9px] text-purple-400 font-mono font-bold leading-none uppercase">
              Ambient Audio
            </p>
            <p className="text-[10px] text-gray-200 truncate leading-tight font-medium mt-0.5">
              {selectedTrack ? selectedTrack.name : "Belum ada lagu"}
            </p>
          </div>
          <Music size={11} className={`text-cyan-400 shrink-0 ${isPlaying ? "animate-bounce" : ""}`} />
        </button>
      </div>

      {/* DROPDOWN OVERLAY SELECTOR (High Opacity Solid Opaque Design) */}
      {isDropdownOpen && (
        <div className="absolute top-full mt-2.5 left-0 z-50 w-64 bg-[#0d091a] border border-purple-500/40 rounded-xl p-4 shadow-[0_10px_35px_rgba(0,0,0,0.9)] space-y-4 animate-fade-in text-left opacity-100">
          <div className="flex justify-between items-center border-b border-white/5 pb-2">
            <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-mono">
              Ambient Player
            </span>
            <span className="text-[8px] text-purple-400 font-mono">Custom Loop</span>
          </div>

          {/* Audio Controls Console */}
          <div className="space-y-3 bg-[#080512] border border-purple-500/15 rounded-lg p-2.5">
            <div className="flex items-center justify-between gap-3">
              <button
                onClick={handleTogglePlay}
                disabled={tracks.length === 0}
                className="p-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-30 text-white rounded-lg transition active:scale-95 flex items-center justify-center min-w-[36px]"
              >
                {isPlaying ? <Pause size={14} /> : <Play size={14} className="fill-white" />}
              </button>

              {/* Volume controller */}
              <div className="flex items-center gap-2 flex-1 min-w-0">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="text-gray-400 hover:text-white transition shrink-0"
                >
                  {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  disabled={tracks.length === 0}
                  onChange={(e) => {
                    const newVol = parseFloat(e.target.value);
                    setVolume(newVol);
                    setIsMuted(false);
                    if (audioRef.current) audioRef.current.volume = newVol;
                  }}
                  className="w-full accent-cyan-400 h-1 bg-gray-800 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
            
            <p className="text-[8px] text-gray-400 italic text-center font-mono truncate">
              Status: {isPlaying ? `Memutar ${selectedTrack ? selectedTrack.name : ""}` : "Jeda / Berhenti"}
            </p>
          </div>

          {/* List of custom tracks */}
          <div className="space-y-1.5 max-h-48 overflow-y-auto pr-0.5 scrollbar-thin">
            <p className="text-[8.5px] font-bold text-purple-400 uppercase tracking-wider pl-1">
              Musik Oleh Player ({tracks.length})
            </p>
            {tracks.length === 0 ? (
              <p className="text-[10px] text-gray-500 italic pl-1 py-4 text-center">
                Belum ada musik. Silakan unggah musik kustom Anda di bawah.
              </p>
            ) : (
              tracks.map((t) => (
                <div
                  key={t.id}
                  onClick={() => handleSelectTrack(t.id)}
                  className={`group flex items-center justify-between p-2 rounded-lg cursor-pointer transition border text-xs ${
                    selectedTrackId === t.id
                      ? "bg-purple-950/40 border-purple-500/50 text-cyan-300 font-semibold"
                      : "bg-[#060410] border-purple-500/10 hover:bg-white/5 text-gray-300 hover:text-white"
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    {selectedTrackId === t.id ? (
                      <Check size={11} className="text-cyan-400 shrink-0" />
                    ) : (
                      <span className="w-1.5 h-1.5 bg-gray-600 rounded-full shrink-0 group-hover:bg-purple-400 transition" />
                    )}
                    <span className="truncate pr-1">{t.name}</span>
                  </div>
                  
                  <button
                    onClick={(e) => handleDeleteTrack(t.id, e)}
                    className="p-1 text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded transition-colors shrink-0"
                    title="Hapus Musik"
                  >
                    <Trash2 size={11} />
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Local file uploader form */}
          <div className="border-t border-white/5 pt-3">
            <label className="relative flex flex-col items-center justify-center p-2.5 border border-dashed border-purple-500/30 hover:border-cyan-400/40 rounded-lg cursor-pointer bg-black/30 hover:bg-black/50 transition active:scale-[0.98]">
              {isUploading ? (
                <div className="flex items-center gap-2 text-[10px] text-cyan-400">
                  <Loader2 size={12} className="animate-spin text-cyan-400" />
                  <span>Mengunggah audio...</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-[10px] text-gray-400">
                  <Upload size={12} className="text-purple-400 animate-pulse" />
                  <span>Tambah Musik Anda (Maks 20MB)</span>
                </div>
              )}
              <input
                type="file"
                accept="audio/*"
                onChange={handleFileUpload}
                disabled={isUploading}
                className="hidden"
              />
            </label>
          </div>
        </div>
      )}

      {/* Embedded Client-side Mini Toast Notification Overlay inside play widget */}
      {toastMessage && (
        <div className="fixed bottom-4 right-4 z-50 bg-[#0d091a] border border-purple-500/30 text-white text-[11px] px-4 py-2.5 rounded-xl shadow-2xl backdrop-blur-md animate-fade-in flex items-center gap-2 opacity-100">
          <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
