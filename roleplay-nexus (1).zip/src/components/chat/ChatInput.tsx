import React from "react";
import { Send, Zap } from "lucide-react";

interface ChatInputProps {
  input: string;
  onChangeInput: (text: string) => void;
  onSendMessage: () => void;
  onContinueWithoutChat: () => void;
  dynamicSuggestions: string[];
  onSelectSuggestion: (text: string) => void;
  loading: boolean;
}

export default function ChatInput({
  input,
  onChangeInput,
  onSendMessage,
  onContinueWithoutChat,
  dynamicSuggestions,
  onSelectSuggestion,
  loading,
}: ChatInputProps) {
  return (
    <>
      {/* Action Suggestion Helpers */}
      <div className="px-3 sm:px-4 py-2 flex flex-col gap-1 border-t border-white/5 bg-black/20 shrink-0">
        <div className="max-w-3xl mx-auto w-full">
          <span className="text-[9px] text-cyan-400 uppercase tracking-widest font-bold font-mono flex items-center gap-1 select-none">
            ✨ REKOMENDASI TINDAKAN (BERDASARKAN KEJADIAN SAAT INI)
          </span>
          <div className="flex gap-2 overflow-x-auto touch-pan-x scrollbar-none py-1 mt-0.5 -mx-1 px-1">
            {dynamicSuggestions.map((helper, i) => (
              <button
                key={i}
                onClick={() => onSelectSuggestion(helper)}
                className="text-[11px] sm:text-[10px] bg-white/5 border border-white/10 hover:border-cyan-400/40 text-gray-200 hover:text-cyan-300 rounded-full px-3.5 py-1.5 shrink-0 transition font-sans cursor-pointer hover:bg-white/10 active:scale-95 min-h-[32px] flex items-center"
              >
                {helper}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Input Bar with Mobile Safe Area Padding */}
      <div className="p-2.5 sm:p-4 pb-[calc(0.65rem+env(safe-area-inset-bottom,0px))] border-t border-white/5 bg-black/40 backdrop-blur-md space-y-2 shrink-0">
        <div className="max-w-3xl mx-auto w-full space-y-2">
          {/* Lanjutkan button row */}
          <div className="flex justify-between items-center px-1 gap-2">
            <span className="text-[9px] sm:text-[10px] text-gray-500 font-mono tracking-wider truncate">
              SIAP MELANJUTKAN ALUR CERITA?
            </span>
            <button
              onClick={onContinueWithoutChat}
              disabled={loading}
              className="px-3 py-1 sm:px-3.5 sm:py-1.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 disabled:opacity-50 text-white font-extrabold text-[10px] sm:text-[11px] rounded-lg transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(16,185,129,0.15)] cursor-pointer active:scale-95 uppercase tracking-wide shrink-0 min-h-[30px]"
            >
              <Zap
                size={11}
                className="text-yellow-300 animate-pulse fill-yellow-300"
              />{" "}
              <span className="hidden xs:inline sm:inline">Lanjutkan Tanpa Chat</span>
              <span className="xs:hidden sm:hidden">Lanjut</span> ➔
            </button>
          </div>

          <div className="relative flex items-center bg-black/50 border border-purple-500/25 rounded-2xl p-2 px-3 focus-within:border-cyan-400/60 shadow-inner transition">
            <textarea
              value={input}
              onChange={(e) => onChangeInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  onSendMessage();
                }
              }}
              rows={Math.min(3, input.split("\n").length || 1)}
              placeholder="Ketik pesan / tindakan *perilaku*..."
              className="flex-1 bg-transparent p-1 outline-none text-[16px] sm:text-sm text-white resize-none scrollbar-none py-1.5 min-h-[36px]"
            />
            <div className="flex items-center gap-1.5 sm:gap-3 pl-1 sm:pl-2 shrink-0">
              <span className="text-[9px] text-purple-400 font-mono hidden md:inline">
                ENC_SECURE
              </span>
              <button
                onClick={onSendMessage}
                disabled={!input.trim() || loading}
                className="p-2.5 sm:p-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-50 rounded-xl text-white shadow-lg transition cursor-pointer min-w-[40px] min-h-[40px] flex items-center justify-center active:scale-90"
                title="Kirim Pesan"
              >
                <Send size={15} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
