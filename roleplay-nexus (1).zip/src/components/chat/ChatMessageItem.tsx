import React from "react";
import {
  ThumbsUp,
  ThumbsDown,
  RotateCw,
  Copy,
  Check,
  Volume2,
  Edit3,
  Download,
} from "lucide-react";
import { Message, Character } from "../../types";

interface ChatMessageItemProps {
  message: Message;
  character: Character;
  userPhotoUrl?: string;
  isEditing: boolean;
  editingText: string;
  onStartEdit: (msg: Message) => void;
  onCancelEdit: () => void;
  onSaveEdit: (msgId: string) => void;
  onChangeEditingText: (text: string) => void;
  feedback?: "up" | "down";
  onFeedback: (msgId: string, type: "up" | "down") => void;
  onRegenerate?: (msgId: string) => void;
  isCopied: boolean;
  onCopy: (content: string, msgId: string) => void;
  isSpeaking: boolean;
  onSpeak: (content: string, msgId: string) => void;
  messageImage?: { url: string; loading: boolean; prompt: string };
  loadingNpcResponse?: boolean;
}

export default function ChatMessageItem({
  message,
  character,
  userPhotoUrl,
  isEditing,
  editingText,
  onStartEdit,
  onCancelEdit,
  onSaveEdit,
  onChangeEditingText,
  feedback,
  onFeedback,
  onRegenerate,
  isCopied,
  onCopy,
  isSpeaking,
  onSpeak,
  messageImage,
  loadingNpcResponse,
}: ChatMessageItemProps) {
  const isUser = message.role === "user";

  const defaultAvatar = `https://api.dicebear.com/7.x/${
    character.persona === "cyberpunk"
      ? "bottts"
      : character.persona === "horror"
      ? "identicon"
      : character.persona === "detective"
      ? "micah"
      : "pixel-art"
  }/svg?seed=${encodeURIComponent(character.name)}`;

  return (
    <div
      className={`flex gap-3 md:gap-4 max-w-4xl mx-auto w-full group ${
        isUser ? "flex-row-reverse" : "flex-row"
      }`}
    >
      {/* Avatar Icon */}
      <div className="shrink-0 pt-0.5">
        {isUser ? (
          <img
            src={
              userPhotoUrl ||
              "https://api.dicebear.com/7.x/bottts/svg?seed=user_avatar"
            }
            alt="User"
            className="w-8 h-8 rounded-full border border-purple-500/30 object-cover shadow-sm"
          />
        ) : (
          <img
            src={character.avatarUrl || defaultAvatar}
            alt={character.name}
            className="w-8 h-8 rounded-xl border border-cyan-500/30 object-cover shadow-sm"
            referrerPolicy="no-referrer"
          />
        )}
      </div>

      {/* Main Content Bubble / Gemini Layout */}
      <div
        className={`flex-1 min-w-0 flex flex-col ${
          isUser ? "items-end" : "items-start"
        }`}
      >
        {/* Name and Timestamp Label */}
        <div className="flex items-center gap-2 mb-1 px-1">
          <span className="text-xs font-bold text-gray-300">
            {isUser ? "Anda (Petualang)" : character.name}
          </span>
          <span className="text-[10px] text-gray-500 font-mono">
            {message.timestamp
              ? new Date(message.timestamp).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                })
              : ""}
          </span>
        </div>

        {/* Bubble */}
        {isUser ? (
          <div className="max-w-[85%] sm:max-w-[75%] space-y-1">
            {isEditing ? (
              <div className="bg-[#19142b] border border-cyan-500/40 rounded-2xl p-3 space-y-2 shadow-lg">
                <textarea
                  value={editingText}
                  onChange={(e) => onChangeEditingText(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none resize-none focus:border-cyan-400"
                  rows={3}
                />
                <div className="flex justify-end gap-2 text-xs">
                  <button
                    onClick={onCancelEdit}
                    className="px-3 py-1 bg-white/5 hover:bg-white/10 text-gray-300 rounded-lg cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    onClick={() => onSaveEdit(message.id)}
                    className="px-3 py-1 bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-bold rounded-lg cursor-pointer"
                  >
                    Simpan & Kirim Ulang
                  </button>
                </div>
              </div>
            ) : (
              <div className="relative group/userBubble">
                <div className="p-3.5 bg-gradient-to-br from-purple-900/60 to-purple-950/80 border border-purple-500/25 rounded-2xl rounded-tr-sm text-gray-100 text-xs sm:text-sm leading-relaxed shadow-md backdrop-blur-sm whitespace-pre-wrap">
                  {message.content}
                </div>
                {/* User Message Action buttons */}
                <div className="absolute right-0 -bottom-6 hidden group-hover/userBubble:flex items-center gap-1 bg-[#0e0a1c] border border-white/10 rounded-lg p-0.5 shadow-lg">
                  <button
                    onClick={() => onStartEdit(message)}
                    className="p-1 hover:bg-white/10 text-gray-400 hover:text-white rounded"
                    title="Edit dan Kirim Ulang"
                  >
                    <Edit3 size={12} />
                  </button>
                  <button
                    onClick={() => onCopy(message.content, message.id)}
                    className="p-1 hover:bg-white/10 text-gray-400 hover:text-white rounded"
                    title="Salin"
                  >
                    {isCopied ? <Check size={12} className="text-cyan-400" /> : <Copy size={12} />}
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="w-full space-y-2">
            {/* Split formatting for asterisks (*action*) and quotes ("dialogue") */}
            <div className="space-y-2 text-left">
              {(() => {
                const parts = message.content
                  .split(/(\*[^*]+\*|"[^"]+"|[^\n]+)/g)
                  .filter((part) => part && part.trim() !== "");

                // Keep track of the current/last seen speaker tag
                let currentSpeaker: { type: 'gm' | 'npc' | 'monster', name: string } | null = null;

                // Function to parse speaker tags
                const getSpeaker = (txt: string) => {
                  const bracketMatch = txt.match(/\[(GM|NPC|MONSTER)(?:\s*-\s*([^\]]+))?\]/i);
                  if (bracketMatch) {
                    const type = bracketMatch[1].toLowerCase() as 'gm' | 'npc' | 'monster';
                    const name = bracketMatch[2] ? bracketMatch[2].trim() : (type === 'gm' ? 'Game Master' : character.name);
                    return { type, name };
                  }

                  const colonMatch = txt.match(/^\s*(Game\s*Master|GM|Monster|NPC|[\w\s-]+)\s*:/i);
                  if (colonMatch) {
                    const rawName = colonMatch[1].trim();
                    const lowerName = rawName.toLowerCase();
                    if (lowerName === 'gm' || lowerName === 'game master') {
                      return { type: 'gm' as const, name: 'Game Master' };
                    }
                    if (lowerName.includes('monster') || lowerName.includes('slime') || lowerName.includes('goblin') || lowerName.includes('dragon') || lowerName.includes('beast') || lowerName.includes('demon')) {
                      return { type: 'monster' as const, name: rawName };
                    }
                    return { type: 'npc' as const, name: rawName };
                  }

                  return null;
                };

                return parts.map((part, idx) => {
                  const trimmed = part.trim();
                  const isAction = trimmed.startsWith("*") && trimmed.endsWith("*") && trimmed.length > 2;
                  const isDialogue = trimmed.startsWith('"') && trimmed.endsWith('"') && trimmed.length > 2;

                  if (isAction) {
                    const cleanText = part.slice(1, -1).trim();
                    return (
                      <div
                        key={idx}
                        className="border-l-2 border-purple-500/40 pl-3 py-1.5 bg-purple-950/15 rounded-r text-gray-300 font-sans italic text-[13px] sm:text-[13.5px] leading-relaxed shadow-sm"
                      >
                        <span className="text-[9px] uppercase tracking-wider font-bold text-purple-400 block mb-0.5 not-italic font-mono select-none">
                          ❖ Narasi / Perilaku (Sistem)
                        </span>
                        *{cleanText}*
                      </div>
                    );
                  }

                  if (isDialogue) {
                    let cleanText = part.slice(1, -1).trim();
                    
                    // Parse if the speaker is defined inside the dialogue itself
                    let localSpeaker = getSpeaker(cleanText);
                    if (localSpeaker) {
                      // Strip the speaker prefix inside the text e.g. "[GM]: " or "GM: "
                      cleanText = cleanText.replace(/^\[(GM|NPC|MONSTER)(?:\s*-\s*([^\]]+))?\]\s*:\s*/i, "");
                      cleanText = cleanText.replace(/^\s*(Game\s*Master|GM|Monster|NPC|[\w\s-]+)\s*:\s*/i, "");
                    } else if (currentSpeaker) {
                      localSpeaker = currentSpeaker;
                    } else {
                      // Fallback
                      const isGmChar = character.name.toLowerCase().includes("game master") || character.aiMode === "gamemaster";
                      localSpeaker = {
                        type: isGmChar ? 'npc' : 'npc',
                        name: isGmChar ? '???' : character.name,
                      };
                    }

                    // Reset currentSpeaker after dialogue consumption to prevent leakage to next quotes
                    currentSpeaker = null;

                    // Choose styling based on speaker type
                    let containerClass = "p-3 rounded-xl leading-relaxed shadow-sm flex flex-col gap-1.5 border ";
                    let badgeClass = "text-[9px] uppercase tracking-wider font-mono font-extrabold px-2 py-0.5 rounded-md inline-block max-w-max select-none ";
                    let badgeLabel = "";

                    if (localSpeaker.type === 'gm') {
                      containerClass += "bg-purple-950/10 border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.05)]";
                      badgeClass += "bg-purple-500/20 text-purple-300 border border-purple-500/30";
                      badgeLabel = `🔮 Game Master (GM)`;
                    } else if (localSpeaker.type === 'monster') {
                      containerClass += "bg-red-950/10 border-red-500/30 text-red-200 shadow-[0_0_15px_rgba(239,68,68,0.05)]";
                      badgeClass += "bg-red-500/20 text-red-300 border border-red-500/30";
                      badgeLabel = `👿 Monster: ${localSpeaker.name}`;
                    } else {
                      containerClass += "bg-cyan-950/10 border-cyan-500/20 text-cyan-200";
                      badgeClass += "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30";
                      badgeLabel = `👤 NPC: ${localSpeaker.name}`;
                    }

                    return (
                      <div key={idx} className={containerClass}>
                        <div className="flex justify-between items-center">
                          <span className={badgeClass}>{badgeLabel}</span>
                        </div>
                        <span className="relative pl-1 text-[13.5px] sm:text-[14.5px] font-semibold tracking-wide">
                          “{cleanText}”
                        </span>
                      </div>
                    );
                  }

                  // It's a plain text part (like the speaker tag before a quote)
                  const speaker = getSpeaker(trimmed);
                  if (speaker) {
                    currentSpeaker = speaker;
                    // If the line consists ONLY of the speaker prefix (e.g. "[GM]:" or "GM:"), hide it to prevent raw text clutter!
                    const isOnlyTag = /^(?:\[(GM|NPC|MONSTER)(?:\s*-\s*([^\]]+))?\]|Game\s*Master|GM|Monster|NPC|[\w\s-]+)\s*:\s*$/i.test(trimmed);
                    if (isOnlyTag) {
                      return null;
                    }
                  }

                  // Otherwise render as a plain text or RPG reward block
                  const isReward =
                    part.includes("+") &&
                    (part.toUpperCase().includes("XP") ||
                      part.toUpperCase().includes("KOIN") ||
                      part.toUpperCase().includes("COIN") ||
                      part.toUpperCase().includes("LOOT") ||
                      part.toUpperCase().includes("ITEM"));

                  return (
                    <div
                      key={idx}
                      className={`p-2.5 rounded-xl text-[13px] sm:text-[14px] leading-relaxed font-sans ${
                        isReward
                          ? "bg-amber-500/10 border border-amber-500/25 text-amber-300 font-bold"
                          : "text-gray-300 bg-white/5 border border-white/5"
                      }`}
                    >
                      {isReward ? (
                        <div className="flex items-center gap-1.5 text-[9px] font-mono text-amber-400 uppercase tracking-widest font-extrabold mb-1 select-none">
                          🎁 RPG Reward Sistem
                        </div>
                      ) : null}
                      {part}
                    </div>
                  );
                });
              })()}
            </div>

            {/* Gemini Action Bar */}
            <div className="flex items-center gap-1 sm:gap-2 text-gray-400 pt-1">
              <button
                onClick={() => onFeedback(message.id, "up")}
                className={`p-2 sm:p-1.5 rounded-lg transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90 ${
                  feedback === "up"
                    ? "text-emerald-400 bg-emerald-500/10"
                    : "hover:text-gray-200 hover:bg-white/5"
                }`}
                title="Suka respons ini"
              >
                <ThumbsUp size={16} className={feedback === "up" ? "fill-emerald-400/20" : ""} />
              </button>
              <button
                onClick={() => onFeedback(message.id, "down")}
                className={`p-2 sm:p-1.5 rounded-lg transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90 ${
                  feedback === "down"
                    ? "text-rose-400 bg-rose-500/10"
                    : "hover:text-gray-200 hover:bg-white/5"
                }`}
                title="Kurang suka respons ini"
              >
                <ThumbsDown
                  size={16}
                  className={feedback === "down" ? "fill-rose-400/20" : ""}
                />
              </button>
              {onRegenerate && (
                <button
                  onClick={() => onRegenerate(message.id)}
                  disabled={loadingNpcResponse}
                  className="p-2 sm:p-1.5 rounded-lg hover:text-gray-200 hover:bg-white/5 transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90 disabled:opacity-50"
                  title="Regenerasi balasan ini"
                >
                  <RotateCw
                    size={16}
                    className={loadingNpcResponse ? "animate-spin text-cyan-400" : ""}
                  />
                </button>
              )}
              <button
                onClick={() => onCopy(message.content, message.id)}
                className={`p-2 sm:p-1.5 rounded-lg transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90 ${
                  isCopied ? "text-cyan-400 bg-cyan-500/10" : "hover:text-gray-200 hover:bg-white/5"
                }`}
                title={isCopied ? "Tersalin!" : "Salin pesan"}
              >
                {isCopied ? <Check size={16} /> : <Copy size={16} />}
              </button>
              <button
                onClick={() => onSpeak(message.content, message.id)}
                className="p-2 sm:p-1.5 rounded-lg hover:text-gray-200 hover:bg-white/5 transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90"
                title="Putar suara text-to-speech"
              >
                <Volume2
                  size={16}
                  className={isSpeaking ? "text-green-400 animate-pulse" : ""}
                />
              </button>
            </div>

            {/* Generated AI Image attachment if any */}
            {messageImage && (
              <div className="mt-3 border-t border-white/5 pt-3">
                <div className="relative aspect-video max-w-lg rounded-xl overflow-hidden border border-white/10 bg-black/40 group">
                  {messageImage.loading ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/60">
                      <RotateCw size={18} className="animate-spin text-amber-500" />
                      <span className="text-[10px] text-gray-400 font-mono">
                        Memvisualisasikan adegan...
                      </span>
                    </div>
                  ) : (
                    <>
                      <img
                        src={messageImage.url}
                        alt="Visualisasi Adegan"
                        className="w-full h-full object-cover transition duration-300 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-3 flex flex-col justify-end">
                        <p className="text-[10px] text-gray-300 line-clamp-1 italic">
                          {messageImage.prompt}
                        </p>
                        <a
                          href={messageImage.url}
                          download={`nova_rpg_${Date.now()}.png`}
                          className="mt-1 text-[9px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono"
                        >
                          <Download size={10} /> Unduh Ilustrasi
                        </a>
                      </div>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
