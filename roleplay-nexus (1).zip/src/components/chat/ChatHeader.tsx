import React from "react";
import { ArrowLeft, Menu, RefreshCw, UserCheck, Shield } from "lucide-react";
import { Character } from "../../types";

interface ChatHeaderProps {
  character: Character;
  onBack: () => void;
  onOpenMobileSidebar?: () => void;
  onToggleMobileDetails: () => void;
  onResetChat: () => void;
  loading: boolean;
}

export default function ChatHeader({
  character,
  onBack,
  onOpenMobileSidebar,
  onToggleMobileDetails,
  onResetChat,
  loading,
}: ChatHeaderProps) {
  const defaultAvatar = `https://api.dicebear.com/7.x/${
    character.persona === "cyberpunk"
      ? "bottts"
      : character.persona === "horror"
      ? "identicon"
      : character.persona === "detective"
      ? "micah"
      : "pixel-art"
  }/svg?seed=${encodeURIComponent(character.name)}`;

  return (
    <div className="h-16 border-b border-white/10 px-4 md:px-6 flex items-center justify-between bg-black/40 backdrop-blur-md shrink-0 z-10">
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onBack}
          className="p-2 hover:bg-white/5 border border-white/10 rounded-xl text-gray-400 hover:text-white transition shrink-0 cursor-pointer"
          title="Kembali ke Galeri Karakter"
        >
          <ArrowLeft size={16} />
        </button>

        {onOpenMobileSidebar && (
          <button
            onClick={onOpenMobileSidebar}
            className="p-2 md:hidden hover:bg-white/5 border border-purple-500/20 rounded-xl text-gray-300 hover:text-white transition shrink-0 cursor-pointer"
            title="Daftar Karakter"
          >
            <Menu size={16} />
          </button>
        )}

        <div className="flex items-center gap-3 min-w-0">
          <div className="relative shrink-0">
            <img
              src={character.avatarUrl || defaultAvatar}
              alt={character.name}
              className="w-9 h-9 rounded-xl object-cover border border-purple-500/30"
              referrerPolicy="no-referrer"
            />
            <span
              className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-[#0d0e14] ${
                loading ? "bg-amber-400 animate-ping" : "bg-emerald-400"
              }`}
            />
          </div>
          <div className="truncate">
            <h3 className="font-black text-sm text-white truncate flex items-center gap-1.5">
              {character.name}
              <span className="text-[8px] px-1.5 py-0.2 rounded font-mono font-bold uppercase bg-purple-500/10 text-purple-300 border border-purple-500/20">
                {character.persona}
              </span>
            </h3>
            <span className="text-[10px] text-cyan-400 font-mono block leading-none truncate">
              {loading ? "BERPIKIR & MERUMUSKAN TAKDIR..." : "MENUNGGU TINDAKAN ANDA"}
            </span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onResetChat}
          className="p-2 hover:bg-white/5 border border-white/10 rounded-xl text-gray-400 hover:text-white transition cursor-pointer"
          title="Reset Sesi Obrolan Ini"
        >
          <RefreshCw size={15} />
        </button>

        <button
          onClick={onToggleMobileDetails}
          className="p-2 lg:hidden hover:bg-white/5 border border-white/10 rounded-xl text-cyan-400 transition cursor-pointer"
          title="Detail & Log"
        >
          <Shield size={16} />
        </button>
      </div>
    </div>
  );
}
