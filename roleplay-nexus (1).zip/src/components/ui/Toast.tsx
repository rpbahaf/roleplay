import { Sparkles } from "lucide-react";

interface ToastProps {
  message: string | null;
  onClose?: () => void;
}

export default function Toast({ message }: ToastProps) {
  if (!message) return null;

  return (
    <div className="fixed top-4 right-4 z-50 bg-[#0e0a1c]/90 border border-cyan-500/30 text-cyan-300 text-xs px-4 py-3 rounded-xl shadow-[0_0_15px_rgba(6,182,212,0.25)] backdrop-blur-md flex items-center gap-2.5 animate-fade-in transition-all">
      <span className="relative flex h-2 w-2">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
        <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
      </span>
      <Sparkles size={12} className="text-cyan-400 animate-pulse shrink-0" />
      <span className="font-sans font-medium">{message}</span>
    </div>
  );
}
