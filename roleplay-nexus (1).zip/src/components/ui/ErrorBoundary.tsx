import * as React from "react";
import { ShieldAlert, RefreshCw, LogOut } from "lucide-react";

interface Props {
  children?: React.ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
}

export default class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
    this.setState({ errorInfo });
  }

  private handleReset = () => {
    // Clear potentially corrupted layout state
    localStorage.removeItem("nova_rp_settings");
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen w-full bg-[#07050e] text-gray-100 flex flex-col items-center justify-center p-6 font-mono relative overflow-hidden">
          {/* Background grid */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#140d2b_1px,transparent_1px),linear-gradient(to_bottom,#140d2b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] opacity-30 pointer-events-none" />

          {/* Glowing ambient lights */}
          <div className="absolute top-1/4 left-1/4 w-[300px] h-[300px] bg-red-500/10 rounded-full blur-[100px] pointer-events-none animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-[300px] h-[300px] bg-purple-500/10 rounded-full blur-[100px] pointer-events-none animate-pulse" />

          <div className="max-w-lg w-full bg-[#120a21]/80 border border-red-500/30 rounded-2xl p-6 md:p-8 space-y-6 shadow-[0_0_50px_rgba(239,68,68,0.15)] z-10 backdrop-blur-md">
            <div className="flex items-center gap-3 border-b border-red-500/20 pb-4">
              <div className="p-3 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl animate-pulse">
                <ShieldAlert size={24} />
              </div>
              <div>
                <span className="text-[10px] text-red-400 uppercase tracking-widest font-bold">
                  [SYSTEM FAULT DETECTED]
                </span>
                <h2 className="text-lg font-black text-white tracking-tight uppercase">
                  Anomali Gerbang Dimensi
                </h2>
              </div>
            </div>

            <p className="text-xs text-gray-400 leading-relaxed">
              Modul biner Nova RP mengalami gangguan rendering akibat tumpang tindih energi partikel. Tenang, memori astral Anda tetap aman di inkubator localStorage.
            </p>

            <div className="bg-black/40 border border-red-500/10 rounded-xl p-4 text-[11px] text-red-300 overflow-x-auto max-h-40 font-mono space-y-1">
              <p className="font-bold text-red-400">ERROR MESSAGE:</p>
              <p>{this.state.error?.toString() || "Unknown rendering anomaly"}</p>
              {this.state.errorInfo && (
                <pre className="text-gray-500 text-[10px] whitespace-pre-wrap leading-normal">
                  {this.state.errorInfo.componentStack}
                </pre>
              )}
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={() => window.location.reload()}
                className="flex-1 py-3 px-4 bg-gradient-to-r from-purple-700 to-indigo-600 hover:from-purple-600 hover:to-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-purple-500/15"
              >
                <RefreshCw size={14} /> Muat Ulang Halaman
              </button>
              <button
                onClick={this.handleReset}
                className="flex-1 py-3 px-4 bg-red-950/20 border border-red-500/20 hover:bg-red-500 hover:text-white text-red-400 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogOut size={14} /> Atur Ulang & Masuk
              </button>
            </div>

            <div className="text-[9px] text-gray-500 text-center font-mono uppercase tracking-widest">
              Nova Recovery Console • Error Code: 0x50F
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
