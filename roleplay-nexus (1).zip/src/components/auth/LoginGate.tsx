import React, { useState } from "react";
import { Shield, Brain, Sparkle, LogIn } from "lucide-react";

interface LoginGateProps {
  onLogin: (user: { uid: string; displayName: string; photoURL?: string }) => void;
}

export default function LoginGate({ onLogin }: LoginGateProps) {
  const [loginName, setLoginName] = useState("");
  const [loginPhotoUrl, setLoginPhotoUrl] = useState("");

  const handleUserImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement("canvas");
          let width = img.width;
          let height = img.height;
          const MAX_SIZE = 256;
          if (width > height && width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          } else if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext("2d");
          if (ctx) {
            ctx.drawImage(img, 0, 0, width, height);
            const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
            setLoginPhotoUrl(dataUrl);
          }
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = () => {
    if (!loginName.trim()) return;
    const uid = loginName
      .trim()
      .toLowerCase()
      .replace(/[^a-zA-Z0-9_-]/g, "_");
    const newUser = {
      uid,
      displayName: loginName.trim(),
      photoURL:
        loginPhotoUrl.trim() ||
        `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(uid)}`,
    };
    onLogin(newUser);
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-[#07050e] text-gray-100 font-sans p-6 relative overflow-hidden">
      {/* Ambient lighting effects */}
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-purple-600/15 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-2xl w-full space-y-8 text-center z-10">
        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-500/10 border border-cyan-500/20 rounded-full text-cyan-400 text-xs font-semibold uppercase tracking-wider">
            <Shield size={12} className="animate-pulse" /> Neural Engine Portal
          </div>
          <h1 className="text-5xl md:text-6xl font-black tracking-tighter bg-gradient-to-r from-cyan-400 via-purple-400 to-white bg-clip-text text-transparent">
            NOVA RP
          </h1>
          <p className="text-gray-300 text-sm md:text-base max-w-lg mx-auto leading-relaxed">
            Dunia bermain peran berbasis kecerdasan buatan paling imersif.
            Setiap skenario, tindakan, dan enkripsi memori dikelola langsung
            untuk Anda.
          </p>
        </div>

        {/* Feature Bento Showcase */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
          <div className="p-5 bg-[#140e29]/40 border border-purple-500/15 rounded-xl space-y-2 hover:border-cyan-500/30 transition-all">
            <Brain className="text-cyan-400" size={20} />
            <h3 className="text-xs font-bold uppercase tracking-wider text-white">
              6 Persona Dunia
            </h3>
            <p className="text-[11px] text-gray-400 leading-relaxed">
              Pilih genre Fantasi, Modern, Cyberpunk, Abad Pertengahan, Noir
              Detektif, atau Horor Psikologis.
            </p>
          </div>
          <div className="p-5 bg-[#140e29]/40 border border-purple-500/15 rounded-xl space-y-2 hover:border-cyan-500/30 transition-all">
            <Shield className="text-cyan-400" size={20} />
            <h3 className="text-xs font-bold uppercase tracking-wider text-white">
              Secure Encrypted
            </h3>
            <p className="text-[11px] text-gray-400 leading-relaxed">
              Semua dialog disandikan dengan modul scrambling AES-B64 untuk
              menjamin privasi absolut.
            </p>
          </div>
          <div className="p-5 bg-[#140e29]/40 border border-purple-500/15 rounded-xl space-y-2 hover:border-cyan-500/30 transition-all">
            <Sparkle className="text-purple-400" size={20} />
            <h3 className="text-xs font-bold uppercase tracking-wider text-white">
              Custom Summon
            </h3>
            <p className="text-[11px] text-gray-400 leading-relaxed">
              Rancang latar belakang, gaya bicara, dan keahlian khusus karakter
              pendamping Anda.
            </p>
          </div>
        </div>

        <div className="p-6 bg-[#0f0d1a]/80 border border-purple-500/20 rounded-2xl max-w-md mx-auto space-y-4 shadow-2xl backdrop-blur-md">
          <p className="text-xs text-gray-400 leading-relaxed">
            Tuliskan nama peran atau nama panggilan Anda untuk mengakses &amp;
            menyimpan seluruh karakter kustom dan memori langsung di server.
          </p>

          <div className="flex flex-col items-center space-y-2 pb-2">
            <div className="relative group w-16 h-16 rounded-full overflow-hidden border-2 border-purple-500/40 hover:border-cyan-400 transition-all shadow-[0_0_15px_rgba(168,85,247,0.2)]">
              <img
                src={
                  loginPhotoUrl ||
                  `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(
                    loginName.trim() || "default"
                  )}`
                }
                alt="Preview Avatar"
                className="w-full h-full object-cover"
              />
              <label className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-[9px] text-white font-bold cursor-pointer transition-opacity">
                Upload Foto
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleUserImageUpload}
                />
              </label>
            </div>
            <span className="text-[9px] text-gray-500 font-mono">
              Pratinjau Avatar Petualang
            </span>
          </div>

          <div className="space-y-3.5 text-left">
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest pl-1">
                Nama Petualang (Wajib)
              </label>
              <input
                type="text"
                placeholder="cth: Valerius, Rizal, Petualang..."
                value={loginName}
                onChange={(e) => setLoginName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && loginName.trim()) handleSubmit();
                }}
                className="w-full bg-black/40 border border-purple-500/20 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-cyan-400/50 transition-all font-mono"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-purple-400 uppercase tracking-widest pl-1">
                Atau Tempel Link Avatar (Opsional)
              </label>
              <input
                type="text"
                placeholder="https://link-gambar.com/foto.jpg"
                value={loginPhotoUrl}
                onChange={(e) => setLoginPhotoUrl(e.target.value)}
                className="w-full bg-black/40 border border-purple-500/20 rounded-xl px-4 py-3 text-xs text-white outline-none focus:border-purple-400/50 transition-all font-mono"
              />
            </div>
          </div>

          <button
            onClick={handleSubmit}
            disabled={!loginName.trim()}
            className="w-full py-3.5 px-6 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-50 text-white rounded-xl flex items-center justify-center gap-3 text-sm font-bold shadow-[0_0_20px_rgba(168,85,247,0.25)] hover:shadow-[0_0_25px_rgba(6,182,212,0.35)] transition-all duration-300 cursor-pointer"
          >
            <LogIn size={18} /> Mulai Berpetualang
          </button>
        </div>

        <div className="text-[10px] text-gray-500 font-mono">
          SECURE STAGE • HOST RUNNING ON PORT 3000
        </div>
      </div>
    </div>
  );
}
