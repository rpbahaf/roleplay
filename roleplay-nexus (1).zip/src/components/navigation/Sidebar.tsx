import React from "react";
import { Sparkle, Menu, X, UserPlus, Settings as SettingsIcon } from "lucide-react";
import { Character } from "../../types";

interface SidebarProps {
  isOpen: boolean;
  isCollapsed: boolean;
  onClose: () => void;
  onToggleCollapse: () => void;
  characters: Character[];
  selectedCharacter: Character | null;
  onSelectCharacter: (char: Character) => void;
  onNewChat: () => void;
  user: { uid: string; displayName: string; photoURL?: string };
  onOpenSettings: () => void;
}

export default function Sidebar({
  isOpen,
  isCollapsed,
  onClose,
  onToggleCollapse,
  characters,
  selectedCharacter,
  onSelectCharacter,
  onNewChat,
  user,
  onOpenSettings,
}: SidebarProps) {
  return (
    <>
      {/* Mobile Drawer Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 md:hidden transition-all"
          onClick={onClose}
        />
      )}

      <aside
        className={`
          fixed inset-y-0 left-0 z-50 bg-[#0e0a1b] border-r border-purple-950/40 flex flex-col shrink-0
          transform transition-all duration-300 ease-in-out md:static md:translate-x-0
          ${isCollapsed ? "w-20" : "w-72"}
          ${isOpen ? "translate-x-0 shadow-[5px_0_25px_rgba(0,0,0,0.5)] w-72" : "-translate-x-full md:translate-x-0"}
        `}
      >
        {/* Brand Lockup Header */}
        <div className="p-4 py-6 border-b border-purple-950/20 flex items-center justify-between">
          {!isCollapsed ? (
            <div className="flex items-center gap-2.5 truncate">
              <Sparkle size={20} className="text-cyan-400 animate-spin-slow shrink-0" />
              <div className="truncate">
                <h1 className="text-xl font-black tracking-tighter bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent leading-none">
                  NOVA RP
                </h1>
                <span className="text-[8px] text-purple-400/80 uppercase tracking-widest leading-none mt-1.5 block font-mono">
                  Engine v3.0
                </span>
              </div>
            </div>
          ) : (
            <div className="mx-auto">
              <Sparkle size={20} className="text-cyan-400 animate-spin-slow" />
            </div>
          )}

          {/* Collapse/Expand Toggle Button */}
          {!isCollapsed ? (
            <button
              onClick={onToggleCollapse}
              className="hidden md:flex p-1.5 hover:bg-white/5 border border-purple-500/20 rounded-lg text-gray-400 hover:text-white transition shrink-0 cursor-pointer"
              title="Sembunyikan Menu"
            >
              <Menu size={16} />
            </button>
          ) : (
            <button
              onClick={onToggleCollapse}
              className="hidden md:flex absolute top-6 right-5 p-1.5 hover:bg-white/5 border border-purple-500/20 rounded-lg text-gray-400 hover:text-white transition shrink-0 cursor-pointer"
              title="Tampilkan Menu"
            >
              <Menu size={16} />
            </button>
          )}

          {/* Mobile close button */}
          <button
            onClick={onClose}
            className="p-1.5 bg-white/5 border border-purple-500/20 rounded-lg text-gray-400 hover:text-white md:hidden transition shrink-0"
            title="Tutup Menu"
          >
            <X size={16} />
          </button>
        </div>

        {/* New Chat Button */}
        <div className="p-4 shrink-0">
          {!isCollapsed ? (
            <button
              onClick={onNewChat}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-purple-600/30 to-cyan-500/30 hover:from-purple-600 hover:to-cyan-500 text-white rounded-full flex items-center justify-center gap-2 text-xs border border-purple-400/20 hover:border-cyan-400/30 transition shadow-lg cursor-pointer font-bold whitespace-nowrap"
            >
              <UserPlus size={14} /> Percakapan baru
            </button>
          ) : (
            <button
              onClick={onNewChat}
              className="mx-auto w-10 h-10 bg-gradient-to-r from-purple-600/30 to-cyan-500/30 hover:from-purple-600 hover:to-cyan-500 text-white rounded-full flex items-center justify-center border border-purple-400/20 transition cursor-pointer"
              title="Percakapan baru"
            >
              <UserPlus size={16} />
            </button>
          )}
        </div>

        {/* Recent Conversations List */}
        <div className="flex-1 overflow-y-auto px-4 py-2 space-y-4">
          {!isCollapsed && (
            <div className="space-y-2">
              <span className="text-[10px] text-gray-500 font-bold uppercase tracking-wider font-mono block px-2">
                Terbaru
              </span>
              <div className="space-y-1">
                {characters.slice(0, 8).map((char) => {
                  const isSelected = selectedCharacter?.id === char.id;
                  return (
                    <button
                      key={char.id}
                      onClick={() => onSelectCharacter(char)}
                      className={`w-full p-2 rounded-xl flex items-center gap-2.5 text-xs transition text-left cursor-pointer truncate ${
                        isSelected
                          ? "bg-purple-600/20 border border-purple-500/30 text-white font-bold"
                          : "text-gray-400 hover:text-white hover:bg-white/5"
                      }`}
                    >
                      <img
                        src={
                          char.avatarUrl ||
                          `https://api.dicebear.com/7.x/pixel-art/svg?seed=${encodeURIComponent(
                            char.name
                          )}`
                        }
                        alt=""
                        className="w-5 h-5 rounded-lg object-cover shrink-0"
                      />
                      <span className="truncate">{char.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          {isCollapsed && (
            <div className="flex flex-col items-center gap-2 pt-2">
              {characters.slice(0, 8).map((char) => {
                const isSelected = selectedCharacter?.id === char.id;
                return (
                  <button
                    key={char.id}
                    onClick={() => onSelectCharacter(char)}
                    className={`w-10 h-10 rounded-full flex items-center justify-center transition border cursor-pointer overflow-hidden ${
                      isSelected
                        ? "border-purple-500 shadow-[0_0_8px_rgba(168,85,247,0.4)]"
                        : "border-transparent hover:border-white/20"
                    }`}
                    title={char.name}
                  >
                    <img
                      src={
                        char.avatarUrl ||
                        `https://api.dicebear.com/7.x/pixel-art/svg?seed=${encodeURIComponent(
                          char.name
                        )}`
                      }
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Profile and Settings Footbar */}
        <div className="p-4 border-t border-purple-950/20 bg-black/10 shrink-0">
          {!isCollapsed ? (
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                <img
                  src={
                    user.photoURL ||
                    `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(
                      user.uid
                    )}`
                  }
                  alt=""
                  className="w-8 h-8 rounded-full border border-purple-500/30 shrink-0"
                />
                <div className="truncate">
                  <div className="text-xs font-bold text-white truncate">
                    {user.displayName}
                  </div>
                  <span className="text-[9px] text-cyan-400 font-mono font-bold leading-none uppercase block mt-1">
                    ONLINE • PETUALANG
                  </span>
                </div>
              </div>
              <button
                onClick={onOpenSettings}
                className="p-2 hover:bg-white/5 border border-purple-500/20 rounded-xl text-gray-400 hover:text-white transition shrink-0 cursor-pointer"
                title="Pengaturan Model"
              >
                <SettingsIcon size={15} />
              </button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-3">
              <img
                src={
                  user.photoURL ||
                  `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(
                    user.uid
                  )}`
                }
                alt=""
                className="w-8 h-8 rounded-full border border-purple-500/30 cursor-pointer"
                title={user.displayName}
                onClick={onOpenSettings}
              />
              <button
                onClick={onOpenSettings}
                className="p-2 hover:bg-white/5 border border-purple-500/20 rounded-xl text-gray-400 hover:text-white transition shrink-0 cursor-pointer"
                title="Pengaturan Model"
              >
                <SettingsIcon size={15} />
              </button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
