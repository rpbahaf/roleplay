import React from "react";
import { Trash2 } from "lucide-react";

interface DeleteConfirmModalProps {
  isOpen: boolean;
  title?: string;
  description?: string;
  onCancel: () => void;
  onConfirm: () => void;
}

export default function DeleteConfirmModal({
  isOpen,
  title = "Hapus Karakter Permanen?",
  description = "Apakah Anda yakin ingin menghapus sepenuhnya karakter ini beserta semua log percakapannya? Tindakan ini bersifat permanen dan tidak dapat dibatalkan.",
  onCancel,
  onConfirm,
}: DeleteConfirmModalProps) {
  if (!isOpen) return null;

  return (
    <div
      id="home-delete-confirm-modal"
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
    >
      <div className="bg-[#12141d] border border-red-500/20 max-w-md w-full rounded-2xl p-6 space-y-6 shadow-[0_0_50px_rgba(239,68,68,0.15)] relative">
        <div className="flex items-center gap-3 border-b border-white/5 pb-3">
          <div className="p-2 bg-red-500/10 rounded-xl text-red-400">
            <Trash2 size={20} />
          </div>
          <h3 className="text-base font-bold text-white">{title}</h3>
        </div>

        <p className="text-xs text-gray-300 leading-relaxed">{description}</p>

        <div className="flex justify-end gap-3 pt-2">
          <button
            onClick={onCancel}
            className="px-4 py-2 bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-semibold rounded-xl text-gray-300 transition-all cursor-pointer"
          >
            Batal
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 bg-red-600 hover:bg-red-500 text-xs font-semibold rounded-xl text-white transition-all cursor-pointer shadow-lg shadow-red-900/40"
          >
            Hapus Karakter
          </button>
        </div>
      </div>
    </div>
  );
}
