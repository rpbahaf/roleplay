import React from "react";
import { Settings as SettingsIcon, X } from "lucide-react";
import { ChatSettings } from "../../types";
import Settings from "../Settings";

interface SettingsModalProps {
  isOpen: boolean;
  settings: ChatSettings;
  onUpdate: (settings: ChatSettings) => void;
  onClose: () => void;
  onAudioCue?: (type: "click" | "receive") => void;
}

export default function SettingsModal({
  isOpen,
  settings,
  onUpdate,
  onClose,
  onAudioCue,
}: SettingsModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div className="bg-[#0f0b21] border border-purple-500/25 max-w-xl w-full rounded-2xl p-4 sm:p-6 space-y-4 shadow-[0_0_55px_rgba(168,85,247,0.2)] relative flex flex-col max-h-[90vh]">
        <div className="flex justify-between items-center border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <SettingsIcon size={18} className="text-cyan-400 animate-spin-slow" />
            <h3 className="text-base font-black text-white">
              Pengaturan Utama Portal
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        <div className="overflow-y-auto pr-1 flex-1">
          <Settings settings={settings} onUpdate={onUpdate} />
        </div>

        <div className="pt-2 border-t border-white/5 flex justify-end">
          <button
            onClick={() => {
              if (onAudioCue) onAudioCue("click");
              onClose();
            }}
            className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold rounded-xl text-xs transition shadow-lg cursor-pointer"
          >
            Simpan & Selesai
          </button>
        </div>
      </div>
    </div>
  );
}
