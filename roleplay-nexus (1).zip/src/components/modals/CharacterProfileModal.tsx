import React from "react";
import { X } from "lucide-react";
import { Character } from "../../types";

interface CharacterProfileModalProps {
  character: Character | null;
  onClose: () => void;
  onStartChat: (character: Character) => void;
}

export default function CharacterProfileModal({
  character,
  onClose,
  onStartChat,
}: CharacterProfileModalProps) {
  if (!character) return null;

  const defaultAvatar = `https://api.dicebear.com/7.x/${
    character.persona === "cyberpunk"
      ? "bottts"
      : character.persona === "horror"
      ? "identicon"
      : character.persona === "detective"
      ? "micah"
      : "pixel-art"
  }/svg?seed=${encodeURIComponent(character.name)}`;

  return (
    <div
      id="character-profile-modal"
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in overflow-y-auto"
    >
      <div className="bg-[#0f0b21] border border-purple-500/20 max-w-lg w-full rounded-2xl overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.6)] relative flex flex-col my-8">
        {/* Banner/Avatar header */}
        <div className="relative h-48 bg-gradient-to-r from-purple-950/40 to-cyan-950/40 border-b border-purple-500/15 flex items-center justify-center">
          <img
            src={character.avatarUrl || defaultAvatar}
            alt={character.name}
            className="w-28 h-28 rounded-2xl border-4 border-[#0f0b21] shadow-2xl object-cover z-10"
            referrerPolicy="no-referrer"
          />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-black/50 hover:bg-black/80 rounded-full border border-white/10 text-gray-400 hover:text-white transition z-20 cursor-pointer"
            title="Tutup"
          >
            <X size={16} />
          </button>
        </div>

        {/* Profile body details */}
        <div className="p-6 space-y-4 overflow-y-auto max-h-[50vh]">
          <div className="text-center space-y-1">
            <h3 className="text-lg font-black text-white tracking-tight">
              {character.name}
            </h3>
            <div className="flex items-center justify-center gap-2">
              <span className="text-[9px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-2 py-0.5 rounded-full uppercase font-bold tracking-wider font-mono">
                {character.persona || "custom"}
              </span>
              <span className="text-[9px] bg-purple-500/10 text-purple-400 border border-purple-500/20 px-2 py-0.5 rounded-full uppercase font-bold tracking-wider font-mono">
                {character.gender || "Tidak ditentukan"}
              </span>
            </div>
          </div>

          <div className="space-y-3.5 text-xs">
            {/* Backstory */}
            <div className="space-y-1 bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <span className="text-[9px] text-cyan-400 font-bold uppercase tracking-widest block font-mono">
                Latar Belakang
              </span>
              <p className="text-gray-300 leading-relaxed text-[11px]">
                {character.background}
              </p>
            </div>

            {/* Personality */}
            <div className="space-y-1 bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <span className="text-[9px] text-purple-400 font-bold uppercase tracking-widest block font-mono">
                Kepribadian
              </span>
              <p className="text-gray-300 leading-relaxed text-[11px]">
                {character.personality}
              </p>
            </div>

            {/* Speaking style */}
            <div className="space-y-1 bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <span className="text-[9px] text-cyan-300 font-bold uppercase tracking-widest block font-mono">
                Gaya Berbicara
              </span>
              <p className="text-gray-300 font-mono text-[10px] leading-relaxed italic">
                "{character.speakingStyle}"
              </p>
            </div>

            {/* Sapaan Pembuka */}
            <div className="space-y-1 bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <span className="text-[9px] text-emerald-400 font-bold uppercase tracking-widest block font-mono">
                Sapaan Pembuka
              </span>
              <p className="text-gray-300 leading-relaxed text-[11px] italic">
                "{character.intro}"
              </p>
            </div>
          </div>
        </div>

        {/* Footer buttons */}
        <div className="p-4 bg-black/40 border-t border-white/5 flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2 bg-white/5 hover:bg-white/10 text-white font-bold rounded-xl text-xs transition border border-white/5 cursor-pointer text-center"
          >
            Tutup
          </button>
          <button
            onClick={() => onStartChat(character)}
            className="flex-1 py-2 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold rounded-xl text-xs transition shadow-lg shadow-purple-500/25 cursor-pointer text-center"
          >
            Chat Karakter 💬
          </button>
        </div>
      </div>
    </div>
  );
}
