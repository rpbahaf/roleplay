import React from "react";
import { Sparkle, Sparkles, Zap } from "lucide-react";

export type PersonaType =
  | "fantasy"
  | "cyberpunk"
  | "detective"
  | "medieval"
  | "horror"
  | "normal";

interface InstantSummonerProps {
  isSummoning: boolean;
  summonPersona: PersonaType;
  onPersonaChange: (persona: PersonaType) => void;
  onInstantSummon: () => void;
  summonError: string | null;
}

export default function InstantSummoner({
  isSummoning,
  summonPersona,
  onPersonaChange,
  onInstantSummon,
  summonError,
}: InstantSummonerProps) {
  return (
    <>
      {/* Instant Summoning AI portal animation cover */}
      {isSummoning && (
        <div className="fixed inset-0 bg-black/90 backdrop-blur-md z-50 flex flex-col items-center justify-center p-6 text-center animate-fade-in">
          <div className="relative w-24 h-24 mb-6">
            <div
              className="absolute inset-0 rounded-full border-4 border-t-cyan-400 border-r-transparent border-b-purple-500 border-l-transparent animate-spin"
              style={{ animationDuration: "1s" }}
            />
            <div
              className="absolute inset-2 rounded-full border-4 border-t-purple-400 border-r-transparent border-b-cyan-500 border-l-transparent animate-spin-reverse"
              style={{ animationDuration: "1.8s" }}
            />
            <div className="absolute inset-4 rounded-full bg-purple-950/40 flex items-center justify-center text-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.3)]">
              <Sparkles size={28} className="animate-pulse" />
            </div>
          </div>
          <h3 className="text-lg font-bold text-white tracking-wide">
            Membuka Gerbang Dimensi Astral...
          </h3>
          <p className="text-xs text-gray-400 mt-2 max-w-sm">
            Menghubungkan faksi biner {summonPersona} untuk menulis takdir kehidupan NPC baru...
          </p>
          <div className="text-[10px] text-gray-400 font-mono mt-4 space-y-1 bg-black/40 p-3 rounded-lg border border-purple-500/15 w-64 text-left">
            <p className="animate-pulse">• Memancarkan sinyal biner...</p>
            <p className="animate-pulse" style={{ animationDelay: "0.5s" }}>
              • Mengumpulkan partikel memori...
            </p>
            <p className="animate-pulse" style={{ animationDelay: "1s" }}>
              • Melahirkan kesadaran emosional...
            </p>
          </div>
        </div>
      )}

      {/* AI Instant Summoner Box */}
      <div className="bg-gradient-to-br from-purple-950/15 via-[#0e0a1c] to-cyan-950/10 border border-purple-500/20 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/5 rounded-full blur-[40px] pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <span className="text-[9px] bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 px-2.5 py-1 rounded-full uppercase font-bold tracking-widest inline-flex items-center gap-1.5">
              <Sparkle size={11} className="animate-spin-slow text-cyan-400" /> AI Portal Summoner
            </span>
            <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
              Kamar Ritual Instan AI
            </h3>
            <p className="text-xs text-gray-300 leading-relaxed">
              Malas mengisi form identitas manual? Biarkan Nova AI melahirkan NPC legendaris baru
              yang acak, unik, dan memiliki latar belakang mendalam secara instan berdasarkan genre
              dunia pilihan Anda!
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center shrink-0">
            <select
              value={summonPersona}
              onChange={(e) => onPersonaChange(e.target.value as PersonaType)}
              className="bg-[#0e0a1b] border border-purple-500/30 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-cyan-400/50"
            >
              <option value="fantasy">High Fantasy</option>
              <option value="cyberpunk">Cyberpunk</option>
              <option value="detective">Noir Detective</option>
              <option value="medieval">Medieval Kingdom</option>
              <option value="horror">Psychological Horror</option>
              <option value="normal">Modern Realistic</option>
            </select>
            <button
              onClick={onInstantSummon}
              disabled={isSummoning}
              className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-bold rounded-xl text-xs transition shadow-lg shadow-purple-500/20 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Zap size={13} className="animate-pulse text-yellow-300" /> Panggil NPC Instan (AI)
            </button>
          </div>
        </div>
        {summonError && (
          <p className="text-[11px] text-red-400 mt-3 font-mono">⚠️ {summonError}</p>
        )}
      </div>
    </>
  );
}
