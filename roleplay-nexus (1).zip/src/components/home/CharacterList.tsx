import React from "react";
import { UserPlus, Search, Sparkles, Trash2 } from "lucide-react";
import { Character } from "../../types";

export type GenreTab =
  | "all"
  | "fantasy"
  | "cyberpunk"
  | "detective"
  | "medieval"
  | "horror"
  | "normal";

interface CharacterListProps {
  characters: Character[];
  loading: boolean;
  activeTab: GenreTab;
  onTabChange: (tab: GenreTab) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectProfile: (char: Character) => void;
  onStartChat: (char: Character) => void;
  onOpenCreate: () => void;
  onConfirmDelete: (charId: string) => void;
}

const genreLabels: Record<GenreTab, string> = {
  all: "Semua",
  fantasy: "High Fantasy 🧙‍♂️",
  cyberpunk: "Cyberpunk 🌆",
  detective: "Noir Detective 🕵️‍♂️",
  medieval: "Medieval ⚔️",
  horror: "Horror 👁️",
  normal: "Modern ☕",
};

export default function CharacterList({
  characters,
  loading,
  activeTab,
  onTabChange,
  searchQuery,
  onSearchChange,
  onSelectProfile,
  onStartChat,
  onOpenCreate,
  onConfirmDelete,
}: CharacterListProps) {
  const customCount = characters.filter((c) => !c.isDefault).length;

  const filteredList = characters.filter((char) => {
    if (activeTab !== "all" && char.persona !== activeTab) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      char.name?.toLowerCase().includes(q) ||
      char.background?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-4 mt-8">
      {/* Genre Filter Tabs Bar */}
      <div className="flex flex-wrap items-center gap-2 border-b border-purple-500/10 pb-5">
        <span className="text-[10px] font-bold uppercase tracking-widest text-purple-400 font-mono mr-2">
          Faksi Dimensi:
        </span>
        {(
          [
            "all",
            "fantasy",
            "cyberpunk",
            "detective",
            "medieval",
            "horror",
            "normal",
          ] as const
        ).map((tab) => (
          <button
            key={tab}
            onClick={() => onTabChange(tab)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
              activeTab === tab
                ? "bg-purple-600 border-purple-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.25)]"
                : "bg-[#120e24]/40 border-purple-500/15 text-gray-400 hover:text-white hover:border-purple-500/30"
            }`}
          >
            {genreLabels[tab]}
          </button>
        ))}
      </div>

      {/* Header with Title and Create Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
        <div className="space-y-1">
          <h3 className="text-sm font-bold uppercase tracking-wider text-purple-400 flex items-center gap-2">
            Penjelajah & Penduduk Dimensi
            <span
              className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold border ${
                customCount > 3
                  ? "bg-red-500/10 text-red-400 border-red-500/20 shadow-[0_0_15px_rgba(239,68,68,0.1)]"
                  : customCount === 3
                  ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20"
                  : "bg-purple-500/10 text-purple-300 border-purple-500/20"
              }`}
            >
              {customCount}/3 Karakter Kustom
            </span>
          </h3>
          <p className="text-[11px] text-gray-500">
            Hubungi penduduk lokal untuk memulai dialog permainan peran interaktif.
          </p>
        </div>
        <button
          onClick={onOpenCreate}
          className="text-xs text-cyan-400 hover:text-cyan-300 font-bold flex items-center gap-1 transition self-start sm:self-auto bg-cyan-950/20 px-3 py-1.5 border border-cyan-500/20 rounded-xl cursor-pointer"
        >
          <UserPlus size={14} /> Summon Karakter Baru
        </button>
      </div>

      {/* Capacity Warning */}
      {customCount > 3 && (
        <div className="p-4 bg-red-950/25 border border-red-500/20 text-red-400 rounded-xl text-[11px] leading-normal font-sans shadow-md flex items-start gap-3">
          <span className="text-sm">⚠️</span>
          <div className="space-y-1">
            <p className="font-bold">Kapasitas Maksimal Karakter Terlampaui!</p>
            <p className="text-gray-400">
              Anda saat ini memiliki {customCount} karakter kustom. Silakan
              hapus beberapa karakter di bawah menggunakan tombol ikon sampah (
              <span className="text-red-400 font-semibold">Hapus Karakter</span>
              ) agar kapasitas kembali normal (maksimal 3 karakter kustom). Game Master tidak dihitung dalam slot kapasitas.
            </p>
          </div>
        </div>
      )}

      {/* Search Input Bar */}
      <div className="relative flex items-center bg-black/40 border border-purple-500/15 rounded-xl p-2 px-3 focus-within:border-cyan-400/40 transition">
        <span className="text-gray-400 mr-2">
          <Search size={16} />
        </span>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Cari karakter berdasarkan nama atau deskripsi..."
          className="flex-1 bg-transparent p-1.5 outline-none text-xs text-white placeholder-gray-500"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange("")}
            className="text-xs text-gray-400 hover:text-white px-2 cursor-pointer"
          >
            Batal
          </button>
        )}
      </div>

      {/* Cards List or Loading */}
      {loading ? (
        <div className="text-center py-8 text-xs text-cyan-400 font-mono animate-pulse">
          MEMUAT KARAKTER...
        </div>
      ) : characters.length > 0 ? (
        filteredList.length === 0 ? (
          <div className="text-center py-12 bg-[#130f24]/20 border border-dashed border-purple-500/10 rounded-xl">
            <p className="text-xs text-gray-500">
              Tidak ada karakter dalam faksi "{genreLabels[activeTab]}" yang cocok
              dengan pencarian Anda.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredList.map((char) => {
              const defaultAvatar = `https://api.dicebear.com/7.x/${
                char.persona === "cyberpunk"
                  ? "bottts"
                  : char.persona === "horror"
                  ? "identicon"
                  : char.persona === "detective"
                  ? "micah"
                  : "pixel-art"
              }/svg?seed=${encodeURIComponent(char.name)}`;

              return (
                <div
                  key={char.id}
                  className="bg-[#130f24]/50 border border-purple-500/15 hover:border-cyan-500/30 rounded-xl p-5 flex flex-col justify-between gap-4 transition shadow-md group"
                >
                  <div className="space-y-2">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-3">
                        {/* Avatar Thumbnail */}
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectProfile(char);
                          }}
                          className="w-10 h-10 rounded-xl overflow-hidden border border-purple-500/20 shrink-0 cursor-pointer hover:border-cyan-400/50 transition-all group-hover:scale-105 relative"
                          title="Klik untuk melihat profil lengkap"
                        >
                          <img
                            src={char.avatarUrl || defaultAvatar}
                            alt={char.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Name & Quick Profile Trigger */}
                        <div className="flex flex-col">
                          <h4 className="font-bold text-white flex items-center gap-1.5 text-sm">
                            <span
                              className={`w-1.5 h-1.5 rounded-full animate-pulse ${
                                char.isDefault ? "bg-purple-400" : "bg-cyan-400"
                              }`}
                            />
                            {char.name}
                          </h4>
                          <div className="flex items-center gap-2 mt-0.5">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                onSelectProfile(char);
                              }}
                              className="text-[10px] text-purple-400 hover:text-purple-300 font-bold text-left transition cursor-pointer"
                            >
                              Lihat Profil 🔍
                            </button>
                            <span
                              className={`px-1.5 py-0.2 text-[8px] rounded font-extrabold uppercase font-mono ${
                                char.isDefault
                                  ? "bg-purple-500/10 text-purple-300 border border-purple-500/20"
                                  : "bg-cyan-500/10 text-cyan-300 border border-cyan-500/20"
                              }`}
                            >
                              {char.isDefault ? "🌌 Sistem" : "🎴 Kustom"}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed">
                      {char.background}
                    </p>

                    {/* Direct Chat Button */}
                    <button
                      onClick={() => onStartChat(char)}
                      className="mt-3 w-full py-2 bg-gradient-to-r from-purple-600/50 to-cyan-500/50 hover:from-purple-600 hover:to-cyan-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
                    >
                      <Sparkles size={12} className="text-yellow-300" /> Mulai
                      Obrolan Baru ➔
                    </button>
                  </div>

                  <div className="flex justify-between items-center border-t border-purple-500/10 pt-3 mt-3">
                    <span className="text-[10px] text-cyan-400 uppercase font-bold tracking-wider font-mono">
                      {char.persona}
                    </span>
                    <div className="flex gap-2">
                      {!char.isDefault && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onConfirmDelete(char.id);
                          }}
                          className="p-1.5 bg-red-600/10 border border-red-500/20 hover:bg-red-600/30 text-red-400 hover:text-red-300 rounded-lg text-xs transition flex items-center justify-center cursor-pointer"
                          title="Hapus Karakter"
                        >
                          <Trash2 size={14} />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )
      ) : (
        <div className="text-center py-8 bg-white/[0.02] border border-dashed border-white/10 rounded-xl">
          <p className="text-xs text-gray-500 mb-3">
            Belum ada karakter yang tersedia.
          </p>
          <button
            onClick={onOpenCreate}
            className="px-4 py-2 bg-white/5 hover:bg-white/10 text-xs rounded-lg transition cursor-pointer"
          >
            Buat Karakter Sekarang
          </button>
        </div>
      )}
    </div>
  );
}
