import React from "react";
import { Compass, Send } from "lucide-react";
import { Character } from "../../types";

interface FloatingPromptBarProps {
  character: Character | null;
  characters: Character[];
  onSelectCharacter: (char: Character) => void;
  onOpenCreate: () => void;
  mainPromptInput: string;
  onChangePromptInput: (val: string) => void;
  onSubmitPrompt: () => void;
}

export default function FloatingPromptBar({
  character,
  characters,
  onSelectCharacter,
  onOpenCreate,
  mainPromptInput,
  onChangePromptInput,
  onSubmitPrompt,
}: FloatingPromptBarProps) {
  return (
    <div className="max-w-3xl mx-auto w-full space-y-3 pt-2">
      <div className="relative border border-purple-500/25 bg-[#0e0a1c]/90 backdrop-blur-md rounded-2xl sm:rounded-full p-2.5 px-3 sm:px-5 focus-within:border-cyan-400/50 focus-within:shadow-[0_0_30px_rgba(6,182,212,0.15)] transition-all duration-300 flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3">
        {/* Select character inline */}
        <div className="flex items-center gap-1 shrink-0 bg-purple-950/40 border border-purple-500/20 rounded-xl sm:rounded-full p-1.5 px-3 text-xs justify-between sm:justify-start">
          <div className="flex items-center gap-1.5">
            <Compass size={13} className="text-cyan-400 animate-pulse" />
            <span className="text-[10px] text-gray-400 uppercase font-mono sm:hidden">
              Karakter:
            </span>
          </div>
          <select
            value={character?.id || ""}
            onChange={(e) => {
              const val = e.target.value;
              if (val === "new") {
                onOpenCreate();
              } else {
                const found = characters.find((c) => c.id === val);
                if (found) {
                  onSelectCharacter(found);
                }
              }
            }}
            className="bg-transparent border-none text-white outline-none text-[12px] sm:text-[10px] font-extrabold max-w-[180px] sm:max-w-[120px] cursor-pointer"
          >
            <option value="" className="bg-[#0e0a1c] text-gray-400">
              Pilih Karakter
            </option>
            {characters.map((c) => (
              <option key={c.id} value={c.id} className="bg-[#0e0a1c] text-white">
                {c.name}
              </option>
            ))}
            <option value="new" className="bg-[#0e0a1c] text-cyan-300">
              + Buat Baru
            </option>
          </select>
        </div>

        <div className="flex items-center gap-2 flex-1">
          <input
            type="text"
            value={mainPromptInput}
            onChange={(e) => onChangePromptInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                onSubmitPrompt();
              }
            }}
            placeholder={
              character
                ? `Kirim tindakan ke ${character.name}...`
                : "Ketik skenario lalu kirim untuk mulai..."
            }
            className="flex-1 bg-transparent p-1.5 outline-none text-[16px] sm:text-sm text-white placeholder-gray-500 font-sans min-w-0"
          />

          <button
            onClick={onSubmitPrompt}
            disabled={!mainPromptInput.trim()}
            className="p-2 sm:p-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-50 text-white rounded-full transition cursor-pointer flex items-center justify-center shadow-lg shrink-0 min-w-[36px] min-h-[36px] active:scale-90"
            title="Kirim Skenario"
          >
            <Send size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
