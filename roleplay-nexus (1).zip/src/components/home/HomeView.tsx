import React from "react";
import HomeHero from "./HomeHero";
import SuggestionCards from "./SuggestionCards";
import FloatingPromptBar from "./FloatingPromptBar";
import InstantSummoner, { PersonaType } from "./InstantSummoner";
import CharacterList, { GenreTab } from "./CharacterList";
import AnimeArtStudio from "../AnimeArtStudio";
import { Character } from "../../types";

interface HomeViewProps {
  user: { uid: string; displayName: string; photoURL?: string } | null;
  character: Character | null;
  characters: Character[];
  loadingChars: boolean;
  mainPromptInput: string;
  onChangePromptInput: (val: string) => void;
  onSubmitPrompt: () => void;
  onSelectSuggestion: (persona: string, promptText: string) => void;
  onSelectCharacter: (char: Character) => void;
  onOpenCreate: () => void;
  // Summoner props
  isSummoning: boolean;
  summonPersona: PersonaType;
  onPersonaChange: (persona: PersonaType) => void;
  onInstantSummon: () => void;
  summonError: string | null;
  // Character list props
  activeTab: GenreTab;
  onTabChange: (tab: GenreTab) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSelectProfile: (char: Character) => void;
  onStartChat: (char: Character) => void;
  onConfirmDelete: (charId: string) => void;
  // Audio & Toast props for AnimeArtStudio
  playAudioCue: (type: "click" | "receive" | "reset" | "reflect" | "send") => void;
  showToast: (msg: string) => void;
}

export default function HomeView({
  user,
  character,
  characters,
  loadingChars,
  mainPromptInput,
  onChangePromptInput,
  onSubmitPrompt,
  onSelectSuggestion,
  onSelectCharacter,
  onOpenCreate,
  isSummoning,
  summonPersona,
  onPersonaChange,
  onInstantSummon,
  summonError,
  activeTab,
  onTabChange,
  searchQuery,
  onSearchChange,
  onSelectProfile,
  onStartChat,
  onConfirmDelete,
  playAudioCue,
  showToast,
}: HomeViewProps) {
  return (
    <div className="space-y-8 max-w-4xl mx-auto relative animate-fade-in">
      {/* Instant Summoning AI Portal animation and Section */}
      <InstantSummoner
        isSummoning={isSummoning}
        summonPersona={summonPersona}
        onPersonaChange={onPersonaChange}
        onInstantSummon={onInstantSummon}
        summonError={summonError}
      />

      {/* Hero Welcome Zone */}
      <HomeHero displayName={user?.displayName || "Petualang"} />

      {/* Suggestion Scenario Cards Grid */}
      <SuggestionCards onSelectSuggestion={onSelectSuggestion} />

      {/* Floating Prompt Bar with Character Selector */}
      <FloatingPromptBar
        character={character}
        characters={characters}
        onSelectCharacter={onSelectCharacter}
        onOpenCreate={onOpenCreate}
        mainPromptInput={mainPromptInput}
        onChangePromptInput={onChangePromptInput}
        onSubmitPrompt={onSubmitPrompt}
      />

      {/* Character List with Faksi Filter Tabs and Search */}
      <CharacterList
        characters={characters}
        loading={loadingChars}
        activeTab={activeTab}
        onTabChange={onTabChange}
        searchQuery={searchQuery}
        onSearchChange={onSearchChange}
        onSelectProfile={onSelectProfile}
        onStartChat={onStartChat}
        onOpenCreate={onOpenCreate}
        onConfirmDelete={onConfirmDelete}
      />

      {/* AI Anime Art Studio Section */}
      <div className="border-t border-white/5 pt-8 mt-4">
        <div className="bg-[#0f111a]/40 border border-white/10 rounded-2xl p-6 md:p-8 shadow-xl">
          <AnimeArtStudio
            playAudioCue={playAudioCue}
            showToast={showToast}
          />
        </div>
      </div>
    </div>
  );
}
