import React from "react";

export interface ScenarioSuggestion {
  title: string;
  desc: string;
  icon: string;
  persona: string;
  prompt: string;
}

export const defaultSuggestions: ScenarioSuggestion[] = [
  {
    title: "Ksatria Elf Eldoria",
    desc: "Bangun di altar kuno faksi elf...",
    icon: "🧙‍♂️",
    persona: "fantasy",
    prompt:
      '*Membuka mata perlahan di altar batu kuno Eldoria yang dipenuhi lumut bercahaya, menatapmu yang berdiri di depanku...* "Siapa Anda, dan mengapa Anda mengusik segel tidur suci faksi kami?"',
  },
  {
    title: "Peretas Bayangan Neo-JKT",
    desc: "Tembus enkripsi biner Megacorp...",
    icon: "🌆",
    persona: "cyberpunk",
    prompt:
      '*Menatap barisan baris kode biner hijau yang berkedip cepat di layar hologram di depan kita...* "Mainframe Arasaka hampir tembus. Siapkan dekmu, sistem faksi akan overheat dalam 30 detik!"',
  },
  {
    title: "Interogasi Detektif",
    desc: "Ungkap misteri malam di gang gelap...",
    icon: "🕵️‍♂️",
    persona: "detective",
    prompt:
      '*Menghisap rokok terakhir di kantor detektif faksi kota yang gelap, mengembuskan asap abu-abu...* "Saya tahu apa yang kamu lakukan di gang pelabuhan semalam. Jangan berbohong pada lencana ini."',
  },
  {
    title: "Pemberontak Kerajaan",
    desc: "Tantang dominasi raja lalim faksi abad tengah...",
    icon: "⚔️",
    persona: "medieval",
    prompt:
      '*Mengencangkan genggaman pada gagang pedang baja pusaka yang berselimut kain hitam...* "Pasukan pengawal kerajaan faksi utara sudah mendekat. Ini adalah waktu terbaik untuk melakukan penyergapan!"',
  },
];

interface SuggestionCardsProps {
  onSelectSuggestion: (persona: string, promptText: string) => void;
}

export default function SuggestionCards({
  onSelectSuggestion,
}: SuggestionCardsProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
      {defaultSuggestions.map((s, idx) => (
        <button
          key={idx}
          onClick={() => onSelectSuggestion(s.persona, s.prompt)}
          className="p-5 bg-[#0f0b21]/60 border border-purple-500/15 hover:border-cyan-400/40 rounded-2xl text-left hover:bg-[#150f30]/80 hover:shadow-[0_0_20px_rgba(168,85,247,0.15)] transition-all duration-300 group cursor-pointer flex flex-col justify-between h-40"
        >
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <span className="text-xl shrink-0">{s.icon}</span>
              <span className="text-[8px] text-cyan-300 font-bold font-mono uppercase bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded">
                {s.persona}
              </span>
            </div>
            <h4 className="text-xs font-extrabold text-white group-hover:text-cyan-300 transition-colors line-clamp-1 font-sans">
              {s.title}
            </h4>
            <p className="text-[10px] text-gray-400 line-clamp-2 leading-relaxed font-sans">
              {s.desc}
            </p>
          </div>
          <div className="text-[9px] text-purple-400 font-black tracking-wider uppercase mt-2 flex items-center gap-1 group-hover:text-cyan-300 group-hover:translate-x-1 transition-all duration-300 font-mono">
            Mulai Skenario ➔
          </div>
        </button>
      ))}
    </div>
  );
}
