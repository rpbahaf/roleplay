import React from "react";

interface HomeHeroProps {
  displayName?: string;
}

export default function HomeHero({ displayName = "Petualang" }: HomeHeroProps) {
  return (
    <div className="text-center py-6 md:py-10 space-y-3.5 relative">
      <div className="absolute inset-0 -top-10 bg-[radial-gradient(circle_at_center,_rgba(168,85,247,0.08)_0%,_transparent_70%)] h-64 w-full pointer-events-none blur-3xl" />
      <h2 className="text-4xl md:text-6xl font-black bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-500 bg-clip-text text-transparent pb-1 tracking-tighter leading-none">
        Halo, {displayName} 👋
      </h2>
      <p className="text-gray-300 text-sm md:text-base max-w-xl mx-auto font-medium leading-relaxed">
        Pilih skenario takdir biner di bawah untuk memulai secara instan, atau
        tulis skenario kustom Anda sendiri.
      </p>
    </div>
  );
}
