// Utility functions for roleplay dialogue sanitization and formatting

export function sanitizeDialogueFormatting(text: string): string {
  if (!text) return text;

  // Remove lines that look like numbered choices (e.g., "1. *something*", "2. *something*", "1) *something*", etc.)
  let cleanedText = text.replace(/^\s*\d+[\s.)-]+\s*\*([^*]+)\*\s*$/gm, '');
  cleanedText = cleanedText.replace(/^\s*\d+[\s.)-]+\s*"([^"]+)"\s*$/gm, '');
  cleanedText = cleanedText.replace(/^\s*\d+[\s.)-]+\s*.*$/gm, (match) => {
    const lower = match.toLowerCase();
    if (/^\s*\d+[\s.)-]+\s*/.test(match) && (match.includes('*') || match.includes('"') || lower.includes('pilihan') || lower.includes('tindakan') || lower.includes('opsi'))) {
      return '';
    }
    return match;
  });

  // Also strip generic headers like "Rekomendasi Tindakan:" or "Pilihan Anda:" or similar
  cleanedText = cleanedText.replace(/^\s*(?:Rekomendasi Tindakan|Pilihan|Opsi|Daftar Tindakan|Saran Aksi)\s*:\s*$/gmi, '');

  // Process line by line/paragraph by paragraph to keep spacing and structures intact
  return cleanedText
    .split("\n")
    .map((line) => {
      let trimmed = line.trim();
      if (!trimmed) return line;

      // Clean up common duplicate punctuation artifacts like *.* or .*.
      trimmed = trimmed.replace(/\*\.\*/g, "*").replace(/\.\*\.\*/g, ".*");

      // Pattern 1: Starts with * and ends with * and contains double quotes, and only has 2 asterisks in total
      if (
        trimmed.startsWith("*") &&
        trimmed.endsWith("*") &&
        (trimmed.match(/\*/g) || []).length === 2 &&
        trimmed.includes('"')
      ) {
        const firstQuoteIdx = trimmed.indexOf('"');
        const lastQuoteIdx = trimmed.lastIndexOf('"');
        if (firstQuoteIdx > 1 && lastQuoteIdx > firstQuoteIdx) {
          const actionPart = trimmed.substring(1, firstQuoteIdx).trim();
          const dialoguePart = trimmed
            .substring(firstQuoteIdx + 1, lastQuoteIdx)
            .trim();
          let cleanedAction = actionPart;
          cleanedAction = cleanedAction.replace(/\*+$/, "").trim();
          if (cleanedAction.endsWith(",") || cleanedAction.endsWith(".")) {
            cleanedAction = cleanedAction.slice(0, -1).trim();
          }
          cleanedAction = cleanedAction.replace(/\*+$/, "").trim();
          return `*${cleanedAction}.* "${dialoguePart}"`;
        }
      }

      // Pattern 2: Global regex replacement of any nested patterns
      // e.g. *Action, "Dialogue"* or *Action "Dialogue"*
      trimmed = trimmed.replace(
        /\*([^*"]+?)(?:,\s*|\.\s*|\s*)"([^"]+?)"(?:,\s*|\.\s*|\s*)\*/g,
        (_match, action, dialogue) => {
          let cleanAction = action.trim().replace(/\*+$/, "").trim();
          if (cleanAction.endsWith(",") || cleanAction.endsWith(".")) {
            cleanAction = cleanAction.slice(0, -1).trim();
          }
          cleanAction = cleanAction.replace(/\*+$/, "").trim();
          return `*${cleanAction}.* "${dialogue.trim()}"`;
        },
      );

      // Pattern 3: *Action, "Dialogue"
      trimmed = trimmed.replace(
        /\*([^*"]+?)(?:,\s*|\.\s*|\s*)"([^"]+?)"/g,
        (_match, action, dialogue) => {
          let cleanAction = action.trim().replace(/\*+$/, "").trim();
          if (cleanAction.endsWith(",") || cleanAction.endsWith(".")) {
            cleanAction = cleanAction.slice(0, -1).trim();
          }
          cleanAction = cleanAction.replace(/\*+$/, "").trim();
          return `*${cleanAction}.* "${dialogue.trim()}"`;
        },
      );

      // Ensure spaces between asterisk and quotes: e.g. `*"Dialogue"` or `"*` or similar
      trimmed = trimmed.replace(/\*(\s*)"/g, '* "');
      trimmed = trimmed.replace(/"(\s*)\*/g, '" *');

      // Final cleanup of any trailing `.*` right after `*`
      trimmed = trimmed.replace(/\*\.\*/g, "*");

      return trimmed;
    })
    .join("\n");
}

export const personaDisplayNames: Record<string, string> = {
  fantasy: "Aeloria the Spellbinder",
  cyberpunk: "Kaelen the Cyber-Drifter",
  detective: "Inspector Richard",
  medieval: "Sir Galahad",
  horror: "The Whispering Witch",
  normal: "Sarah the Mentor",
};

export const personaBackgrounds: Record<string, string> = {
  fantasy: "Seorang penyihir agung yang menguasai seni elemental kuno di dimensi astral.",
  cyberpunk: "Seorang peretas bayangan legendaris yang mengembara di jalanan neon Neo-Jakarta.",
  detective: "Seorang detektif veteran sinis yang mendedikasikan hidupnya untuk mengungkap kejahatan malam.",
  medieval: "Ksatria perkasa pelindung kerajaan suci yang bertarung demi kehormatan faksi.",
  horror: "Entitas gaib misterius yang mendiami ruang hampa udara di dimensi kegelapan.",
  normal: "Instruktur bijaksana yang melatih para penjelajah pemula di akademi dimensi biner.",
};
