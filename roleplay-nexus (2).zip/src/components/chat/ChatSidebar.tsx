import React from "react";
import {
  X,
  Lock,
  Eye,
  EyeOff,
  RefreshCw,
  Edit3,
  Trash2,
  Copy,
  Check,
  Zap,
} from "lucide-react";
import { Character, ChatSettings, Message } from "../../types";
import { encryptMessage } from "../../lib/storage";

export type SidebarTab = "npc" | "paste_chat" | "secure_storage" | "ai_settings";

interface ChatSidebarProps {
  character: Character;
  settings: ChatSettings;
  messages: Message[];
  showMobileDetails: boolean;
  onCloseMobileDetails: () => void;
  activeSidebarTab: SidebarTab;
  onTabChange: (tab: SidebarTab) => void;
  // Paste chat tab
  pastedChatText: string;
  onChangePastedChat: (text: string) => void;
  onClearPastedChat: () => void;
  isPastedCopied: boolean;
  onCopyPastedChat: () => void;
  onLoadActiveChatToPaste?: () => void;
  onRestoreFromPaste?: () => void;
  onUpdateSettings?: (settings: ChatSettings) => void;
  // Secure storage tab
  showEncryptedLog: boolean;
  onToggleEncryptedLog: () => void;
  isDecryptingLogs: boolean;
  editingLogId: string | null;
  editingLogText: string;
  onStartEditLog: (id: string, text: string) => void;
  onChangeEditingLogText: (text: string) => void;
  onCancelEditLog: () => void;
  onSaveLog: (id: string) => void;
  onDeleteLog: (id: string) => void;
  // NPC tab
  isEditingNpc: boolean;
  editedNpc: Partial<Character>;
  onStartEditNpc: () => void;
  onCancelEditNpc: () => void;
  onChangeEditedNpc: (updated: Partial<Character>) => void;
  onSaveNpc: () => void;
  onRequestDeleteNpc: () => void;
  playAudioCue: (type: "click" | "receive" | "reset" | "reflect" | "send") => void;
}

export default function ChatSidebar({
  character,
  settings,
  messages,
  showMobileDetails,
  onCloseMobileDetails,
  activeSidebarTab,
  onTabChange,
  pastedChatText,
  onChangePastedChat,
  onClearPastedChat,
  isPastedCopied,
  onCopyPastedChat,
  onLoadActiveChatToPaste,
  onRestoreFromPaste,
  onUpdateSettings,
  showEncryptedLog,
  onToggleEncryptedLog,
  isDecryptingLogs,
  editingLogId,
  editingLogText,
  onStartEditLog,
  onChangeEditingLogText,
  onCancelEditLog,
  onSaveLog,
  onDeleteLog,
  isEditingNpc,
  editedNpc,
  onStartEditNpc,
  onCancelEditNpc,
  onChangeEditedNpc,
  onSaveNpc,
  onRequestDeleteNpc,
  playAudioCue,
}: ChatSidebarProps) {
  const defaultAvatar = `https://api.dicebear.com/7.x/${
    character.persona === "cyberpunk"
      ? "bottts"
      : character.persona === "horror"
      ? "identicon"
      : character.persona === "detective"
      ? "micah"
      : "pixel-art"
  }/svg?seed=${encodeURIComponent(character.name)}`;

  return (
    <>
      {/* Mobile Drawer Backdrop */}
      {showMobileDetails && (
        <div
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 lg:hidden transition-all"
          onClick={onCloseMobileDetails}
        />
      )}

      {/* RIGHT SIDEBAR CONTAINER */}
      <div
        className={`
        fixed inset-y-0 right-0 z-50 w-80 bg-[#0d0e14] border-l border-white/10 p-6 flex flex-col space-y-6 overflow-y-auto
        transform transition-transform duration-300 ease-in-out lg:static lg:w-80 lg:p-0 lg:z-auto lg:overflow-y-visible lg:h-auto lg:bg-transparent lg:border-l-0
        ${
          showMobileDetails
            ? "translate-x-0 shadow-[-5px_0_25px_rgba(0,0,0,0.5)]"
            : "translate-x-full lg:translate-x-0"
        }
      `}
      >
        {/* Mobile Close Header */}
        <div className="flex lg:hidden items-center justify-between border-b border-white/5 pb-3">
          <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
            Detail & Log Enkripsi
          </span>
          <button
            onClick={onCloseMobileDetails}
            className="p-1.5 bg-white/5 border border-white/10 rounded-lg text-gray-400 hover:text-white transition cursor-pointer"
            title="Tutup Detail"
          >
            <X size={14} />
          </button>
        </div>

        {/* TAB SWITCHER */}
        <div className="flex bg-black/40 p-1 rounded-xl border border-white/5 gap-0.5 shadow-inner shrink-0 overflow-x-auto scrollbar-none">
          <button
            onClick={() => {
              playAudioCue("send");
              onTabChange("npc");
            }}
            className={`flex-1 min-w-[50px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 cursor-pointer ${
              activeSidebarTab === "npc"
                ? "bg-gradient-to-r from-purple-600/90 to-indigo-600/90 text-white shadow-[0_0_15px_rgba(168,85,247,0.3)] border border-purple-500/30"
                : "text-gray-400 hover:text-white hover:bg-white/5"
            }`}
          >
            👤 NPC
          </button>
          <button
            onClick={() => {
              playAudioCue("reflect");
              onTabChange("paste_chat");
            }}
            className={`flex-1 min-w-[70px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 relative cursor-pointer ${
              activeSidebarTab === "paste_chat"
                ? "bg-gradient-to-r from-cyan-600/90 to-purple-600/90 text-white shadow-[0_0_15px_rgba(6,182,212,0.3)] border border-cyan-500/30"
                : "text-gray-400 hover:text-white hover:bg-white/5"
            }`}
          >
            📋 PASTE
          </button>
          <button
            onClick={() => {
              playAudioCue("send");
              onTabChange("secure_storage");
            }}
            className={`flex-1 min-w-[60px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 cursor-pointer ${
              activeSidebarTab === "secure_storage"
                ? "bg-gradient-to-r from-emerald-600/90 to-teal-600/90 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)] border border-emerald-500/30"
                : "text-gray-400 hover:text-white hover:bg-white/5"
            }`}
          >
            🔒 SECURE
          </button>
          <button
            onClick={() => {
              playAudioCue("click");
              onTabChange("ai_settings");
            }}
            className={`flex-1 min-w-[70px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 cursor-pointer ${
              activeSidebarTab === "ai_settings"
                ? "bg-gradient-to-r from-blue-600/90 to-cyan-600/90 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)] border border-blue-500/30"
                : "text-gray-400 hover:text-white hover:bg-white/5"
            }`}
          >
            🤖 AI MODE
          </button>
        </div>

        {/* TAB 1: PASTE CHAT */}
        {activeSidebarTab === "paste_chat" ? (
          <div className="p-4 bg-[#0a0a14]/95 border border-purple-500/25 rounded-2xl shadow-xl flex flex-col flex-1 min-h-0 text-left">
            <div className="flex flex-col gap-2 shrink-0 mb-3 border-b border-white/5 pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <h4 className="text-[10px] font-black uppercase tracking-wider text-cyan-400 font-mono">
                    📋 MEMORY SYNCHRONIZER (PASTE CHAT)
                  </h4>
                </div>
                <span
                  className={`text-[8px] border px-1.5 py-0.5 rounded font-mono font-bold ${
                    settings.pasteChatEnabled !== false && pastedChatText.trim()
                      ? "bg-cyan-500/10 border-cyan-500/30 text-cyan-300"
                      : "bg-white/5 border-white/10 text-gray-400"
                  }`}
                >
                  {settings.pasteChatEnabled !== false && pastedChatText.trim()
                    ? "AKTIF DI AI"
                    : "STANDBY"}
                </span>
              </div>
              <p className="text-[9px] text-gray-400 leading-normal">
                Tempel salinan percakapan, ringkasan lore, atau sesi chat sebelumnya di sini agar AI
                otomatis mengingat konteks cerita dan bertindak sesuai riwayat tersebut.
              </p>

              <div className="flex items-center justify-between p-2 bg-purple-950/25 border border-purple-500/20 rounded-xl mt-1">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span
                    className={`w-2 h-2 rounded-full shrink-0 ${
                      settings.pasteChatEnabled !== false && pastedChatText.trim()
                        ? "bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(6,182,212,0.8)]"
                        : "bg-gray-500"
                    }`}
                  />
                  <span className="text-[9px] font-bold text-gray-200 truncate font-mono">
                    {settings.pasteChatEnabled !== false
                      ? pastedChatText.trim()
                        ? "AI Membaca Konteks Ini"
                        : "Aktif (Menunggu Teks)"
                      : "Nonaktif (AI Mengabaikan Teks)"}
                  </span>
                </div>
                <button
                  onClick={() => {
                    playAudioCue("click");
                    if (onUpdateSettings) {
                      onUpdateSettings({
                        ...settings,
                        pasteChatEnabled: settings.pasteChatEnabled === false,
                      });
                    }
                  }}
                  className={`px-2 py-0.5 rounded text-[8px] font-bold font-mono uppercase transition cursor-pointer ${
                    settings.pasteChatEnabled !== false
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-[0_0_8px_rgba(6,182,212,0.3)]"
                      : "bg-white/5 text-gray-400 border border-white/10 hover:text-white"
                  }`}
                  title="Aktifkan atau nonaktifkan pengaruh Paste Chat ke AI"
                >
                  {settings.pasteChatEnabled !== false ? "TERHUBUNG AI" : "TERPUTUS"}
                </button>
              </div>
            </div>

            <div className="flex-1 flex flex-col min-h-0 space-y-3">
              <div className="flex-1 flex flex-col min-h-0 relative">
                <textarea
                  value={pastedChatText}
                  onChange={(e) => onChangePastedChat(e.target.value)}
                  placeholder={`Contoh format:\nAnda: Halo, siapa kamu?\n${character.name}: Saya adalah penjelajah biner...\n\nTempel teks chat di sini...`}
                  className="w-full flex-1 bg-black/50 border border-white/10 rounded-xl p-3 text-[11px] font-sans text-gray-200 placeholder-gray-600 focus:border-cyan-400/50 outline-none resize-none leading-relaxed custom-scrollbar"
                />
              </div>

              <div className="flex items-center justify-between text-[9px] text-gray-400 font-mono shrink-0">
                <span>{pastedChatText.length} Karakter Tersimpan</span>
                <div className="flex gap-2">
                  {pastedChatText && (
                    <button
                      onClick={onClearPastedChat}
                      className="px-2 py-1 bg-red-950/30 border border-red-500/20 hover:bg-red-900/40 text-red-300 rounded text-[9px] transition cursor-pointer"
                    >
                      Kosongkan
                    </button>
                  )}
                  {pastedChatText && (
                    <button
                      onClick={onCopyPastedChat}
                      className="px-2 py-1 bg-white/5 border border-white/10 hover:bg-white/10 text-gray-300 rounded text-[9px] transition flex items-center gap-1 cursor-pointer"
                    >
                      {isPastedCopied ? (
                        <>
                          <Check size={10} className="text-cyan-400" /> Tersalin
                        </>
                      ) : (
                        <>
                          <Copy size={10} /> Salin
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>

              {(onLoadActiveChatToPaste || onRestoreFromPaste) && (
                <div className="grid grid-cols-2 gap-2 shrink-0 pt-1">
                  {onLoadActiveChatToPaste && (
                    <button
                      onClick={onLoadActiveChatToPaste}
                      className="py-1.5 px-2 bg-purple-950/40 hover:bg-purple-900/40 border border-purple-500/35 text-purple-300 hover:text-white rounded-xl text-[9px] font-bold transition flex items-center justify-center gap-1 cursor-pointer active:scale-95"
                      title="Salin semua pesan di ruang obrolan saat ini"
                    >
                      📥 Salin Obrolan Aktif
                    </button>
                  )}
                  {onRestoreFromPaste && (
                    <button
                      onClick={onRestoreFromPaste}
                      disabled={!pastedChatText.trim()}
                      className="py-1.5 px-2 bg-cyan-950/40 hover:bg-cyan-900/40 border border-cyan-500/35 text-cyan-300 hover:text-white rounded-xl text-[9px] font-bold transition flex items-center justify-center gap-1 cursor-pointer disabled:opacity-30 active:scale-95"
                      title="Gantikan riwayat pesan aktif dengan teks di atas"
                    >
                      🔄 Pulihkan Obrolan
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        ) : activeSidebarTab === "secure_storage" ? (
          /* TAB 2: SECURE STORAGE LOGS */
          <div className="p-4 bg-[#0a0a14]/95 border border-purple-500/25 rounded-2xl shadow-xl flex flex-col flex-1 min-h-0 text-left space-y-3">
            <div className="flex items-center justify-between border-b border-white/5 pb-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
                <Lock size={12} className="text-emerald-400" /> Secure Storage Logs
              </h4>
              <button
                onClick={onToggleEncryptedLog}
                className="p-1.5 bg-white/5 border border-white/10 hover:border-emerald-500/30 text-gray-400 hover:text-emerald-300 rounded-lg transition cursor-pointer"
              >
                {showEncryptedLog ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>

            {isDecryptingLogs ? (
              <div className="text-center py-12 text-emerald-400 font-mono text-xs flex items-center justify-center gap-2 flex-1">
                <RefreshCw className="animate-spin" size={14} />
                <span>SINKRONISASI & DEKRIPSI...</span>
              </div>
            ) : showEncryptedLog ? (
              <div className="space-y-2 flex-1 overflow-y-auto bg-black/40 border border-white/5 p-3 rounded-xl custom-scrollbar min-h-0">
                <div className="text-[9px] text-emerald-400 font-mono mb-2 border-b border-white/5 pb-1 flex justify-between">
                  <span>RAW PLAINTEXT DECRYPTED</span>
                  <span>STATUS: SECURE</span>
                </div>
                {messages.map((m, i) => (
                  <div
                    key={m.id || i}
                    className="text-[10px] border-b border-white/5 pb-2 mb-2 text-gray-300 relative group"
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-sans font-semibold text-gray-500 mr-1 text-[9px] uppercase">
                        [{m.role}]:
                      </span>
                      <div className="hidden group-hover:flex items-center gap-1">
                        <button
                          onClick={() => onStartEditLog(m.id, m.content)}
                          className="p-1 hover:bg-white/10 rounded text-cyan-400 transition"
                          title="Edit Log"
                        >
                          <Edit3 size={10} />
                        </button>
                        <button
                          onClick={() => onDeleteLog(m.id)}
                          className="p-1 hover:bg-red-500/20 rounded text-red-400 transition"
                          title="Delete Log"
                        >
                          <Trash2 size={10} />
                        </button>
                      </div>
                    </div>
                    {editingLogId === m.id ? (
                      <div className="space-y-1 mt-1">
                        <textarea
                          rows={3}
                          value={editingLogText}
                          onChange={(e) => onChangeEditingLogText(e.target.value)}
                          className="w-full bg-black/60 border border-white/10 p-1.5 rounded text-[9px] font-mono text-white outline-none resize-none"
                        />
                        <div className="flex justify-end gap-1">
                          <button
                            onClick={onCancelEditLog}
                            className="px-2 py-0.5 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-[9px]"
                          >
                            Batal
                          </button>
                          <button
                            onClick={() => onSaveLog(m.id)}
                            className="px-2 py-0.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 rounded text-[9px] text-white font-bold cursor-pointer"
                          >
                            Simpan
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="font-serif leading-tight">{m.content}</div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2 flex-1 overflow-y-auto bg-black/40 border border-white/5 p-3 rounded-xl font-mono text-[9px] text-gray-600 break-all select-none leading-normal custom-scrollbar min-h-0">
                <div className="text-[9px] text-gray-500 mb-2 border-b border-white/5 pb-1 flex justify-between">
                  <span>CIPHERTEXT AES/B64 ENCRYPTED</span>
                  <span>STATUS: ENCRYPTED</span>
                </div>
                {messages.map((m, i) => (
                  <div key={i} className="mb-2">
                    <span className="text-blue-500/50">
                      [{m.role === "user" ? "USR_CIPHER" : "NPC_CIPHER"}]:
                    </span>
                    <div className="text-gray-500 bg-white/[0.01] p-1 rounded mt-0.5 font-mono">
                      {encryptMessage(m.content).slice(0, 120)}...
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="text-[10px] text-gray-500 leading-relaxed shrink-0">
              Semua riwayat terenkripsi otomatis di tingkat lokal & cloud secara asinkron agar aman dari
              intervensi luar.
            </div>
          </div>
        ) : activeSidebarTab === "ai_settings" ? (
          /* TAB 3: AI COGNITIVE CORE */
          <div className="p-4 bg-[#0a0a14]/95 border border-purple-500/25 rounded-2xl shadow-xl flex flex-col flex-1 min-h-0 text-left overflow-y-auto custom-scrollbar space-y-4">
            <div className="flex flex-col gap-1 border-b border-white/5 pb-2">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                <h4 className="text-[10px] font-black uppercase tracking-wider text-blue-400 font-mono">
                  🤖 AI COGNITIVE CORE & MODE
                </h4>
              </div>
              <p className="text-[9px] text-gray-400 leading-normal">
                Sesuaikan model otak neural dan panjang teks respon secara langsung.
              </p>
            </div>

            {/* Model Provider */}
            <div className="space-y-1.5">
              <span className="text-[10px] text-cyan-400 uppercase font-mono font-bold block">
                Model Bahasa AI
              </span>
              <select
                value={settings.model || "gemini-3.8-flash"}
                onChange={(e) => {
                  playAudioCue("click");
                  if (onUpdateSettings) {
                    onUpdateSettings({ ...settings, model: e.target.value });
                  }
                }}
                className="w-full bg-black/50 border border-white/10 rounded-xl p-2.5 text-xs text-white focus:border-cyan-400 outline-none"
              >
                <option value="gemini-3.8-flash">Gemini 3.8 Flash (Deep Reasoning - Sangat Direkomendasikan)</option>
                <option value="gemini-3.5-flash">Gemini 3.5 Flash (Default)</option>
                <option value="gemini-2.5-flash">Gemini 2.5 Flash (Stabil & Cepat)</option>
                <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Super Cepat & Hemat Kuota)</option>
              </select>
            </div>

            {/* Text Length Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between items-center text-[10px] font-mono">
                <span className="text-gray-300 font-bold uppercase">Panjang Jawaban NPC</span>
                <span className="text-cyan-400 font-bold">
                  {settings.textLength === 1
                    ? "Ringkas (~1 Paragraf)"
                    : settings.textLength === 2
                    ? "Sedang (~2-3 Paragraf)"
                    : "Mendalam (~4+ Paragraf Deskriptif)"}
                </span>
              </div>
              <input
                type="range"
                min={1}
                max={3}
                step={1}
                value={settings.textLength ?? 2}
                onChange={(e) => {
                  playAudioCue("click");
                  if (onUpdateSettings) {
                    onUpdateSettings({
                      ...settings,
                      textLength: parseInt(e.target.value, 10) as any,
                    });
                  }
                }}
                className="w-full accent-cyan-400"
              />
            </div>
          </div>
        ) : (
          /* TAB 4: NPC DOSSIER */
          <div className="p-4 bg-[#0a0a14]/95 border border-purple-500/25 rounded-2xl shadow-xl flex flex-col flex-1 min-h-0 text-left overflow-y-auto custom-scrollbar space-y-4">
            <div className="flex items-center justify-between border-b border-white/5 pb-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
                👤 NPC Dossier: {character.name}
              </h4>
              {!isEditingNpc ? (
                <button
                  onClick={onStartEditNpc}
                  className="p-1.5 hover:bg-white/10 rounded-lg text-cyan-400 hover:text-white transition cursor-pointer"
                  title="Edit Karakter"
                >
                  <Edit3 size={13} />
                </button>
              ) : (
                <button
                  onClick={onCancelEditNpc}
                  className="text-[10px] text-gray-400 hover:text-white"
                >
                  Batal
                </button>
              )}
            </div>

            <div className="space-y-3 flex-1">
              <div className="flex items-center gap-3">
                <img
                  src={character.avatarUrl || defaultAvatar}
                  alt={character.name}
                  className="w-14 h-14 rounded-2xl object-cover border border-purple-500/30"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h3 className="font-black text-sm text-white">{character.name}</h3>
                  <span className="text-[10px] text-cyan-400 uppercase font-mono font-bold">
                    {character.persona} • {character.gender || "Bebas"}
                  </span>
                </div>
              </div>

              {isEditingNpc ? (
                <div className="space-y-2.5">
                  <div>
                    <label className="text-[9px] uppercase font-mono text-gray-400 block mb-1">
                      Nama Karakter
                    </label>
                    <input
                      type="text"
                      value={editedNpc.name || ""}
                      onChange={(e) => onChangeEditedNpc({ name: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] uppercase font-mono text-gray-400 block mb-1">
                      Latar Belakang
                    </label>
                    <textarea
                      rows={3}
                      value={editedNpc.background || ""}
                      onChange={(e) => onChangeEditedNpc({ background: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white outline-none focus:border-cyan-400 resize-none leading-relaxed"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] uppercase font-mono text-gray-400 block mb-1">
                      Kepribadian
                    </label>
                    <textarea
                      rows={3}
                      value={editedNpc.personality || ""}
                      onChange={(e) => onChangeEditedNpc({ personality: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white outline-none focus:border-cyan-400 resize-none leading-relaxed"
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      onClick={onCancelEditNpc}
                      className="px-3 py-1 bg-white/5 rounded-lg text-xs text-gray-300"
                    >
                      Batal
                    </button>
                    <button
                      onClick={onSaveNpc}
                      className="px-3 py-1 bg-gradient-to-r from-purple-600 to-cyan-500 rounded-lg text-xs text-white font-bold cursor-pointer"
                    >
                      Simpan
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 text-xs">
                  <div>
                    <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                      Definisi Karakter
                    </span>
                    <p className="text-xs text-gray-300 leading-relaxed font-sans bg-black/20 p-2.5 rounded border border-white/5 whitespace-pre-wrap">
                      {character.background || "Belum ada definisi karakter."}
                    </p>
                  </div>
                  <div>
                    <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                      Kepribadian
                    </span>
                    <p className="text-xs text-gray-300 leading-relaxed font-sans bg-black/20 p-2.5 rounded border border-white/5 whitespace-pre-wrap">
                      {character.personality || "Belum ada rincian kepribadian."}
                    </p>
                  </div>
                </div>
              )}

              {/* Neural Memories Section */}
              <div className="border-t border-white/5 pt-3 space-y-2">
                <span className="text-[10px] text-purple-400 uppercase tracking-widest block font-bold font-mono">
                  🧠 Memori Enkripsi NPC
                </span>
                <p className="text-[9px] text-gray-400 leading-relaxed font-sans">
                  *Memori biner diekstrak & disimpan secara otomatis dari petualangan Anda.*
                </p>
                {character.memories && character.memories.length > 0 ? (
                  <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1 custom-scrollbar">
                    {character.memories.map((memory, index) => (
                      <div
                        key={index}
                        className="bg-purple-950/20 border border-purple-500/20 p-2.5 rounded-xl text-[11px] text-gray-300 font-sans leading-relaxed relative overflow-hidden group hover:border-cyan-500/30 transition-all"
                      >
                        <div className="absolute top-0 right-0 w-1.5 h-full bg-purple-500 group-hover:bg-cyan-500 transition-colors" />
                        <span className="block font-semibold text-[9px] text-cyan-400 mb-0.5 font-mono">
                          #MEMORI_{index + 1}
                        </span>
                        {memory}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-black/30 border border-dashed border-white/5 p-3 rounded-xl text-center text-[10px] text-gray-500">
                    Belum ada ingatan terenkripsi. Terus ajak {character.name} berbicara untuk merajut
                    benang memori!
                  </div>
                )}
              </div>

              {!character.isDefault && (
                <div className="border-t border-white/5 pt-4 shrink-0">
                  <button
                    onClick={onRequestDeleteNpc}
                    className="w-full py-2 bg-red-950/20 hover:bg-red-950/40 text-red-400 border border-red-500/10 rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <Trash2 size={13} /> Hapus Karakter Ini
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </>
  );
}
