import React from "react";
import { Menu, Compass, Home, Settings as SettingsIcon } from "lucide-react";
import MusicPlayer from "../MusicPlayer";

interface HeaderProps {
  view: "home" | "chat" | "settings" | "create" | "rebirth";
  onOpenMobileSidebar: () => void;
  onNavigateHome: () => void;
  onOpenSettings: () => void;
}

export default function Header({
  view,
  onOpenMobileSidebar,
  onNavigateHome,
  onOpenSettings,
}: HeaderProps) {
  return (
    <header className="h-16 border-b border-white/5 px-3 sm:px-6 flex items-center justify-between backdrop-blur-sm bg-black/10 shrink-0">
      <div className="flex items-center gap-2 sm:gap-3.5 min-w-0">
        {/* Hamburger button for mobile */}
        <button
          onClick={onOpenMobileSidebar}
          className="p-2 md:hidden hover:bg-white/5 border border-purple-500/20 rounded-xl text-gray-300 hover:text-white transition cursor-pointer active:scale-95 shrink-0"
          title="Menu Karakter"
        >
          <Menu size={18} />
        </button>

        <button
          onClick={onNavigateHome}
          className="text-xs sm:text-sm font-semibold tracking-wide hover:text-cyan-400 transition flex items-center gap-1.5 sm:gap-2 truncate cursor-pointer"
        >
          <Compass size={18} className="shrink-0 text-cyan-400" />
          <span className="truncate">Roleplay Stage</span>
        </button>

        {/* Custom Atmospheric Music Controller & Playlist Dropdown */}
        <MusicPlayer />
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {view !== "home" && (
          <button
            onClick={onNavigateHome}
            className="px-2.5 sm:px-3 py-1.5 bg-white/5 border border-white/10 rounded-lg text-xs hover:bg-white/10 hover:text-white text-gray-300 transition flex items-center gap-1 cursor-pointer font-medium active:scale-95 shrink-0"
          >
            <Home size={14} />
            <span className="hidden sm:inline">Kembali ke Menu Utama</span>
            <span className="sm:hidden">Menu</span>
          </button>
        )}
        <button
          onClick={onOpenSettings}
          className="p-2 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 hover:text-cyan-400 transition shrink-0 active:scale-95 cursor-pointer"
          title="Pengaturan"
        >
          <SettingsIcon size={16} />
        </button>
      </div>
    </header>
  );
}
