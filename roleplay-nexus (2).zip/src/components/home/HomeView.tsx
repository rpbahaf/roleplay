import React from "react";
import HomeHero from "./HomeHero";
import SuggestionCards from "./SuggestionCards";
import FloatingPromptBar from "./FloatingPromptBar";
import InstantSummoner, { PersonaType } from "./InstantSummoner";
import CharacterList, { GenreTab } from "./CharacterList";
import AnimeArtStudio from "../AnimeArtStudio";
import { Character } from "../../types";
import { Sparkles } from "lucide-react";

interface HomeViewProps {
  user: { uid: string; displayName: string; photoURL?: string } | null;
  character: Character | null;
  characters: Character[];
  loadingChars: boolean;
  mainPromptInput: string;
  onChangePromptInput: (val: string) => void;
  onSubmitPrompt: () => void;
  onSelectSuggestion: (persona: string, promptText: string) => void;
  onSelectCharacter: (char: Character) => void;
  onOpenCreate: () => void;
  onOpenRebirth: () => void;
  // Summoner props
  isSummoning: boolean;
  summonPersona: PersonaType;
  onPersonaChange: (persona: PersonaType) => void;
  onInstantSummon: () => void;
  summonError: string | null;
  // Character list props
  activeTab: GenreTab;
  onTabChange: (tab: GenreTab) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onSelectProfile: (char: Character) => void;
  onStartChat: (char: Character) => void;
  onConfirmDelete: (charId: string) => void;
  // Audio & Toast props for AnimeArtStudio
  playAudioCue: (type: "click" | "receive" | "reset" | "reflect" | "send") => void;
  showToast: (msg: string) => void;
}

export default function HomeView({
  user,
  character,
  characters,
  loadingChars,
  mainPromptInput,
  onChangePromptInput,
  onSubmitPrompt,
  onSelectSuggestion,
  onSelectCharacter,
  onOpenCreate,
  onOpenRebirth,
  isSummoning,
  summonPersona,
  onPersonaChange,
  onInstantSummon,
  summonError,
  activeTab,
  onTabChange,
  searchQuery,
  onSearchChange,
  onSelectProfile,
  onStartChat,
  onConfirmDelete,
  playAudioCue,
  showToast,
}: HomeViewProps) {
  return (
    <div className="space-y-8 max-w-4xl mx-auto relative animate-fade-in">
      {/* GORGEOUS ISEKAI REBIRTH PORTAL BANNER */}
      <div className="bg-gradient-to-r from-[#170e34] via-[#09061c] to-[#0a182c] border border-purple-500/30 rounded-2xl p-5 md:p-6 shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-5">
        <div className="absolute top-0 right-0 w-48 h-48 bg-purple-500/10 rounded-full blur-[50px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-36 h-36 bg-cyan-500/10 rounded-full blur-[40px] pointer-events-none" />
        
        <div className="flex items-center gap-4 relative z-10">
          <div className="w-14 h-14 md:w-16 md:h-16 rounded-xl overflow-hidden border border-purple-500/30 shadow-lg shrink-0 relative">
            <img 
              src="/src/assets/images/goddess_of_rebirth_1790605102592.jpg" 
              alt="Dewi Reinkarnasi" 
              className="w-full h-full object-cover" 
            />
            <div className="absolute inset-0 bg-purple-500/10 animate-pulse" />
          </div>
          <div className="space-y-1">
            <span className="text-[9px] bg-purple-500/20 text-purple-300 border border-purple-500/30 px-2 py-0.5 rounded-full uppercase font-bold tracking-widest font-mono inline-block">
              ★ Rebirth Portal
            </span>
            <h3 className="text-xs md:text-sm font-black text-white leading-none">
              Gerbang Reinkarnasi (High Fantasy)
            </h3>
            <p className="text-[10px] md:text-[11px] text-gray-300 max-w-xl leading-relaxed italic">
              &ldquo;kamu baru saja mati di kehidupan mu sebelumnya, aku minta maaf karena telah terseret ke dunia ini. dan sebagai gantinya. kamu akan mendapatkan kehidupan selanjutnya. apa yang kamu minta wahai jiwa?&rdquo;
            </p>
          </div>
        </div>
        
        <button
          onClick={onOpenRebirth}
          className="px-4 py-2 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white font-black rounded-xl text-[11px] uppercase tracking-widest transition shadow-lg shadow-purple-500/20 flex items-center gap-1.5 shrink-0 active:scale-95 cursor-pointer border border-cyan-400/20 relative z-10"
        >
          <Sparkles size={12} className="animate-pulse text-yellow-300" /> Rebirth Now
        </button>
      </div>

      {/* Instant Summoning AI Portal animation and Section */}
      <InstantSummoner
        isSummoning={isSummoning}
        summonPersona={summonPersona}
        onPersonaChange={onPersonaChange}
        onInstantSummon={onInstantSummon}
        summonError={summonError}
      />

      {/* Hero Welcome Zone */}
      <HomeHero displayName={user?.displayName || "Petualang"} />

      {/* Suggestion Scenario Cards Grid */}
      <SuggestionCards onSelectSuggestion={onSelectSuggestion} />

      {/* Floating Prompt Bar with Character Selector */}
      <FloatingPromptBar
        character={character}
        characters={characters}
        onSelectCharacter={onSelectCharacter}
        onOpenCreate={onOpenCreate}
        mainPromptInput={mainPromptInput}
        onChangePromptInput={onChangePromptInput}
        onSubmitPrompt={onSubmitPrompt}
      />

      {/* Character List with Faksi Filter Tabs and Search */}
      <CharacterList
        characters={characters}
        loading={loadingChars}
        activeTab={activeTab}
        onTabChange={onTabChange}
        searchQuery={searchQuery}
        onSearchChange={onSearchChange}
        onSelectProfile={onSelectProfile}
        onStartChat={onStartChat}
        onOpenCreate={onOpenCreate}
        onConfirmDelete={onConfirmDelete}
      />

      {/* AI Anime Art Studio Section */}
      <div className="border-t border-white/5 pt-8 mt-4">
        <div className="bg-[#0f111a]/40 border border-white/10 rounded-2xl p-6 md:p-8 shadow-xl">
          <AnimeArtStudio
            playAudioCue={playAudioCue}
            showToast={showToast}
          />
        </div>
      </div>
    </div>
  );
}
