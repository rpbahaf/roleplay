import { ChatSettings } from '../types';

export default function Settings({ settings, onUpdate }: { settings: ChatSettings, onUpdate: (s: ChatSettings) => void }) {
  const currentProvider = settings.provider || 'gemini';
  const getInitialModelForProvider = (provider: 'gemini' | 'groq' | 'ollama' | 'webllm' | 'openrouter' | 'openai') => {
    switch (provider) {
      case 'gemini': return 'gemini-3.8-flash';
      case 'groq': return 'llama-3.3-70b-versatile';
      case 'ollama': return 'llama3';
      case 'webllm': return 'Phi-3-mini-4k-instruct-q4f16_1-MLC';
      case 'openrouter': return 'openai/gpt-4o-mini';
      case 'openai': return 'gpt-4o-mini';
    }
  };
  const currentModel = settings.model || getInitialModelForProvider(currentProvider);

  const geminiModels = [
    { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash (Sangat Cepat & Responsif - Rekomendasi)' },
    { id: 'gemini-3.1-pro-preview', name: 'Gemini 3.1 Pro (Berpikir Kompleks, Sastrawi & Kreatif)' },
  ];

  const groqModels = [
    { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B (Recommended & Stable)' },
    { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B (Blazing Fast & Stable)' },
  ];

  const ollamaModels = [
    { id: 'llama3', name: 'Llama 3 (8B)' },
    { id: 'llama3.1', name: 'Llama 3.1' },
    { id: 'gemma2', name: 'Gemma 2' },
    { id: 'mistral', name: 'Mistral' },
    { id: 'phi3', name: 'Phi 3' },
    { id: 'qwen2', name: 'Qwen 2' },
    { id: 'custom', name: 'Custom (Tulis di bawah)' },
  ];

  const openrouterModels = [
    { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini (OpenAI)' },
    { id: 'openai/gpt-4o', name: 'GPT-4o (OpenAI)' },
    { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet (Anthropic)' },
    { id: 'anthropic/claude-3-haiku', name: 'Claude 3 Haiku (Anthropic)' },
    { id: 'google/gemini-flash-1.5', name: 'Gemini 1.5 Flash (Google)' },
    { id: 'google/gemini-pro-1.5', name: 'Gemini 1.5 Pro (Google)' },
    { id: 'meta-llama/llama-3-8b-instruct', name: 'Llama 3 8B Instruct (Meta)' },
    { id: 'meta-llama/llama-3-70b-instruct', name: 'Llama 3 70B Instruct (Meta)' }
  ];

  const webllmModels = [
    { id: 'Phi-3-mini-4k-instruct-q4f16_1-MLC', name: 'Phi 3 Mini (3.8B - Cepat & Direkomendasikan)' },
    { id: 'gemma-2b-it-q4f16_1-MLC', name: 'Gemma 2B (2B - Sangat Ringan)' },
    { id: 'TinyLlama-1.1B-Chat-v1.0-q4f16_1-MLC', name: 'TinyLlama (1.1B - Super Ringan)' },
    { id: 'Qwen2-0.5B-Instruct-q4f16_1-MLC', name: 'Qwen 2 (0.5B - Paling Ringan)' },
    { id: 'Llama-3-8B-Instruct-q4f16_1-MLC', name: 'Llama 3 (8B - Butuh GPU Kuat 6GB+)' },
  ];

  const openaiModels = [
    { id: 'gpt-4o-mini', name: 'GPT-4o Mini (OpenAI - Cepat & Hemat)' },
    { id: 'gpt-4o', name: 'GPT-4o (OpenAI - Sangat Cerdas)' },
    { id: 'o1-mini', name: 'o1-mini (OpenAI - Penalaran Logika)' },
    { id: 'custom', name: 'Custom (Tulis di bawah)' },
  ];

  const handleProviderChange = (provider: 'gemini' | 'groq' | 'ollama' | 'webllm' | 'openrouter' | 'openai') => {
    onUpdate({
      ...settings,
      provider,
      model: getInitialModelForProvider(provider),
      ollamaUrl: provider === 'ollama' ? (settings.ollamaUrl || 'http://localhost:11434') : settings.ollamaUrl
    });
  };

  const handleModelChange = (model: string) => {
    onUpdate({
      ...settings,
      model
    });
  };

  const isWebGPUSupported = typeof navigator !== 'undefined' && 'gpu' in navigator;

  return (
    <div className="p-4 bg-[#0f0b21]/40 rounded-xl border border-purple-500/15 space-y-5">
      <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">System Mode</h3>
      
      <div className="space-y-4">
        {/* Model Provider */}
        <div className="bg-white/5 rounded-lg p-3 border border-white/5 space-y-2">
          <label className="text-xs text-gray-300 block font-medium">Model Provider</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleProviderChange('gemini')}
              className={`py-2 px-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                currentProvider === 'gemini'
                  ? 'bg-gradient-to-r from-purple-600 to-cyan-500 text-white shadow-[0_0_15px_rgba(168,85,247,0.3)] border border-purple-400/30'
                  : 'bg-black/30 text-gray-400 border border-white/5 hover:bg-black/50'
              }`}
            >
              Google Gemini
            </button>
            <button
              onClick={() => handleProviderChange('groq')}
              className={`py-2 px-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                currentProvider === 'groq'
                  ? 'bg-orange-600 text-white shadow-[0_0_12px_rgba(234,88,12,0.4)] border border-orange-400/30'
                  : 'bg-black/30 text-gray-400 border border-white/5 hover:bg-black/50'
              }`}
            >
              Groq Cloud
            </button>
            <button
              onClick={() => handleProviderChange('openrouter')}
              className={`py-2 px-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                currentProvider === 'openrouter'
                  ? 'bg-rose-600 text-white shadow-[0_0_12px_rgba(225,29,72,0.4)] border border-rose-400/30'
                  : 'bg-black/30 text-gray-400 border border-white/5 hover:bg-black/50'
              }`}
            >
              OpenRouter
            </button>
            <button
              onClick={() => handleProviderChange('ollama')}
              className={`py-2 px-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                currentProvider === 'ollama'
                  ? 'bg-purple-600 text-white shadow-[0_0_12px_rgba(147,51,234,0.4)] border border-purple-400/30'
                  : 'bg-black/30 text-gray-400 border border-white/5 hover:bg-black/50'
              }`}
            >
              Ollama (Lokal)
            </button>
            <button
              onClick={() => handleProviderChange('webllm')}
              className={`py-2 px-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                currentProvider === 'webllm'
                  ? 'bg-emerald-600 text-white shadow-[0_0_12px_rgba(16,185,129,0.4)] border border-emerald-400/30'
                  : 'bg-black/30 text-gray-400 border border-white/5 hover:bg-black/50'
              }`}
            >
              WebLLM (GPU)
            </button>
            <button
              onClick={() => handleProviderChange('openai')}
              className={`py-2 px-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                currentProvider === 'openai'
                  ? 'bg-blue-600 text-white shadow-[0_0_12px_rgba(37,99,235,0.4)] border border-blue-400/30'
                  : 'bg-black/30 text-gray-400 border border-white/5 hover:bg-black/50'
              }`}
            >
              OpenAI (Kustom)
            </button>
          </div>
        </div>

        {/* Model Selection */}
        <div className="bg-white/5 rounded-lg p-3 border border-white/5 space-y-2">
          <label className="text-xs text-gray-300 block font-medium">Neural Model</label>
          <select
            value={currentModel}
            onChange={(e) => handleModelChange(e.target.value)}
            className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-2 text-xs text-white outline-none focus:border-cyan-400/50 transition font-sans"
          >
            {currentProvider === 'gemini' && geminiModels.map((m) => (
              <option key={m.id} value={m.id} className="bg-neutral-900 text-white">
                {m.name}
              </option>
            ))}
            {currentProvider === 'groq' && groqModels.map((m) => (
              <option key={m.id} value={m.id} className="bg-neutral-900 text-white">
                {m.name}
              </option>
            ))}
            {currentProvider === 'ollama' && ollamaModels.map((m) => (
              <option key={m.id} value={m.id} className="bg-neutral-900 text-white">
                {m.name}
              </option>
            ))}
            {currentProvider === 'webllm' && webllmModels.map((m) => (
              <option key={m.id} value={m.id} className="bg-neutral-900 text-white">
                {m.name}
              </option>
            ))}
            {currentProvider === 'openrouter' && openrouterModels.map((m) => (
              <option key={m.id} value={m.id} className="bg-neutral-900 text-white">
                {m.name}
              </option>
            ))}
            {currentProvider === 'openai' && openaiModels.map((m) => (
              <option key={m.id} value={m.id} className="bg-neutral-900 text-white">
                {m.name}
              </option>
            ))}
          </select>

          {/* Additional input fields for Ollama custom name or settings */}
          {currentProvider === 'ollama' && (
            <div className="space-y-2 mt-2 pt-2 border-t border-white/5">
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">Ollama API URL</label>
                <input
                  type="text"
                  value={settings.ollamaUrl || 'http://localhost:11434'}
                  onChange={(e) => onUpdate({ ...settings, ollamaUrl: e.target.value })}
                  placeholder="http://localhost:11434"
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white outline-none focus:border-purple-500/50 transition font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">Ollama API Key / Token (Opsional)</label>
                <input
                  type="password"
                  value={settings.ollamaApiKey || ''}
                  onChange={(e) => onUpdate({ ...settings, ollamaApiKey: e.target.value })}
                  placeholder="Masukkan token jika menggunakan hosted Ollama"
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white outline-none focus:border-purple-500/50 transition font-mono"
                />
              </div>
              {currentModel === 'custom' && (
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">Nama Model Kustom</label>
                  <input
                    type="text"
                    defaultValue=""
                    onChange={(e) => onUpdate({ ...settings, model: e.target.value })}
                    placeholder="Contoh: llama3:8b, mistral, gemma"
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white outline-none focus:border-purple-500/50 transition font-mono"
                  />
                </div>
              )}
              <span className="text-[10px] text-purple-400/90 block leading-normal mt-1 font-sans">
                🔌 Pastikan Ollama berjalan di komputer Anda dengan perintah: <code className="bg-black/40 px-1 py-0.5 rounded text-[9px]">OLLAMA_ORIGINS="*" ollama serve</code> agar tidak terkena hambatan CORS di peramban.
              </span>
            </div>
          )}

          {currentProvider === 'webllm' && (
            <div className="mt-2 pt-2 border-t border-white/5 space-y-2">
              <div className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${isWebGPUSupported ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`}></span>
                <span className="text-[10px] font-semibold text-gray-300">
                  Status WebGPU: {isWebGPUSupported ? 'Didukung' : 'Tidak Didukung'}
                </span>
              </div>
              {!isWebGPUSupported ? (
                <span className="text-[9px] text-red-400 block leading-normal">
                  ⚠️ Peramban Anda tidak mendukung WebGPU atau belum mengaktifkannya. WebLLM memerlukan WebGPU untuk memproses model AI secara langsung di peranti keras Anda.
                </span>
              ) : (
                <span className="text-[10px] text-emerald-400/90 block leading-normal">
                  📦 Model akan diunduh dan disimpan langsung di peramban Anda saat pertama kali memulai percakapan. Sesi berikutnya akan dimuat secara instan!
                </span>
              )}
            </div>
          )}

          {currentProvider === 'groq' && (
            <span className="text-[10px] text-orange-400/90 block leading-normal mt-1 font-sans">
              ⚡ Menggunakan API Key Groq yang Anda berikan. Kecepatan super tinggi tanpa limit berlebih!
            </span>
          )}
          {currentProvider === 'gemini' && (
            <div className="space-y-2 mt-2 pt-2 border-t border-white/5">
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">Gemini API Key (Opsional - Bebas Limit)</label>
                <input
                  type="password"
                  value={settings.geminiApiKey || ''}
                  onChange={(e) => onUpdate({ ...settings, geminiApiKey: e.target.value })}
                  placeholder="Masukkan Gemini API Key kustom Anda"
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white outline-none focus:border-cyan-400/50 transition font-mono"
                />
              </div>
              <span className="text-[10px] text-cyan-400/90 block leading-normal font-sans">
                ✨ Masukkan API Key Anda sendiri untuk menikmati batas kuota bebas limit penuh tanpa hambatan platform bersama!
              </span>
            </div>
          )}
          {currentProvider === 'openai' && (
            <div className="space-y-2 mt-2 pt-2 border-t border-white/5">
              <div>
                <label className="text-[10px] text-gray-400 block mb-1">OpenAI API Key (Kustom)</label>
                <input
                  type="password"
                  value={settings.openaiApiKey || ''}
                  onChange={(e) => onUpdate({ ...settings, openaiApiKey: e.target.value })}
                  placeholder="Masukkan sk-proj-... API Key Anda"
                  className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white outline-none focus:border-blue-500/50 transition font-mono"
                />
              </div>
              {currentModel === 'custom' && (
                <div>
                  <label className="text-[10px] text-gray-400 block mb-1">Nama Model Kustom</label>
                  <input
                    type="text"
                    defaultValue=""
                    onChange={(e) => onUpdate({ ...settings, model: e.target.value })}
                    placeholder="Contoh: gpt-4, gpt-6-luna"
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-2 py-1 text-xs text-white outline-none focus:border-blue-500/50 transition font-mono"
                  />
                </div>
              )}
              <span className="text-[10px] text-blue-400/90 block leading-normal font-sans">
                💡 Seluruh proses pemanggilan kecerdasan buatan akan langsung dihubungkan ke server resmi OpenAI menggunakan API Key pribadi Anda.
              </span>
            </div>
          )}
        </div>

        {/* Text Level Slider */}
        <div className="bg-white/5 rounded-lg p-3 border border-white/5">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs text-gray-300">Text Length</span>
            <span className="text-xs text-cyan-400 font-mono font-bold">LVL {settings.textLength}</span>
          </div>
          <input 
            type="range" 
            min="1" 
            max="5" 
            value={settings.textLength}
            onChange={(e) => onUpdate({...settings, textLength: parseInt(e.target.value) as any})}
            className="w-full accent-cyan-400 h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-gray-500 mt-1">
            <span>Short</span>
            <span>Balanced</span>
            <span>Descriptive</span>
          </div>
        </div>
        
        {/* Paste Chat Integration Toggle */}
        <div className="bg-white/5 rounded-lg p-3 border border-white/5 flex items-center justify-between">
          <div>
            <span className="text-xs text-gray-300 block">Integrasi Paste Chat (Memori)</span>
            <span className="text-[10px] text-gray-500 block">Sertakan teks Paste Chat ke dalam prompt memori AI</span>
          </div>
          <button 
            onClick={() => onUpdate({...settings, pasteChatEnabled: settings.pasteChatEnabled === false ? true : false})}
            className={`w-10 h-5 rounded-full relative border transition-all duration-300 ${
              settings.pasteChatEnabled !== false
                ? 'bg-cyan-950/60 border-cyan-500/50 shadow-[0_0_8px_rgba(6,182,212,0.3)]' 
                : 'bg-neutral-800 border-white/10'
            }`}
          >
            <div className={`absolute top-[3px] w-3 h-3 rounded-full transition-all duration-300 ${
              settings.pasteChatEnabled !== false 
                ? 'right-1 bg-cyan-400 shadow-[0_0_6px_rgba(6,182,212,0.8)]' 
                : 'left-1 bg-gray-400'
            }`}></div>
          </button>
        </div>

        {/* Mature 18+ Toggle */}
        <div className="bg-white/5 rounded-lg p-3 border border-white/5 flex items-center justify-between">
          <div>
            <span className="text-xs text-gray-300 block">Mature Language (18+)</span>
            <span className="text-[10px] text-gray-500 block">Allows NPC adult expression</span>
          </div>
          <button 
            onClick={() => onUpdate({...settings, allow18Plus: !settings.allow18Plus})}
            className={`w-10 h-5 rounded-full relative border transition-all duration-300 ${
              settings.allow18Plus 
                ? 'bg-red-900/40 border-red-500/50 shadow-[0_0_8px_rgba(239,68,68,0.3)]' 
                : 'bg-neutral-800 border-white/10'
            }`}
          >
            <div className={`absolute top-[3px] w-3 h-3 rounded-full transition-all duration-300 ${
              settings.allow18Plus 
                ? 'right-1 bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.8)]' 
                : 'left-1 bg-gray-400'
            }`}></div>
          </button>
        </div>

      </div>
    </div>
  );
}
