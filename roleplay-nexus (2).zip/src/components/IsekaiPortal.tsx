import React, { useState, useEffect } from "react";
import {
  Sparkles,
  Shield,
  Compass,
  ArrowRight,
  RefreshCw,
  Sparkle,
  Dices,
  Eye,
  Scroll,
  Wand2,
  Heart,
  Skull,
  Flame,
  CloudLightning,
  ChevronLeft
} from "lucide-react";
import { Character } from "../types";
import { playAudioCue } from "../utils/audio";

interface IsekaiPortalProps {
  userId: string;
  onRebirthComplete: (character: Character) => void;
  onBack: () => void;
  playAudioCue: (type: "click" | "receive" | "reset" | "reflect" | "send") => void;
  showToast: (msg: string) => void;
}

const RACES = [
  { id: "Elf", label: "Elf (Peri Kuno)", desc: "Mana murni berlimpah, umur panjang, dan kepekaan elemental tinggi.", bonus: "+3 INT, +2 AGI", icon: Sparkle, color: "border-emerald-500/30 text-emerald-400 bg-emerald-950/20" },
  { id: "Dragonborn", label: "Dragonborn (Naga)", desc: "Kekuatan fisik luar biasa, sisik zirah alami, dan sihir napas api.", bonus: "+3 STR, +2 VIT", icon: Flame, color: "border-orange-500/30 text-orange-400 bg-orange-950/20" },
  { id: "Celestial", label: "Celestial (Malaikat)", desc: "Aura suci, penyembuh tak berbatas, dan sayap pelindung jiwa.", bonus: "+3 INT, +2 LUK", icon: Heart, color: "border-yellow-500/30 text-yellow-400 bg-yellow-950/20" },
  { id: "Demon", label: "Demon (Iblis)", desc: "Ketahanan kegelapan, energi mana liar, dan daya juang membara.", bonus: "+3 INT, +2 STR", icon: Skull, color: "border-red-500/30 text-red-400 bg-red-950/20" },
  { id: "Beastman", label: "Beastman (Manusia Binatang)", desc: "Refleks super cepat, pancaindra tajam, dan insting tempur alami.", bonus: "+3 AGI, +2 DEX", icon: CloudLightning, color: "border-teal-500/30 text-teal-400 bg-teal-950/20" },
  { id: "Human", label: "Human (Manusia)", desc: "Adaptasi tak terbatas, keberuntungan tinggi, dan fleksibilitas takdir.", bonus: "+3 LUK, +2 DEX", icon: Compass, color: "border-cyan-500/30 text-cyan-400 bg-cyan-950/20" }
];

const CLASSES = [
  { id: "Rune Magus", label: "Rune Magus (Penyihir Aksara)", desc: "Melukis aksara magis kuno untuk perlindungan elemental." },
  { id: "Void Swordmaster", label: "Void Swordmaster (Pendekar Kehampaan)", desc: "Tebasan pedang berkecepatan cahaya yang membelah ruang dimensi." },
  { id: "Divine Alchemist", label: "Divine Alchemist (Alkemis Suci)", desc: "Meramu ramuan legendaris penyembuh serta eliksir mana murni." },
  { id: "Spirit Summoner", label: "Spirit Summoner (Pemanggil Peri)", desc: "Menjalin kontrak dengan roh alam dan makhluk mistis nirkala." },
  { id: "Shadow Rogue", label: "Shadow Rogue (Pencuri Bayangan)", desc: "Menyelinap di balik bayangan pekat untuk membunuh tanpa jejak." }
];

const PRESET_WISHES = [
  "Sistem Pengukur Level & Stats (Melihat data tersembunyi NPC)",
  "Sihir Kegelapan Tak Terbatas (Unlimited Mana untuk sihir hitam)",
  "Sentuhan Emas Alkemis (Mengubah benda biasa menjadi emas)",
  "Gerbang Dimensi Penyimpanan (Inventory tak terbatas)",
  "Pemulihan Instan (Regenerasi HP & MP super cepat)"
];

export default function IsekaiPortal({
  userId,
  onRebirthComplete,
  onBack,
  playAudioCue,
  showToast
}: IsekaiPortalProps) {
  const [step, setStep] = useState(1);
  const [typedText, setTypedText] = useState("");
  const [customWish, setCustomWish] = useState("");
  const [selectedRace, setSelectedRace] = useState("Elf");
  const [selectedClass, setSelectedClass] = useState("Rune Magus");
  const [gender, setGender] = useState<"Laki-laki" | "Perempuan" | "Bebas">("Bebas");
  const [characterName, setCharacterName] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  // RPG stats
  const [stats, setStats] = useState({
    STR: 10,
    AGI: 10,
    INT: 10,
    VIT: 10,
    DEX: 10,
    LUK: 10
  });
  const [rollsLeft, setRollsLeft] = useState(5);

  const fullPrompt =
    "kamu baru saja mati di kehidupan mu sebelumnya, aku minta maaf karena telah terseret ke dunia ini. dan sebagai gantinya. kamu akan mendapatkan kehidupan selanjutnya. apa yang kamu minta wahai jiwa?";

  // Typing effect on mount
  useEffect(() => {
    let index = 0;
    const interval = setInterval(() => {
      setTypedText((prev) => prev + fullPrompt.charAt(index));
      index++;
      if (index >= fullPrompt.length) {
        clearInterval(interval);
      }
    }, 30);
    return () => clearInterval(interval);
  }, []);

  const handleRollStats = () => {
    if (rollsLeft <= 0) {
      showToast("⚠️ Gulungan dadu takdir Anda sudah habis!");
      return;
    }
    playAudioCue("reflect");
    
    // Random stats generator
    const newStats = {
      STR: Math.floor(Math.random() * 8) + 8,
      AGI: Math.floor(Math.random() * 8) + 8,
      INT: Math.floor(Math.random() * 8) + 8,
      VIT: Math.floor(Math.random() * 8) + 8,
      DEX: Math.floor(Math.random() * 8) + 8,
      LUK: Math.floor(Math.random() * 8) + 8
    };

    // Apply race bonus
    if (selectedRace === "Elf") {
      newStats.INT += 3;
      newStats.AGI += 2;
    } else if (selectedRace === "Dragonborn") {
      newStats.STR += 3;
      newStats.VIT += 2;
    } else if (selectedRace === "Celestial") {
      newStats.INT += 3;
      newStats.LUK += 2;
    } else if (selectedRace === "Demon") {
      newStats.INT += 3;
      newStats.STR += 2;
    } else if (selectedRace === "Beastman") {
      newStats.AGI += 3;
      newStats.DEX += 2;
    } else if (selectedRace === "Human") {
      newStats.LUK += 3;
      newStats.DEX += 2;
    }

    setStats(newStats);
    setRollsLeft((prev) => prev - 1);
    showToast("🎲 Takdir bergulir! Atribut jiwamu telah disesuaikan.");
  };

  const handleRebirthNow = async () => {
    if (!characterName.trim()) {
      showToast("⚠️ Harap masukkan nama baru untuk jiwa Anda!");
      return;
    }
    const finalWish = customWish.trim() || PRESET_WISHES[0];
    setIsGenerating(true);
    playAudioCue("send");

    let settings = null;
    try {
      const saved = localStorage.getItem("roleplay_chat_settings") || localStorage.getItem("chat_settings") || localStorage.getItem("settings");
      if (saved) {
        settings = JSON.parse(saved);
      }
    } catch (e) {
      console.warn("Failed to load settings in IsekaiPortal:", e);
    }

    try {
      const response = await fetch("/api/generate-isekai-character", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: characterName,
          gender,
          race: selectedRace,
          klass: selectedClass,
          wish: finalWish,
          stats,
          settings
        })
      });

      if (!response.ok) {
        throw new Error("Gagal merajut jalinan takdir di server.");
      }

      const characterData = await response.json();

      const newChar: Character = {
        ...characterData,
        id: `isekai_reborn_${Date.now()}`,
        userId: userId,
        isDefault: false,
        persona: "fantasy",
        aiMode: "gamemaster",
        typeAi: "creative"
      };

      // Save character to local store
      onRebirthComplete(newChar);
    } catch (err) {
      console.error(err);
      showToast("❌ Gagal reinkarnasi. Coba lagi!");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 sm:space-y-8 bg-gradient-to-b from-[#090615] via-[#0b081e] to-[#04030a] border border-purple-500/20 rounded-2xl p-4 sm:p-6 md:p-8 shadow-2xl relative overflow-hidden text-gray-100 font-sans">
      {/* Background starlight overlay */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_rgba(147,51,234,0.15)_0%,_transparent_60%)] pointer-events-none" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-lg h-1 bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-60" />

      {/* Back button */}
      <div className="flex items-center justify-between pb-4 border-b border-white/5 relative z-10">
        <button
          onClick={onBack}
          className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-xs text-gray-400 hover:text-white rounded-lg transition flex items-center gap-1 cursor-pointer"
        >
          <ChevronLeft size={14} /> Kembali ke Menu
        </button>
        <span className="text-[10px] text-cyan-400 font-mono tracking-widest font-extrabold uppercase">
          ✦ Divine Rebirth Room ✦
        </span>
      </div>

      {/* GODDESS ZONE (STEP 1) */}
      {step === 1 && (
        <div className="space-y-6 md:space-y-8 relative z-10">
          <div className="flex flex-col md:flex-row items-center gap-6 md:gap-8 bg-black/40 border border-purple-500/10 p-6 rounded-2xl relative overflow-hidden">
            {/* Visual Goddess Image Asset with animations */}
            <div className="w-32 h-32 md:w-48 md:h-48 rounded-2xl overflow-hidden border border-purple-500/30 shadow-[0_0_20px_rgba(168,85,247,0.3)] shrink-0 relative group">
              <div className="absolute inset-0 bg-gradient-to-t from-purple-950/40 via-transparent to-transparent z-10" />
              <img
                src="/src/assets/images/goddess_of_rebirth_1790605102592.jpg"
                alt="Goddess of Rebirth"
                className="w-full h-full object-cover transform group-hover:scale-105 transition duration-500"
              />
              <div className="absolute inset-0 bg-purple-500/10 animate-pulse pointer-events-none" />
            </div>

            {/* Conversation text bubble */}
            <div className="flex-1 space-y-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                <span className="text-xs text-cyan-400 font-mono font-bold tracking-widest uppercase">
                  Sang Dewi Takdir
                </span>
              </div>
              <div className="bg-purple-950/20 border border-purple-500/15 p-4 rounded-xl min-h-[90px] relative">
                <p className="text-sm md:text-base text-gray-200 italic font-medium leading-relaxed font-serif">
                  &ldquo;{typedText}&rdquo;
                </p>
                {typedText.length < fullPrompt.length && (
                  <span className="inline-block w-2 h-4 bg-cyan-400 ml-1 animate-pulse" />
                )}
              </div>
            </div>
          </div>

          {/* Preset Wishes Selector */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">
              ❖ Pilih Karunia Takdir (Cheat Skills):
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {PRESET_WISHES.map((wish, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    playAudioCue("click");
                    setCustomWish(wish);
                  }}
                  className={`p-3 text-left text-xs rounded-xl border transition ${
                    customWish === wish
                      ? "bg-purple-950/40 border-cyan-400 text-white shadow-[0_0_15px_rgba(6,182,212,0.15)]"
                      : "bg-black/30 border-white/5 text-gray-400 hover:text-white hover:border-purple-500/20"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Wand2 size={14} className="text-cyan-400" />
                    <span>{wish}</span>
                  </div>
                </button>
              ))}
            </div>

            {/* Custom Input */}
            <div className="space-y-2 pt-2">
              <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest font-mono">
                Atau Tulis Permintaan Kustom Anda:
              </label>
              <textarea
                value={customWish}
                onChange={(e) => setCustomWish(e.target.value)}
                placeholder="Contoh: Saya ingin memiliki ingatan ensiklopedia naga, pedang legendaris naga hitam, atau kekuatan mengendalikan waktu..."
                rows={3}
                className="w-full bg-black/40 border border-white/10 rounded-xl p-3.5 text-xs focus:border-cyan-400/50 outline-none transition text-white leading-relaxed resize-none"
              />
            </div>
          </div>

          {/* Action to Next Step */}
          <div className="pt-4 flex justify-end">
            <button
              onClick={() => {
                playAudioCue("click");
                setStep(2);
              }}
              disabled={!customWish.trim()}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-2 transition shadow-xl shadow-purple-500/20 cursor-pointer"
            >
              Lanjutkan Reinkarnasi <ArrowRight size={14} />
            </button>
          </div>
        </div>
      )}

      {/* CHARACTER CUSTOMIZATION & STATS ROLL (STEP 2) */}
      {step === 2 && (
        <div className="space-y-6 md:space-y-8 relative z-10 animate-fade-in">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
            {/* Left: Race & Class Choice */}
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="block text-xs font-bold text-cyan-400 uppercase tracking-widest font-mono">
                  1. Pilih Ras Anda (Reborn Race):
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {RACES.map((race) => {
                    const IconComp = race.icon;
                    return (
                      <button
                        key={race.id}
                        onClick={() => {
                          playAudioCue("click");
                          setSelectedRace(race.id);
                        }}
                        className={`p-3 text-left rounded-xl border transition flex flex-col justify-between h-24 ${
                          selectedRace === race.id
                            ? "bg-purple-950/40 border-cyan-400 text-white shadow-md"
                            : "bg-black/30 border-white/5 text-gray-400 hover:text-white"
                        }`}
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="text-xs font-bold text-white">{race.label}</span>
                          <IconComp size={14} className="text-cyan-400" />
                        </div>
                        <p className="text-[10px] text-gray-500 line-clamp-2 mt-1 leading-snug">
                          {race.desc}
                        </p>
                        <span className="text-[9px] font-mono font-bold text-cyan-400 mt-1">
                          {race.bonus}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-3 pt-2">
                <label className="block text-xs font-bold text-cyan-400 uppercase tracking-widest font-mono">
                  2. Pilih Spesialisasi Kelas (Class):
                </label>
                <div className="grid grid-cols-1 gap-2">
                  {CLASSES.map((kls) => (
                    <button
                      key={kls.id}
                      onClick={() => {
                        playAudioCue("click");
                        setSelectedClass(kls.id);
                      }}
                      className={`p-3 text-left rounded-xl border transition flex items-center justify-between gap-3 ${
                        selectedClass === kls.id
                          ? "bg-purple-950/40 border-cyan-400 text-white"
                          : "bg-black/30 border-white/5 text-gray-400 hover:text-white"
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="text-xs font-bold text-white">{kls.label}</div>
                        <p className="text-[10px] text-gray-500 leading-normal">
                          {kls.desc}
                        </p>
                      </div>
                      <div className={`w-3 h-3 rounded-full border flex items-center justify-center ${selectedClass === kls.id ? "border-cyan-400 bg-cyan-400" : "border-white/25"}`} />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Rolled Stats & Identity */}
            <div className="space-y-6 bg-black/40 border border-purple-500/10 p-5 rounded-2xl">
              <div className="space-y-3">
                <label className="block text-xs font-bold text-purple-400 uppercase tracking-widest font-mono">
                  3. Roll Atribut Jiwa (Starting Stats):
                </label>
                <div className="bg-black/50 p-4 rounded-xl border border-white/5 space-y-3.5">
                  <div className="grid grid-cols-2 gap-3 font-mono">
                    {Object.entries(stats).map(([stat, val]) => (
                      <div key={stat} className="flex justify-between items-center bg-purple-950/10 p-2.5 rounded-lg border border-purple-500/5">
                        <span className="text-xs text-gray-400 font-bold">{stat}</span>
                        <span className="text-sm font-black text-cyan-300 animate-pulse">{val}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/5">
                    <span className="text-[10px] text-gray-400">
                      Percobaan Tersisa: <span className="text-white font-bold">{rollsLeft}</span>
                    </span>
                    <button
                      onClick={handleRollStats}
                      disabled={rollsLeft <= 0}
                      className="px-3 py-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-lg text-xs transition flex items-center gap-1.5 cursor-pointer font-bold uppercase disabled:opacity-50"
                    >
                      <Dices size={14} /> Lempar Dadu Takdir
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-4 pt-2">
                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest font-mono mb-2">
                    4. Nama Baru Anda (Reborn Name):
                  </label>
                  <input
                    type="text"
                    required
                    value={characterName}
                    onChange={(e) => setCharacterName(e.target.value)}
                    placeholder="Contoh: Elian Frostwood, Zephyr Starfall..."
                    className="w-full bg-black/50 border border-white/10 rounded-xl p-3 text-sm focus:border-cyan-400/50 outline-none transition text-white font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest font-mono mb-2">
                    5. Identitas Gender:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {(["Laki-laki", "Perempuan", "Bebas"] as const).map((g) => (
                      <button
                        key={g}
                        onClick={() => {
                          playAudioCue("click");
                          setGender(g);
                        }}
                        className={`py-2 px-3 text-center text-xs rounded-lg border transition ${
                          gender === g
                            ? "bg-cyan-500/10 border-cyan-400 text-white font-bold"
                            : "bg-black/30 border-white/5 text-gray-400"
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-6 border-t border-white/5 flex justify-between items-center">
            <button
              onClick={() => {
                playAudioCue("click");
                setStep(1);
              }}
              disabled={isGenerating}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-xs text-gray-400 hover:text-white rounded-xl transition flex items-center gap-1 cursor-pointer"
            >
              Kembali
            </button>

            <button
              onClick={handleRebirthNow}
              disabled={!characterName.trim() || isGenerating}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-50 text-white text-xs font-black uppercase tracking-widest rounded-xl flex items-center gap-2 transition shadow-xl shadow-purple-500/20 cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <RefreshCw size={14} className="animate-spin text-white" />
                  Merajut Takdir Anda...
                </>
              ) : (
                <>
                  <Sparkles size={14} className="animate-pulse" />
                  Mulai Reinkarnasi & Bermain
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
