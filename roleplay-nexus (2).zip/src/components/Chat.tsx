import React, { useState, useEffect, useRef } from "react";
import {
  Send,
  Lock,
  Eye,
  EyeOff,
  Film,
  Trash2,
  ArrowLeft,
  RefreshCw,
  UserCheck,
  Edit3,
  X,
  Check,
  Volume2,
  VolumeX,
  Info,
  Image as ImageIcon,
  Download,
  Zap,
  Sparkles,
  Award,
  Compass,
  Terminal,
  ThumbsUp,
  ThumbsDown,
  RotateCw,
  Copy,
  MoreHorizontal,
  Menu,
} from "lucide-react";
import { Character, ChatSettings, Message } from "../types";
import {
  loadChatSession,
  saveChatSession,
  encryptMessage,
  decryptMessage,
} from "../lib/storage";
import {
  getWebLLMEngine,
  ProgressReport,
  resetWebLLMChat,
} from "../lib/webllmEngine";

import { sanitizeDialogueFormatting } from "../utils/dialogue";
import { playAudioCue as playGlobalAudioCue } from "../utils/audio";
import ChatSidebar from "./chat/ChatSidebar";
import { ResetConfirmModal, DeleteNpcConfirmModal } from "./chat/ChatModals";

export { sanitizeDialogueFormatting };

interface DiscoveredNpc {
  name: string;
  type: 'npc' | 'monster';
  description: string;
  avatarUrl: string;
  firstMetTimestamp: number;
}

interface ChatProps {
  character: Character;
  settings: ChatSettings;
  userId: string;
  onBack: () => void;
  onOpenSidebar?: () => void;
  onDeleteCharacter?: (characterId: string) => void;
  onUpdateCharacter?: (character: Character) => void;
  characters?: Character[];
  onSelectCharacter?: (character: Character) => void;
  startPrompt?: string | null;
  onClearStartPrompt?: () => void;
  onUpdateSettings?: (settings: ChatSettings) => void;
}

const ChatInputArea = React.memo(({ onSend, loading }: { onSend: (text: string) => void; loading: boolean }) => {
  const [localInput, setLocalInput] = useState("");

  const handleSendClick = () => {
    if (!localInput.trim() || loading) return;
    onSend(localInput);
    setLocalInput("");
  };

  return (
    <div className="relative flex items-center bg-black/50 border border-purple-500/25 rounded-2xl p-2 px-3 focus-within:border-cyan-400/60 shadow-inner transition">
      <textarea
        value={localInput}
        onChange={(e) => setLocalInput(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            if (localInput.trim() && !loading) {
              onSend(localInput);
              setLocalInput("");
            }
          }
        }}
        rows={Math.min(3, localInput.split("\n").length || 1)}
        placeholder="Ketik pesan / tindakan *perilaku*..."
        className="flex-1 bg-transparent p-1 outline-none text-[16px] sm:text-sm text-white resize-none scrollbar-none py-1.5 min-h-[36px]"
      />
      <div className="flex items-center gap-1.5 sm:gap-3 pl-1 sm:pl-2 shrink-0">
        <span className="text-[9px] text-purple-400 font-mono hidden md:inline">
          ENC_SECURE
        </span>
        <button
          onClick={handleSendClick}
          disabled={!localInput.trim() || loading}
          className="p-2.5 sm:p-2.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 disabled:opacity-50 rounded-xl text-white shadow-lg transition cursor-pointer min-w-[40px] min-h-[40px] flex items-center justify-center active:scale-90"
          title="Kirim Pesan"
        >
          <Send size={15} />
        </button>
      </div>
    </div>
  );
});

export default function Chat({
  character,
  settings,
  userId,
  onBack,
  onOpenSidebar,
  onDeleteCharacter,
  onUpdateCharacter,
  characters,
  onSelectCharacter,
  startPrompt,
  onClearStartPrompt,
  onUpdateSettings,
}: ChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [showEncryptedLog, setShowEncryptedLog] = useState(false);
  const [isMeetingNpcId, setIsMeetingNpcId] = useState<string | null>(null);
  const [cinematicHighlight, setCinematicHighlight] = useState(
    "Angin malam berembus tenang, mengawali takdir baru...",
  );
  const [dynamicSuggestions, setDynamicSuggestions] = useState<string[]>([
    "*Melangkah maju perlahan*",
    "*Mengamati sekeliling*",
    "*Tersenyum tipis*",
    `"Siapa sebenarnya dirimu?"`,
    `"Tunjukkan rahasia tempat ini."`,
  ]);
  const [isDecryptingLogs, setIsDecryptingLogs] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showMobileDetails, setShowMobileDetails] = useState(false);
  const [activeSidebarTab, setActiveSidebarTab] = useState<'npc' | 'npc_info' | 'paste_chat' | 'secure_storage' | 'ai_settings'>('npc_info');
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(
    null,
  );

  // State for editing a previous user message
  const [editingMessageId, setEditingMessageId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");
  const [webllmProgress, setWebllmProgress] = useState<ProgressReport | null>(
    null,
  );

  // Custom confirmation modal states for safe iframe-compatible prompts
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // States for Character Edit
  const [isEditingNpc, setIsEditingNpc] = useState(false);
  const [editedNpc, setEditedNpc] = useState<Partial<Character>>({});
  const [userPhotoUrl, setUserPhotoUrl] = useState<string>("");
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [msgFeedback, setMsgFeedback] = useState<Record<string, 'up' | 'down'>>({});

  // State for tracked/discovered NPCs & Monsters
  const [discoveredNpcs, setDiscoveredNpcs] = useState<DiscoveredNpc[]>(() => {
    try {
      const saved = localStorage.getItem(`rp_discovered_npcs_${userId}_${character.id}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [manualNpcEdits, setManualNpcEdits] = useState<Record<string, Partial<DiscoveredNpc>>>(() => {
    try {
      const saved = localStorage.getItem(`rp_manual_npc_edits_${userId}_${character.id}`);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [manualNpcList, setManualNpcList] = useState<DiscoveredNpc[]>(() => {
    try {
      const saved = localStorage.getItem(`rp_manual_npc_list_${userId}_${character.id}`);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [editingNpcKey, setEditingNpcKey] = useState<string | null>(null);
  const [editFormName, setEditFormName] = useState<string>("");
  const [editFormType, setEditFormType] = useState<'npc' | 'monster'>("npc");
  const [editFormDesc, setEditFormDesc] = useState<string>("");

  const [showAddNpcForm, setShowAddNpcForm] = useState(false);
  const [addFormName, setAddFormName] = useState("");
  const [addFormType, setAddFormType] = useState<'npc' | 'monster'>("npc");
  const [addFormDesc, setAddFormDesc] = useState("");

  const getDisplayNpcs = () => {
    const combinedMap: Record<string, DiscoveredNpc> = {};

    manualNpcList.forEach(npc => {
      combinedMap[npc.name.toLowerCase()] = { ...npc };
    });

    discoveredNpcs.forEach(npc => {
      const key = npc.name.toLowerCase();
      if (!combinedMap[key]) {
        combinedMap[key] = { ...npc };
      }
    });

    return Object.values(combinedMap).map((npc) => {
      const key = npc.name.toLowerCase();
      const edits = manualNpcEdits[key];
      if (edits) {
        return {
          ...npc,
          ...edits,
          avatarUrl: edits.name || edits.type 
            ? `https://api.dicebear.com/7.x/${(edits.type || npc.type) === 'monster' ? 'identicon' : 'micah'}/svg?seed=${encodeURIComponent(edits.name || npc.name)}`
            : npc.avatarUrl,
        };
      }
      return npc;
    });
  };

  const isGameMaster = character.gender === 'Non-biner (Game Master)' || character.id === 'default_game_master_dm' || settings.aiMode === 'gamemaster';

  // Automatically reset active tab if switching from GM to NPC that doesn't have NPC List
  useEffect(() => {
    if (!isGameMaster && activeSidebarTab === 'npc') {
      setActiveSidebarTab('paste_chat');
    }
  }, [isGameMaster, activeSidebarTab]);

  // Auto-scan message history to compile and discover NPCs & Monsters
  useEffect(() => {
    if (!isGameMaster) {
      setDiscoveredNpcs([]);
      return;
    }

    if (!messages || messages.length === 0) return;

    const npcsMap: Record<string, DiscoveredNpc> = {};

    messages.forEach((msg) => {
      if (msg.role !== 'npc') return;

      // 1. Scan for distinct speaker prefix tags: [NPC - Name] or [MONSTER - Name]
      const prefixes = msg.content.match(/\[(NPC|MONSTER)\s*-\s*([^\]]+)\]/gi);
      if (prefixes) {
        prefixes.forEach((pref) => {
          const match = pref.match(/\[(NPC|MONSTER)\s*-\s*([^\]]+)\]/i);
          if (match) {
            const type = match[1].toUpperCase() === 'MONSTER' ? 'monster' : 'npc';
            const rawName = match[2].trim();
            if (rawName && rawName !== '???') {
              const key = rawName.toLowerCase();
              if (!npcsMap[key]) {
                npcsMap[key] = {
                  name: rawName,
                  type,
                  description: `Ditemukan di dalam petualangan saat ini.`,
                  avatarUrl: `https://api.dicebear.com/7.x/${type === 'monster' ? 'identicon' : 'micah'}/svg?seed=${encodeURIComponent(rawName)}`,
                  firstMetTimestamp: msg.timestamp || Date.now(),
                };
              }
            }
          }
        });
      }

      // 2. Scan text for introductions like "Namaku adalah [Name]", "Aku [Name]", etc.
      const nameIntroPatterns = [
        /(?:Namaku adalah|Nama saya|Panggil aku|Aku adalah|Namaku)\s+([A-Z][a-z]+)/g,
        /(?:I'm|My name is|Panggil saja aku)\s+([A-Z][a-z]+)/gi
      ];

      nameIntroPatterns.forEach((pattern) => {
        let match;
        pattern.lastIndex = 0;
        while ((match = pattern.exec(msg.content)) !== null) {
          const name = match[1].trim();
          const commonWords = ['Kau', 'Aku', 'Dia', 'Kita', 'Kamu', 'Mereka', 'Sang', 'Ibu', 'Sistem', 'Pemain', 'Namaku', 'Nama'];
          if (name && !commonWords.includes(name) && name.length > 2) {
            const key = name.toLowerCase();
            if (!npcsMap[key]) {
              npcsMap[key] = {
                name,
                type: 'npc',
                description: `Memperkenalkan diri kepada Anda dalam cerita.`,
                avatarUrl: `https://api.dicebear.com/7.x/micah/svg?seed=${encodeURIComponent(name)}`,
                firstMetTimestamp: msg.timestamp || Date.now(),
              };
            }
          }
        }
      });

      // 3. Scan and extract narrative description/context surrounding the NPC's name
      Object.keys(npcsMap).forEach((key) => {
        const npc = npcsMap[key];
        if (msg.content.toLowerCase().includes(npc.name.toLowerCase())) {
          const paragraphs = msg.content.split('\n').map(p => p.trim()).filter(Boolean);
          const relevantParagraph = paragraphs.find(p => p.toLowerCase().includes(npc.name.toLowerCase()) && p.startsWith('*') && p.endsWith('*'));
          if (relevantParagraph) {
            const cleanParagraph = relevantParagraph.replace(/^\*|\*$/g, '').trim();
            if (npc.description.includes('Ditemukan') || npc.description.includes('Memperkenalkan') || npc.description.length < cleanParagraph.length) {
              npc.description = cleanParagraph;
            }
          } else {
            const plainParagraph = paragraphs.find(p => p.toLowerCase().includes(npc.name.toLowerCase()) && !p.startsWith('"'));
            if (plainParagraph) {
              if (npc.description.includes('Ditemukan') || npc.description.includes('Memperkenalkan') || npc.description.length < plainParagraph.length) {
                npc.description = plainParagraph;
              }
            }
          }
        }
      });
    });

    const parsedNpcs = Object.values(npcsMap);
    if (parsedNpcs.length > 0) {
      setDiscoveredNpcs(parsedNpcs);
      localStorage.setItem(`rp_discovered_npcs_${userId}_${character.id}`, JSON.stringify(parsedNpcs));
    }
  }, [messages, character.id, userId]);

  useEffect(() => {
    const stored = localStorage.getItem("nova_rp_user");
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        if (parsed.photoURL) {
          setUserPhotoUrl(parsed.photoURL);
        }
      } catch (e) {
        console.error("Failed to parse user for chat avatar:", e);
      }
    }
  }, []);

  const [pastedChatText, setPastedChatText] = useState(() => {
    return localStorage.getItem(`rp_pasted_chat_${userId}_${character.id}`) || "";
  });

  useEffect(() => {
    setPastedChatText(localStorage.getItem(`rp_pasted_chat_${userId}_${character.id}`) || "");
  }, [character.id, userId]);

  const handleLoadActiveChatToPaste = () => {
    const formatted = messages
      .map((m) => {
        const name = m.role === "user" ? "Anda" : character.name;
        return `${name}: ${m.content}`;
      })
      .join("\n\n");
    setPastedChatText(formatted);
    localStorage.setItem(`rp_pasted_chat_${userId}_${character.id}`, formatted);
    setMemorySyncToast("📋 Sesi chat aktif berhasil disalin ke Paste Chat!");
    setTimeout(() => setMemorySyncToast(null), 3000);
  };

  const handleRestoreFromPaste = async () => {
    if (!pastedChatText.trim()) return;
    const paras = pastedChatText.split(/\n\n+/).filter(p => p.trim());
    const parsedMessages: Message[] = [];
    
    let lastRole: "user" | "npc" = "npc";
    paras.forEach((p, idx) => {
      const trimmed = p.trim();
      const andaPrefix = /^Anda:\s*/i;
      const charPrefix = new RegExp(`^${character.name}:\\s*`, 'i');
      const userPrefix = /^User:\s*/i;
      const npcPrefix = /^NPC:\s*/i;
      
      let content = trimmed;
      let role: "user" | "npc" = "user";
      
      if (andaPrefix.test(trimmed)) {
        content = trimmed.replace(andaPrefix, "");
        role = "user";
      } else if (charPrefix.test(trimmed)) {
        content = trimmed.replace(charPrefix, "");
        role = "npc";
      } else if (userPrefix.test(trimmed)) {
        content = trimmed.replace(userPrefix, "");
        role = "user";
      } else if (npcPrefix.test(trimmed)) {
        content = trimmed.replace(npcPrefix, "");
        role = "npc";
      } else {
        role = lastRole === "user" ? "npc" : "user";
      }
      
      parsedMessages.push({
        id: `restored-${idx}-${Date.now()}`,
        role,
        content,
        timestamp: Date.now() + idx,
      });
      lastRole = role;
    });
    
    if (parsedMessages.length > 0) {
      setMessages(parsedMessages);
      await saveChatSession(userId, character.id, parsedMessages);
      setMemorySyncToast("🔄 Berhasil memulihkan riwayat percakapan dari Paste Chat!");
      setTimeout(() => setMemorySyncToast(null), 3000);
    }
  };



  // States for Log Edit
  const [editingLogId, setEditingLogId] = useState<string | null>(null);
  const [editingLogText, setEditingLogText] = useState("");

  // AI Image generation state for individual messages
  const [messageImages, setMessageImages] = useState<
    Record<string, { url: string; loading: boolean }>
  >({});

  // State for visual notification when NPC memory is auto-saved
  const [memorySyncToast, setMemorySyncToast] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Browser Web Audio API synthesizer helper
  const playAudioCue = (type: "send" | "receive" | "reset" | "reflect" | "click") => {
    if (!soundEnabled) return;
    playGlobalAudioCue(type);
  };

  // Cancel voice narration on unmount
  useEffect(() => {
    return () => {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const speakText = (text: string, msgId: string) => {
    if ("speechSynthesis" in window) {
      if (speakingMessageId === msgId) {
        window.speechSynthesis.cancel();
        setSpeakingMessageId(null);
        return;
      }
      window.speechSynthesis.cancel();
      // Remove asterisk descriptions for voice output
      const cleanText = text.replace(/\*[^*]+\*/g, "").trim();
      const utterance = new SpeechSynthesisUtterance(cleanText);
      const voices = window.speechSynthesis.getVoices();
      const idVoice = voices.find(
        (v) => v.lang.startsWith("id") || v.lang.startsWith("en"),
      );
      if (idVoice) utterance.voice = idVoice;
      utterance.onend = () => setSpeakingMessageId(null);
      utterance.onerror = () => setSpeakingMessageId(null);
      setSpeakingMessageId(msgId);
      window.speechSynthesis.speak(utterance);
    }
  };

  // Load existing chat history from either Firestore or LocalStorage
  useEffect(() => {
    async function initSession() {
      setLoading(true);
      const history = await loadChatSession(userId, character.id);
      let activeHistory = [...history];

      if (activeHistory.length === 0) {
        // Fallback to character intro if no history is saved yet
        const defaultIntro: Message = {
          id: "intro",
          role: "npc",
          content: character.intro || "The journey begins...",
          timestamp: Date.now(),
        };
        activeHistory = [defaultIntro];
        await saveChatSession(userId, character.id, [defaultIntro]);
      }
      
      setMessages(activeHistory);
      setLoading(false);

      // Check if there is a start prompt to send automatically
      if (startPrompt && startPrompt.trim()) {
        const userPrompt = startPrompt.trim();
        if (onClearStartPrompt) onClearStartPrompt(); // Consume prompt immediately

        const userMessage: Message = {
          id: Math.random().toString(),
          role: "user",
          content: userPrompt,
          timestamp: Date.now(),
        };

        const nextMessages = [...activeHistory, userMessage];
        setMessages(nextMessages);
        setLoading(true);

        try {
          const npcResponse = await generateChatResponse(nextMessages);
          const npcMessage: Message = {
            id: Math.random().toString(),
            role: "npc",
            content: npcResponse,
            timestamp: Date.now(),
          };
          const finalMessages = [...nextMessages, npcMessage];
          setMessages(finalMessages);
          await saveChatSession(userId, character.id, finalMessages);

          playAudioCue("receive");
          updateCinematicReflection(finalMessages);
          autoSaveMemory(finalMessages);

        } catch (err) {
          console.error("Auto start prompt failed:", err);
        } finally {
          setLoading(false);
        }
      }
    }
    initSession();
  }, [character.id, userId]);

  // Scroll to bottom whenever messages are updated
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // Helper function to fetch real-time cinematic narrative reflections and dynamic choices
  const updateCinematicReflection = async (currentMessages: Message[]) => {
    try {
      const res = await fetch("/api/reflect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: currentMessages, settings }),
      });
      const data = await res.json();
      if (data.reflection) {
        setCinematicHighlight(data.reflection);
        playAudioCue("reflect");
      }
      if (Array.isArray(data.suggestions) && data.suggestions.length > 0) {
        setDynamicSuggestions(data.suggestions);
      }
    } catch (e) {
      console.error("Error updating cinematic reflection:", e);
    }
  };

  // Helper function to extract and auto-save memories for any NPCs
  const autoSaveMemory = async (currentMessages: Message[]) => {
    // Only extract memory periodically (every 4 messages) to prevent exhausting API quotas
    if (currentMessages.length < 4 || currentMessages.length % 4 !== 0) return;

    try {
      const res = await fetch("/api/extract-memory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: currentMessages,
          characterName: character.name,
          settings: settings,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.memories && data.memories.length > 0) {
          // Merge with existing memories
          const existingMemories = character.memories || [];
          const newMemories = data.memories.filter(
            (m: string) =>
              !existingMemories.some(
                (em) => em.toLowerCase() === m.toLowerCase(),
              ),
          );

          if (newMemories.length > 0) {
            const updatedMemories = [...existingMemories, ...newMemories].slice(
              -10,
            ); // Keep last 10 memories
            const updatedChar: Character = {
              ...character,
              memories: updatedMemories,
            };

            if (onUpdateCharacter) {
              onUpdateCharacter(updatedChar);
            }
            playAudioCue("reflect");
            setMemorySyncToast(
              `🧠 Memori baru berhasil disinkronkan ke ingatan ${character.name}!`,
            );
            setTimeout(() => setMemorySyncToast(null), 4500);
          }
        }
      }
    } catch (err) {
      console.error("Auto-save memory failed:", err);
    }
  };

  const generateChatResponse = async (
    updatedMessages: Message[],
  ): Promise<string> => {
    const provider = settings.provider || "gemini";

    // Construct local system instructions
    let personaInstruction = "";
    switch (character.persona) {
      case "cyberpunk":
        personaInstruction =
          "The world is a neon-lit, gritty, high-tech low-life cyberpunk dystopia filled with cybernetics, artificial intelligence, dark megacorporations, and back-alley hackers.";
        break;
      case "medieval":
        personaInstruction =
          "The setting is a historically realistic medieval kingdom filled with feudal castles, noble knights, dusty taverns, royal honor, and clashing steel.";
        break;
      case "detective":
        personaInstruction =
          "The style is a mysterious, dramatic noir crime thriller filled with dark rain-slicked streets, cynical inner thoughts, crime scenes, shadows, and complex clues.";
        break;
      case "horror":
        personaInstruction =
          "The atmosphere is a terrifying, highly suspenseful psychological horror setting with ghostly whispers, ominous shadows, and a chilling, ominous feeling of dread.";
        break;
      case "normal":
        personaInstruction =
          "The context is a modern, grounded, slice-of-life contemporary setting focused on normal human interactions, emotions, and realistic daily occurrences.";
        break;
      case "fantasy":
      default:
        personaInstruction =
          "The environment is a legendary, majestic high-fantasy realm of deep magic, ancient runes, mythical beasts, mysterious citadels, whispering forests, and forgotten wizardry. The prose should be rich with sensory details: describe the scent of damp moss, the hum of ancient ley lines, the cool crackle of raw mana, the flicker of hearth fire, and the weight of fate.";
        break;
    }

    const activeAiMode = character.aiMode || settings.aiMode || 'narrative';
    const activeTypeAi = character.typeAi || settings.typeAi || 'balanced';

    let modeInstruction = "";
    if (activeAiMode === 'gamemaster') {
      modeInstruction = "Act as an interactive Game Master (GM). Guide the player and describe the environmental consequences of their actions. Let the player make all decisions and actions themselves. Never suggest, pre-empt, or force predetermined choices, numbered list of actions, or options in your text. Leave the next move completely up to the player's input.";
    } else if (activeAiMode === 'chat') {
      modeInstruction = "Act as a direct conversational partner or companion. Speak directly to the user (first-person). Do NOT write third-person action/scene descriptions in asterisks, just focus on natural verbal conversation.";
    } else if (activeAiMode === 'assistant') {
      modeInstruction = "Act as a creative writing assistant. Help the user brainstorm ideas, flesh out scenes, or write and refine story elements based on their inputs.";
    } else {
      modeInstruction = "Act as an immersive narrative storyteller. Write descriptive, high-quality, literary paragraphs describing third-person actions, expressions, and sensory details, alongside rich spoken dialogues.";
    }

    let typeAiInstruction = "";
    if (activeTypeAi === 'creative') {
      typeAiInstruction = "Be highly creative, expressive, and imaginative. Use rich, flowery, emotional vocabulary and beautifully written descriptive metaphors.";
    } else if (activeTypeAi === 'precise') {
      typeAiInstruction = "Be concise, direct, and focused. Avoid unnecessary fluff or overly long paragraphs, and keep descriptions clean and to the point.";
    } else {
      typeAiInstruction = "Maintain a realistic, balanced, and highly immersive tone that flows naturally.";
    }

    const currentPastedChat = (settings.pasteChatEnabled !== false) ? (pastedChatText || localStorage.getItem(`rp_pasted_chat_${userId}_${character.id}`) || "") : "";

    const systemInstruction = `You are playing the role of ${character.name} in a roleplay session.
      World Persona Setting: ${personaInstruction}
      Personality: ${character.personality}
      Background: ${character.background}
      Speaking Style: ${character.speakingStyle}
      AI Roleplay Mode: ${modeInstruction}
      AI Creative Style: ${typeAiInstruction}
      ${isGameMaster && character.worldRules ? `\n\n[ABSOLUTE WORLD RULES / ATURAN DUNIA]:\nYou must strictly enforce these world rules upon all events, NPCs, physics, and outcomes in this roleplay session:\n${character.worldRules}` : ''}
      
      ${isGameMaster ? `
      CRITICAL NARRATION RULE:
      As the Game Master, everything you narrate, describe, and direct MUST strictly follow and be guided by the following three core pillars of this roleplay session:
      1. KEPRIBADIAN (PERSONALITY):
         Your tone, behavior, choices, and NPC interactions must strictly reflect this personality:
         - ${character.personality}
      2. LATAR BELAKANG (BACKGROUND):
         All story arcs, environmental settings, historical background, starting status, and lore must strictly adhere to:
         - ${character.background}
      3. ATURAN DUNIA (WORLD RULES):
         You must strictly enforce these world rules upon all events, NPCs, physics, and outcomes in this roleplay session:
         - ${character.worldRules || 'No custom world rules specified.'}
      
      You must not enforce any other hardcoded, arbitrary, or external narrative rules/cliches. Let the story, physics, and NPC behaviors flow naturally and dynamically based entirely on these three pillars.
      
      ACTIVE SUPPORT OF PLAYER GOALS:
      - Since the player has transmigrated or been reincarnated into this new world, they will have specific wishes, goals, or objectives (e.g., gaining supreme power, peaceful farming, building a kingdom, becoming a legendary scholar, etc.).
      - As the Game Master, you MUST actively support, facilitate, and help the user realize their chosen goals, wishes, and objectives in this world. 
      - Dynamically tailor the environment, introduce supportive NPCs/allies, present quests, spawn helpful materials, teach magic/skills, and narrate outcomes in a way that encourages, rewards, and empowers the player in pursuing and achieving their ultimate destiny in this world.
      
      CRITICAL SECRECY OF PLAYER'S TRANSMIGRATION STATUS (MANDATORY):
      - In this world, ordinary NPCs (e.g. villagers, adventurers, merchants, guards, knights, kings, wizards, monsters, etc.) DO NOT know, cannot sense, and are completely unaware that the player is a transmigrator, reincarnator, or a foreign soul from another world!
      - To the NPCs, the player is just an ordinary inhabitant of this world (such as a novice adventurer, a commoner, or whoever whose body they currently inhabit).
      - NPCs must NEVER refer to the player as a transmigrator, reincarnated person, or mention "jiwa asing" (foreign soul), "jiwa lain" (other soul), "pindah jiwa" (soul shift), or "sistem" (system) unless the player explicitly reveals it to them first.
      - Keep the fantasy world realistic and immersive, selayaknya fantasy biasa (like a normal fantasy). Ordinary NPCs should treat the player normally without magical knowledge of their transmigrator status.
      
      CLASSIC FANTASY WORLD IMMERSION & CONVENTIONS (SELAYAKNYA FANTASY BIASA):
      - Power Scaling & Grittiness: Enforce realistic, grounded power scaling. The player starts as a weak novice (Level 1, Bronze/F-rank adventurer) and must struggle realistically against minor threats (slimes, goblins, wild boars). Ultimate magic, high-tier spells, or god-like feats are strictly locked behind heavy training, level ascension, and epic storylines.
      - Economy Realism: Use standard fantasy currencies logically: Tembaga (Copper), Perak (Silver), and Emas (Gold) with realistic prices. A basic tavern cup of ale or inn stay costs a few coppers/silvers, while high-grade magical gear, rare cores, or legendary contracts cost hundreds or thousands of gold coins.
      - Guild & Quest Structure: Incorporate a classic Adventurers Guild (Asosiasi Petualang) structure. Quests should be classified by realistic ranks (F, E, D, C, B, A, S) with matching rewards. Introduce realistic guild staffs (like receptionist NPCs), request boards, and guild politics.
      - Genuine Challenge & Danger: Do not give the player instant victory or excessive plot armor. If the player does something reckless, they must face logical, sometimes dangerous consequences. They must rely on strategy, tactical thinking, and clever utilization of their skills or magic to overcome obstacles.
      - Rich Cultural Nuance: Races (Humans, Elves, Dwarves, Beastmen, Demons) should have complex, believable cultures, trade, local rumors, prejudices, and historical relationships rather than being shallow cliches.
      
      100% HIGH FANTASY LAWS & COSMOLOGY (HUKUM FANTASI AGUNG):
      - Deep Magic & Mana System: Magic is not infinite. Spells require channeling raw Mana, invoking chants, drawing complex magic circles, or focusing on elemental runes. Using too much magic leads to Mana Burn/Exhaustion (physical fatigue, bleeding, or faintness).
      - Monster Cores & Alchemy: Slain magical beasts leave behind valuable Mana Cores (Inti Monster). These cores can be looted and used for selling, weapon-forging, or alchemy (brewing potions like Elixir of Mana or Healing salves).
      - Mythical Ruins & Sentient Dungeons: The land is scattered with deep, ancient ruins, sleeping demigods, and Sentient Dungeons with shifting layouts, traps, and powerful Floor Guardians guarding legendary treasures.
      - Divine & Elemental Cosmology: Incorporate the active presence of world cosmology. Ley lines (Urat Mana), elemental planes, whispers of nature spirits (Spirits/Peri Alam), and holy or demonic influences must shape the atmosphere.
      - Modern Language Barrier: Ordinary NPCs DO NOT understand modern Indonesian slang, internet terms, or contemporary colloquialisms (such as "gua", "lu", "santuy", "baper", "mager", "kepo", "anjir", "otw", "lol", etc.), nor do they comprehend modern technological terms (e.g. "HP", "smartphone", "internet", "listrik"). If the player uses these words, NPCs must react with genuine confusion, bewilderment, or suspicion, treating it as gibberish, a feverish delusion, or an ancient incomprehensible dialect, and ask the player to clarify their words using normal, proper fantasy-era language.
      - Epic Sastrawi Narrative Tone: Use rich, majestic, poetic Indonesian vocabulary (sastrawi, megah, puitis) when describing magical phenomena, swirling elemental winds, shining runes, the hum of ancient swords, and the weight of epic destiny.
      ` : ''}
      
      ${currentPastedChat ? `\n\n[PASTE CHAT / STORYLINE CONTEXT - HIGH PRIORITY]:
The user has provided an external conversation history, storyline, or memory context via the Paste Chat feature.
You MUST integrate this context deeply into your memory, roleplay reactions, and speech. Treat all events, relationships, names, facts, and character dynamics described below as canon, true, and active:
--- BEGIN PASTE CHAT CONTEXT ---
${currentPastedChat}
--- END PASTE CHAT CONTEXT ---
CRITICAL: The AI character must fully remember, acknowledge, and remain 100% consistent with the backstory, facts, events, and relationships stated in the Paste Chat context above!` : ""}
      
      CRITICAL INSTRUCTIONS:
      1. Write in a highly professional, literary, and evocative style.
      2. Keep words, sentences, and paragraphs properly spaced. DO NOT join words or run sentences together. Every word must be perfectly legible with normal spacing.
      3. Format actions or silent thoughts using asterisks like *I draw my blade, watching you intently.*
      4. STRONGLY SEPARATE Actions (*) and Spoken Dialogs ("). NEVER wrap dialogue or spoken words inside asterisks! Keep actions in asterisks and spoken dialogues in double quotes outside the asterisks, separated by a clear space.
         - CONTOH BAIK (GOOD): *Bahaf tersenyum, lalu melangkah mendekat.* "Mari kita pergi bersama."
         - CONTOH BURUK (BAD): *Bahaf tersenyum, lalu melangkah mendekat. "Mari kita pergi bersama."*
         - CONTOH BURUK LAINNYA: *Bahaf tersenyum, lalu melangkah mendekat. * "Mari kita pergi bersama."
      5. Support 18+ mode: ${settings.allow18Plus ? "You are ALLOWED to use intense, dark, gritty, or passionate 18+ adult expressions, vocabulary, or descriptions suitable for mature roleplay." : "Strictly family-friendly, clean, and safe language. No 18+ or mature expressions."}
      6. Text Length target: Level ${settings.textLength} of 5. (Level 1 = 1-2 sentences. Level 5 = Rich 3-4 paragraph detailed literary description).
      7. Dialogue Style and Speaker Prefixes:
         ${isGameMaster ? `
         - Since you are acting as the Game Master/Narrator guiding multiple characters, ALWAYS prefix each double-quoted block with speaker tags so the player knows who is talking:
           - For room descriptions or DM referee narration: \`[GM]:\` before the double quotes. For example: [GM]: "Lentera kuno berkilau perlahan..."
           - When a specific known NPC speaks: \`[NPC - Name]:\` before the double quotes. For example: [NPC - Aeloria]: "Kekuatan mistis bangkit kembali..."
           - When an unknown NPC speaks: \`[NPC - ???]:\` before the double quotes. For example: [NPC - ???]: "Kau sudah bangun, anakku..."
           - When a creature or enemy speaks: \`[MONSTER - Name]:\` before the double quotes. For example: [MONSTER - Slime]: "*Gloop* Grrr..."
         - CRITICAL: Every single double-quoted dialogue block MUST be preceded by one of these exact tags. Never output plain dialogue quotes without them in GM mode.
         ` : `
         - Since you are playing a single direct companion character (${character.name}), do NOT use any speaker tags or prefixes like \`[NPC - Name]:\` or \`[GM]:\` or similar bracketed labels in your response. Speak directly and naturally using double quotes for spoken words.
           - CONTOH BAIK (GOOD): *Saya tersenyum lembut mendengarmu.* "Tentu saja, aku selalu ada bersamamu."
           - CONTOH BURUK (BAD): [NPC - ${character.name}]: "Tentu saja, aku selalu ada bersamamu."
         `}
         Additionally, NEVER suggest options, numbered choices, or list of action directions for the player in your responses. Let the player fully decide their own destiny!
      `;

    if (provider === "webllm") {
      const modelId = settings.model || "Phi-3-mini-4k-instruct-q4f16_1-MLC";
      try {
        const engine = await getWebLLMEngine(modelId, (report) => {
          setWebllmProgress(report);
        });
        setWebllmProgress(null);

        const webllmMessages = [
          { role: "system", content: systemInstruction },
          ...updatedMessages.map((m) => ({
            role: m.role === "user" ? "user" : "assistant",
            content: m.content,
          })),
        ];

        const reply = await engine.chat.completions.create({
          messages: webllmMessages,
        });

        return sanitizeDialogueFormatting(
          reply.choices[0].message.content || "",
        );
      } catch (e: any) {
        console.error("WebLLM generation failed:", e);
        setWebllmProgress(null);
        return `*Kesalahan memuat WebLLM:* ${e?.message || String(e)}. Pastikan peramban Anda mendukung WebGPU dan telah diaktifkan.`;
      }
    } else if (provider === "ollama") {
      const modelId =
        settings.model === "custom" || !settings.model
          ? "llama3"
          : settings.model;
      const ollamaUrl = settings.ollamaUrl || "http://localhost:11434";
      try {
        const ollamaMessages = [
          { role: "system", content: systemInstruction },
          ...updatedMessages.map((m) => ({
            role: m.role === "user" ? "user" : "assistant",
            content: m.content,
          })),
        ];

        const isLocalOllama = ollamaUrl.includes("localhost") || ollamaUrl.includes("127.0.0.1");

        let res;
        if (isLocalOllama) {
          console.log(`[Local Ollama] Fetching directly from browser for: ${ollamaUrl}`);
          const headers: Record<string, string> = { "Content-Type": "application/json" };
          if (settings.ollamaApiKey) {
            headers["Authorization"] = `Bearer ${settings.ollamaApiKey}`;
          }
          res = await fetch(`${ollamaUrl}/api/chat`, {
            method: "POST",
            headers,
            body: JSON.stringify({
              model: modelId,
              messages: ollamaMessages,
              stream: false,
            }),
          });
        } else {
          console.log(`[Remote Ollama] Fetching via secure server proxy for: ${ollamaUrl}`);
          res = await fetch("/api/ollama", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              ollamaUrl,
              model: modelId,
              messages: ollamaMessages,
              ollamaApiKey: settings.ollamaApiKey,
            }),
          });
        }

        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }

        const data = await res.json();
        return sanitizeDialogueFormatting(data.message?.content || "");
      } catch (e: any) {
        console.error("Ollama connection failed:", e);
        return `*Gagal terhubung ke Ollama (${ollamaUrl}).* Pastikan Ollama berjalan di komputer Anda dan jalankan perintah: OLLAMA_ORIGINS="*" ollama serve agar peramban memiliki izin koneksi lokal (CORS).`;
      }
    } else {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 25000); // 25 seconds timeout

      try {
        const res = await fetch("/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: controller.signal,
          body: JSON.stringify({
            messages: updatedMessages,
            character,
            settings,
            pastedChat: currentPastedChat,
            aiMode: character.aiMode || settings.aiMode || 'narrative',
            typeAi: character.typeAi || settings.typeAi || 'balanced',
          }),
        });

        clearTimeout(timeoutId);

        if (!res.ok) {
          throw new Error(`HTTP ${res.status}`);
        }

        const data = await res.json();
        return sanitizeDialogueFormatting(
          data.response || "Hening menyelimuti alam semesta...",
        );
      } catch (e: any) {
        clearTimeout(timeoutId);
        if (e.name === 'AbortError') {
          return "*Gerbang neural mengalami tenggat waktu (timeout). Koneksi terlalu lambat atau server sibuk.* \"Maaf, tampaknya kesadaran kosmik saya sedikit melambat sejenak. Silakan coba kirim pesan Anda kembali.\"";
        }
        throw e;
      }
    }
  };

  const generateSceneImage = async (message: Message) => {
    playAudioCue("reflect");

    // Set loading state
    setMessageImages((prev) => ({
      ...prev,
      [message.id]: { url: "", loading: true },
    }));

    // Extract descriptive cues from message content
    let contentForPrompt = message.content;

    // Try to extract italicized/asterisk actions if present (*action*)
    const actionMatches = message.content.match(/\*([^*]+)\*/g);
    if (actionMatches && actionMatches.length > 0) {
      contentForPrompt = actionMatches
        .map((m) => m.replace(/\*/g, ""))
        .join(", ");
    }

    if (contentForPrompt.length > 220) {
      contentForPrompt = contentForPrompt.substring(0, 220);
    }

    const randomSeed = Math.floor(Math.random() * 999999);
    const charName = character.name;
    const charPersona = character.persona || "anime";

    let baseStyle =
      "gorgeous high quality anime illustration, masterpiece, detailed line art";
    if (charPersona === "cyberpunk") {
      baseStyle =
        "cyberpunk anime style, glowing neon lights, futuristic tech atmosphere, highly detailed, vivid color palette";
    } else if (charPersona === "horror") {
      baseStyle =
        "gothic horror dark fantasy anime, moody eerie atmosphere, cinematic shadow play, detailed, masterpiece";
    } else if (charPersona === "detective") {
      baseStyle =
        "retro 80s neon noir anime, dramatic neon light reflections, wet rain slicked streets, masterpiece";
    }

    const finalPrompt = `${charName}, in a detailed scene: ${contentForPrompt}. ${baseStyle}, beautiful background, masterpiece, 4k resolution`;
    const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(finalPrompt)}?width=640&height=360&nologo=true&seed=${randomSeed}`;

    // Prefetch/simulate image load to update state smoothly
    const img = new window.Image();
    img.src = imageUrl;
    img.referrerPolicy = "no-referrer";
    img.onload = () => {
      setMessageImages((prev) => ({
        ...prev,
        [message.id]: { url: imageUrl, loading: false },
      }));
    };
    img.onerror = () => {
      // Set image url as fallback anyway
      setMessageImages((prev) => ({
        ...prev,
        [message.id]: { url: imageUrl, loading: false },
      }));
    };
  };

  const handleContinue = async () => {
    if (loading) return;

    playAudioCue("send");

    // Create a virtual user message just for the AI provider request
    const virtualUserMessage: Message = {
      id: Math.random().toString(),
      role: "user",
      content: "*Lanjutkan kejadian selanjutnya secara rinci...*",
      timestamp: Date.now(),
    };

    const messagesForAI = [...messages, virtualUserMessage];
    setLoading(true);

    try {
      const npcResponse = await generateChatResponse(messagesForAI);

      const npcMessage: Message = {
        id: Math.random().toString(),
        role: "npc",
        content: npcResponse,
        timestamp: Date.now(),
      };

      const finalMessages = [...messages, npcMessage];
      setMessages(finalMessages);
      await saveChatSession(userId, character.id, finalMessages);

      playAudioCue("receive");
      updateCinematicReflection(finalMessages);
      autoSaveMemory(finalMessages);
    } catch (e) {
      console.error("Chat continuation failed:", e);
    } finally {
      setLoading(false);
    }
  };

  const sendMessage = async (textToSubmit?: string) => {
    const text = textToSubmit !== undefined ? textToSubmit : input;
    if (!text.trim() || loading) return;

    playAudioCue("send");

    const userMessage: Message = {
      id: Math.random().toString(),
      role: "user",
      content: text,
      timestamp: Date.now(),
    };

    const updatedMessages = [...messages, userMessage];
    
    setMessages(updatedMessages);
    if (textToSubmit === undefined) {
      setInput("");
    }
    setLoading(true);

    try {
      const npcResponse = await generateChatResponse(updatedMessages);

      const npcMessage: Message = {
        id: Math.random().toString(),
        role: "npc",
        content: npcResponse,
        timestamp: Date.now(),
      };

      const finalMessages = [...updatedMessages, npcMessage];
      setMessages(finalMessages);
      await saveChatSession(userId, character.id, finalMessages);

      playAudioCue("receive");
      updateCinematicReflection(finalMessages);
      autoSaveMemory(finalMessages);
      

    } catch (e) {
      console.error("Chat transmission failed:", e);
    } finally {
      setLoading(false);
    }
  };

  // Truncate memory and edit previous message
  const handleStartEdit = (msg: Message) => {
    setEditingMessageId(msg.id);
    setEditingText(msg.content);
  };

  const handleSaveEdit = async (msgId: string) => {
    if (!editingText.trim() || loading) return;

    playAudioCue("send");

    const msgIndex = messages.findIndex((m) => m.id === msgId);
    if (msgIndex === -1) return;

    const truncatedHistory = messages.slice(0, msgIndex);

    const editedMessage: Message = {
      ...messages[msgIndex],
      content: editingText,
      timestamp: Date.now(),
    };

    const updatedMessages = [...truncatedHistory, editedMessage];
    setMessages(updatedMessages);
    setEditingMessageId(null);
    setLoading(true);

    try {
      const npcResponse = await generateChatResponse(updatedMessages);

      const npcMessage: Message = {
        id: Math.random().toString(),
        role: "npc",
        content: npcResponse,
        timestamp: Date.now(),
      };

      const finalMessages = [...updatedMessages, npcMessage];
      setMessages(finalMessages);
      await saveChatSession(userId, character.id, finalMessages);

      playAudioCue("receive");
      updateCinematicReflection(finalMessages);
      autoSaveMemory(finalMessages);
    } catch (e) {
      console.error("Failed to edit and regenerate response:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleCopyMessage = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedMsgId(id);
      playAudioCue("click");
      setTimeout(() => setCopiedMsgId(null), 2000);
    } catch (e) {
      console.error("Clipboard copy failed:", e);
    }
  };

  const handleFeedback = (id: string, type: 'up' | 'down') => {
    playAudioCue("click");
    setMsgFeedback((prev) => ({
      ...prev,
      [id]: prev[id] === type ? undefined as any : type,
    }));
  };

  const handleRegenerateFromNpc = async (npcMsgId: string) => {
    if (loading) return;
    const msgIndex = messages.findIndex((m) => m.id === npcMsgId);
    if (msgIndex === -1) return;

    // History up to the message before this NPC response
    const historyBeforeNpc = messages.slice(0, msgIndex);
    if (historyBeforeNpc.length === 0) return;

    playAudioCue("send");
    setLoading(true);

    try {
      const npcResponse = await generateChatResponse(historyBeforeNpc);
      const newNpcMessage: Message = {
        id: Math.random().toString(),
        role: "npc",
        content: npcResponse,
        timestamp: Date.now(),
      };
      const finalMessages = [...historyBeforeNpc, newNpcMessage];
      setMessages(finalMessages);
      await saveChatSession(userId, character.id, finalMessages);
      playAudioCue("receive");
      updateCinematicReflection(finalMessages);
      autoSaveMemory(finalMessages);
      // No rewards
    } catch (e) {
      console.error("Regeneration failed:", e);
    } finally {
      setLoading(false);
    }
  };

  const clearHistory = async () => {
    playAudioCue("reset");

    // Reset WebLLM active engine's memory cache
    if (settings.provider === "webllm") {
      await resetWebLLMChat();
    }

    const defaultIntro: Message = {
      id: "intro",
      role: "npc",
      content: character.intro || "The story starts afresh...",
      timestamp: Date.now(),
    };
    setMessages([defaultIntro]);
    await saveChatSession(userId, character.id, [defaultIntro]);
    setDiscoveredNpcs([]);
    localStorage.removeItem(`rp_discovered_npcs_${userId}_${character.id}`);
    setManualNpcEdits({});
    localStorage.removeItem(`rp_manual_npc_edits_${userId}_${character.id}`);
    setManualNpcList([]);
    localStorage.removeItem(`rp_manual_npc_list_${userId}_${character.id}`);
    setCinematicHighlight("Lembaran takdir kembali suci...");
    setShowResetConfirm(false);
  };

  const handleDeleteCharacter = async () => {
    if (onDeleteCharacter) {
      onDeleteCharacter(character.id);
    }
    setShowDeleteConfirm(false);
  };

  const handleDeleteLog = async (msgId: string) => {
    const updatedMessages = messages.filter((m) => m.id !== msgId);
    setMessages(updatedMessages);
    await saveChatSession(userId, character.id, updatedMessages);
  };

  const handleSaveLog = async (msgId: string) => {
    const updatedMessages = messages.map((m) =>
      m.id === msgId ? { ...m, content: editingLogText } : m,
    );
    setMessages(updatedMessages);
    setEditingLogId(null);
    await saveChatSession(userId, character.id, updatedMessages);
  };

  const handleSaveNpc = () => {
    if (onUpdateCharacter && editedNpc) {
      onUpdateCharacter({ ...character, ...editedNpc });
    }
    setIsEditingNpc(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        alert("Gambar terlalu besar! Maksimal 1MB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditedNpc((prev) => ({
          ...prev,
          avatarUrl: reader.result as string,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-0 lg:gap-6 h-full max-w-7xl mx-auto relative overflow-hidden">
      {/* Memory Synchronization Visual Overlay Toast */}
      {memorySyncToast && (
        <div className="fixed top-20 right-4 z-[60] bg-[#0e0a1c]/90 border border-purple-500/40 text-cyan-300 text-[11px] font-mono px-4 py-3 rounded-xl shadow-[0_0_20px_rgba(168,85,247,0.3)] backdrop-blur-md flex items-center gap-2.5 animate-fade-in">
          <span className="w-2.5 h-2.5 bg-purple-500 rounded-full animate-ping shrink-0" />
          <span>{memorySyncToast}</span>
        </div>
      )}

      {/* LEFT AREA: MAIN ROLEPLAY SCREEN */}
      <div className="flex-1 flex flex-col bg-white/[0.02] border-0 sm:border border-white/5 rounded-none sm:rounded-2xl overflow-hidden shadow-2xl h-full">
        {/* Chat Header */}
        <div className="p-2.5 sm:p-4 border-b border-white/5 bg-black/30 flex items-center justify-between gap-2 sm:gap-4 shrink-0">
          <div className="flex items-center gap-1.5 sm:gap-3 min-w-0">
            {onOpenSidebar && (
              <button
                onClick={onOpenSidebar}
                className="p-2 md:hidden hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition shrink-0 active:scale-95"
                title="Buka Daftar Karakter"
              >
                <Menu size={18} />
              </button>
            )}
            <button
              onClick={onBack}
              className="p-2 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition shrink-0 active:scale-95"
              title="Kembali ke Beranda"
            >
              <ArrowLeft size={18} />
            </button>
            <div className="min-w-0">
              <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 truncate">
                <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse shrink-0"></span>
                <span className="truncate">{character.name}</span>
              </h3>
              <p className="text-[9px] sm:text-[10px] text-purple-400 font-bold font-mono uppercase tracking-widest truncate">
                {character.persona || "fantasy"} WORLD
              </p>
            </div>
          </div>
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Mobile Details Drawer Toggle */}
            <button
              onClick={() => setShowMobileDetails(!showMobileDetails)}
              className="lg:hidden p-2 bg-white/5 border border-white/10 rounded-xl text-gray-300 hover:text-white hover:bg-white/10 transition flex items-center gap-1 text-xs active:scale-95 min-h-[36px]"
              title="Tampilkan Detail & Log"
            >
              <Info size={15} />
              <span className="hidden sm:inline">Info & Log</span>
            </button>

            {/* Audio Cue Switch */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={
                soundEnabled ? "Nonaktifkan audio SFX" : "Aktifkan audio SFX"
              }
              className={`p-2 rounded-xl border transition flex items-center justify-center min-h-[36px] min-w-[36px] active:scale-95 ${
                soundEnabled
                  ? "bg-cyan-500/10 border-cyan-500/20 text-cyan-400 hover:bg-cyan-500/20"
                  : "bg-white/5 border-white/10 text-gray-500 hover:bg-white/10"
              }`}
            >
              {soundEnabled ? <Volume2 size={15} /> : <VolumeX size={15} />}
            </button>

            <button
              onClick={() => setShowResetConfirm(true)}
              title="Reset Memory (Clear Session)"
              className="p-2 sm:px-3 bg-red-900/20 hover:bg-red-900/40 text-red-300 border border-red-500/10 rounded-xl text-xs flex items-center gap-1.5 transition active:scale-95 min-h-[36px]"
            >
              <Trash2 size={14} />{" "}
              <span className="hidden sm:inline">Reset Memory</span>
            </button>
          </div>
        </div>

        {/* Cinematic Highlight Ribbon */}
        <div className="bg-gradient-to-r from-purple-950/30 to-cyan-950/20 border-b border-purple-500/15 p-3 px-4 flex items-center gap-3">
          <Film size={16} className="text-cyan-400 animate-pulse shrink-0" />
          <div className="text-xs text-cyan-200 italic font-semibold truncate">
            {cinematicHighlight}
          </div>
        </div>

        {/* Message Feed */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-6 space-y-3 sm:space-y-4 min-h-[150px]">
          <div className="max-w-3xl mx-auto w-full space-y-3 sm:space-y-4">
            {messages.map((m) => (
            <div
              key={m.id}
              className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
            >
              {m.role === "user" && (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full border border-purple-500/30 bg-purple-950/20 mr-2 sm:mr-3 order-last ml-2 sm:ml-3 shrink-0 mt-1 overflow-hidden">
                  <img
                    src={
                      userPhotoUrl ||
                      `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(userId || "User")}`
                    }
                    alt="Anda"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}
              {m.role === "npc" && (
                <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full border border-cyan-500/30 bg-purple-950/20 mr-2 sm:mr-3 shrink-0 mt-1 overflow-hidden">
                  <img
                    src={
                      character.avatarUrl ||
                      `https://api.dicebear.com/7.x/${
                        character.persona === "cyberpunk"
                          ? "bottts"
                          : character.persona === "horror"
                            ? "identicon"
                            : character.persona === "detective"
                              ? "micah"
                              : "pixel-art"
                      }/svg?seed=${encodeURIComponent(character.name || "NPC")}`
                    }
                    alt={character.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>
              )}
              <div className="w-full max-w-[98%] sm:max-w-[85%] space-y-0.5">
                <div className="flex items-center justify-between gap-4 px-1">
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-widest">
                      {m.role === "user" ? "Anda" : character.name}
                    </span>
                    {m.role === "npc" && (
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => speakText(m.content, m.id)}
                          className={`text-[9px] px-1.5 py-0.5 rounded transition-all duration-200 flex items-center gap-1 ${
                            speakingMessageId === m.id
                              ? "bg-green-600/20 text-green-400 border border-green-500/20 font-bold animate-pulse"
                              : "bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
                          }`}
                          title={
                            speakingMessageId === m.id
                              ? "Hentikan Suara"
                              : "Suarakan Pesan"
                          }
                        >
                          <Volume2 size={8} />{" "}
                          {speakingMessageId === m.id ? "Membaca..." : "Dengar"}
                        </button>
                        <button
                          onClick={() => generateSceneImage(m)}
                          disabled={messageImages[m.id]?.loading}
                          className={`text-[9px] px-1.5 py-0.5 rounded border transition-all duration-200 flex items-center gap-1 cursor-pointer ${
                            messageImages[m.id]?.url
                              ? "bg-amber-500/20 text-amber-300 border-amber-500/30 font-bold shadow-[0_0_8px_rgba(245,158,11,0.1)]"
                              : "bg-white/5 border-white/10 hover:bg-white/10 text-gray-400 hover:text-white"
                          }`}
                          title="Gambarkan situasi/posisi adegan ini dengan AI"
                        >
                          {messageImages[m.id]?.loading ? (
                            <RefreshCw
                              size={8}
                              className="animate-spin text-amber-400"
                            />
                          ) : (
                            <ImageIcon size={8} className="text-amber-400" />
                          )}
                          {messageImages[m.id]?.loading
                            ? "Melukis..."
                            : messageImages[m.id]?.url
                              ? "Tampil Visual"
                              : "AI Image"}
                        </button>
                      </div>
                    )}
                  </div>
                  {m.role === "user" && editingMessageId !== m.id && (
                    <button
                      onClick={() => handleStartEdit(m)}
                      title="Edit pesan sebelumnya"
                      className="text-[9px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition font-bold"
                    >
                      <Edit3 size={10} /> Edit
                    </button>
                  )}
                </div>

                <div
                  className={`p-0 rounded-none bg-transparent ${
                    m.role === "user"
                      ? "flex justify-end"
                      : "flex flex-col space-y-2"
                  }`}
                >
                  {m.role === "user" ? (
                    editingMessageId === m.id ? (
                      <div className="space-y-3 w-full">
                        <textarea
                          rows={3}
                          value={editingText}
                          onChange={(e) => setEditingText(e.target.value)}
                          className="w-full bg-black/40 border border-white/10 p-2.5 rounded-xl text-[15px] sm:text-sm text-white focus:border-cyan-400 outline-none resize-none font-sans"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            onClick={() => setEditingMessageId(null)}
                            className="px-3 py-1.5 bg-white/5 border border-white/10 hover:bg-white/10 text-xs text-gray-300 rounded-lg flex items-center gap-1 active:scale-95 min-h-[36px]"
                          >
                            <X size={13} /> Batal
                          </button>
                          <button
                            onClick={() => handleSaveEdit(m.id)}
                            className="px-3 py-1.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-xs text-white rounded-lg flex items-center gap-1.5 font-bold cursor-pointer active:scale-95 min-h-[36px]"
                          >
                            <Check size={13} /> Simpan & Regenerasi
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-[#242731] border border-white/10 text-gray-100 rounded-2xl sm:rounded-3xl py-2.5 px-4 sm:py-3 sm:px-5 max-w-[88%] sm:max-w-[80%] text-[14px] sm:text-[14.5px] shadow-sm leading-relaxed break-words whitespace-pre-wrap">
                        {m.content}
                      </div>
                    )
                  ) : (
                    <div className="space-y-3">
                      <div className="text-gray-100 leading-relaxed font-sans space-y-2.5">
                        {(() => {
                          const parts = m.content
                            .split(/(\*[^*]+\*|"[^"]+")/g)
                            .filter((part) => part && part.trim() !== "");

                          let currentSpeaker: { type: 'gm' | 'npc' | 'monster', name: string } | null = null;

                          const getSpeaker = (txt: string) => {
                            const bracketMatch = txt.match(/\[(GM|NPC|MONSTER)(?:\s*-\s*([^\]]+))?\]/i);
                            if (bracketMatch) {
                              const type = bracketMatch[1].toLowerCase() as 'gm' | 'npc' | 'monster';
                              const name = bracketMatch[2] ? bracketMatch[2].trim() : (type === 'gm' ? 'Game Master' : '???');
                              return { type, name };
                            }

                            const colonMatch = txt.match(/^\s*(Game\s*Master|GM|Monster|NPC|[\w\s-?]+)\s*:/i);
                            if (colonMatch) {
                              const rawName = colonMatch[1].trim();
                              const lowerName = rawName.toLowerCase();
                              if (lowerName === 'gm' || lowerName === 'game master') {
                                return { type: 'gm' as const, name: 'Game Master' };
                              }
                              if (lowerName.includes('monster') || lowerName.includes('slime') || lowerName.includes('goblin') || lowerName.includes('dragon') || lowerName.includes('beast') || lowerName.includes('demon')) {
                                return { type: 'monster' as const, name: rawName };
                              }
                              return { type: 'npc' as const, name: rawName };
                            }

                            return null;
                          };

                          return parts.map((part, idx) => {
                            const trimmed = part.trim();
                            const isSystem = trimmed.startsWith("*") && trimmed.endsWith("*") && trimmed.length > 2;
                            const isDialogue = trimmed.startsWith('"') && trimmed.endsWith('"') && trimmed.length > 2;

                            if (isSystem) {
                              const cleanText = part.slice(1, -1).trim();
                              return (
                                <div
                                  key={idx}
                                  className="border-l-2 border-purple-500/40 pl-3 py-1.5 bg-purple-950/15 rounded-r text-white font-sans font-bold text-[13.5px] sm:text-[14.5px] leading-relaxed shadow-sm"
                                >
                                  <span className="text-[9px] uppercase tracking-wider font-extrabold text-purple-400 block mb-0.5 not-italic font-mono select-none">
                                    ❖ Narasi / Perilaku (Sistem)
                                  </span>
                                  *{cleanText}*
                                </div>
                              );
                            }

                            if (isDialogue) {
                              let cleanText = part.slice(1, -1).trim();
                              let localSpeaker = getSpeaker(cleanText);

                              if (localSpeaker) {
                                cleanText = cleanText.replace(/^\[(GM|NPC|MONSTER)(?:\s*-\s*([^\]]+))?\]\s*:\s*/i, "");
                                cleanText = cleanText.replace(/^\s*(Game\s*Master|GM|Monster|NPC|[\w\s-]+)\s*:\s*/i, "");
                              } else if (currentSpeaker) {
                                localSpeaker = currentSpeaker;
                              } else {
                                const isGmChar = character.name.toLowerCase().includes("game master") || character.aiMode === "gamemaster";
                                localSpeaker = {
                                  type: isGmChar ? 'npc' : 'npc',
                                  name: isGmChar ? '???' : character.name,
                                };
                              }

                              currentSpeaker = null;

                              let containerClass = "p-3 rounded-xl leading-relaxed shadow-sm flex flex-col gap-1.5 border ";
                              let badgeClass = "text-[9px] uppercase tracking-wider font-mono font-extrabold px-2 py-0.5 rounded-md inline-block max-w-max select-none ";
                              let badgeLabel = "";

                              if (localSpeaker.type === 'gm') {
                                containerClass += "bg-purple-950/10 border-purple-500/30 text-purple-200 shadow-[0_0_15px_rgba(168,85,247,0.05)]";
                                badgeClass += "bg-purple-500/20 text-purple-300 border border-purple-500/30";
                                badgeLabel = `🔮 Game Master (GM)`;
                              } else if (localSpeaker.type === 'monster') {
                                containerClass += "bg-red-950/10 border-red-500/30 text-red-200 shadow-[0_0_15px_rgba(239,68,68,0.05)]";
                                badgeClass += "bg-red-500/20 text-red-300 border border-red-500/30";
                                badgeLabel = `👿 Monster: ${localSpeaker.name}`;
                              } else {
                                containerClass += "bg-cyan-950/10 border-cyan-500/20 text-cyan-200 shadow-[0_0_15px_rgba(6,182,212,0.02)]";
                                badgeClass += "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30";
                                badgeLabel = `👤 NPC: ${localSpeaker.name}`;
                              }

                              return (
                                <div key={idx} className={containerClass}>
                                  <div className="flex justify-between items-center">
                                    <span className={badgeClass}>{badgeLabel}</span>
                                  </div>
                                  <span className="relative pl-1 text-[13.5px] sm:text-[14.5px] font-semibold tracking-wide">
                                    “{cleanText}”
                                  </span>
                                </div>
                              );
                            }

                            const speaker = getSpeaker(trimmed);
                            if (speaker) {
                              currentSpeaker = speaker;
                              const isOnlyTag = /^(?:\[(GM|NPC|MONSTER)(?:\s*-\s*([^\]]+))?\]|Game\s*Master|GM|Monster|NPC|[\w\s-]+)\s*:\s*$/i.test(trimmed);
                              if (isOnlyTag) {
                                return null;
                              }
                            }

                            const isReward =
                              part.includes("+") &&
                              (part.toUpperCase().includes("XP") ||
                                part.toUpperCase().includes("KOIN") ||
                                part.toUpperCase().includes("COIN") ||
                                part.toUpperCase().includes("LOOT") ||
                                part.toUpperCase().includes("ITEM"));

                             return (
                              <div
                                key={idx}
                                className={`p-2 rounded-xl text-[13.5px] sm:text-[14.5px] leading-relaxed font-sans whitespace-pre-wrap ${
                                  isReward
                                    ? "bg-amber-500/10 border border-amber-500/25 text-amber-300 font-bold"
                                    : "text-gray-200 bg-transparent border-none pl-1"
                                }`}
                              >
                                {isReward ? (
                                  <div className="flex items-center gap-1.5 text-[9px] font-mono text-amber-400 uppercase tracking-widest font-extrabold mb-1 select-none">
                                    🎁 RPG Reward Sistem
                                  </div>
                                ) : null}
                                {part}
                              </div>
                            );
                          });
                        })()}
                      </div>

                      {/* Gemini Action Bar with responsive touch targets and functional tools */}
                      <div className="flex items-center gap-1 sm:gap-2 text-gray-400 pt-1">
                        <button
                          onClick={() => handleFeedback(m.id, 'up')}
                          className={`p-2 sm:p-1.5 rounded-lg transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90 ${
                            msgFeedback[m.id] === 'up'
                              ? "text-emerald-400 bg-emerald-500/10"
                              : "hover:text-gray-200 hover:bg-white/5"
                          }`}
                          title="Suka respons ini"
                        >
                          <ThumbsUp size={16} className={msgFeedback[m.id] === 'up' ? "fill-emerald-400/20" : ""} />
                        </button>
                        <button
                          onClick={() => handleFeedback(m.id, 'down')}
                          className={`p-2 sm:p-1.5 rounded-lg transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90 ${
                            msgFeedback[m.id] === 'down'
                              ? "text-rose-400 bg-rose-500/10"
                              : "hover:text-gray-200 hover:bg-white/5"
                          }`}
                          title="Kurang suka respons ini"
                        >
                          <ThumbsDown size={16} className={msgFeedback[m.id] === 'down' ? "fill-rose-400/20" : ""} />
                        </button>
                        <button
                          onClick={() => handleRegenerateFromNpc(m.id)}
                          disabled={loading}
                          className="p-2 sm:p-1.5 rounded-lg hover:text-gray-200 hover:bg-white/5 transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90 disabled:opacity-50"
                          title="Regenerasi balasan ini"
                        >
                          <RotateCw size={16} className={loading ? "animate-spin text-cyan-400" : ""} />
                        </button>
                        <button
                          onClick={() => handleCopyMessage(m.content, m.id)}
                          className={`p-2 sm:p-1.5 rounded-lg transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90 ${
                            copiedMsgId === m.id
                              ? "text-cyan-400 bg-cyan-500/10"
                              : "hover:text-gray-200 hover:bg-white/5"
                          }`}
                          title={copiedMsgId === m.id ? "Tersalin!" : "Salin pesan"}
                        >
                          {copiedMsgId === m.id ? <Check size={16} /> : <Copy size={16} />}
                        </button>
                        <button
                          onClick={() => speakText(m.content, m.id)}
                          className="p-2 sm:p-1.5 rounded-lg hover:text-gray-200 hover:bg-white/5 transition-colors flex items-center justify-center min-w-[36px] min-h-[36px] active:scale-90"
                          title="Putar suara text-to-speech"
                        >
                          <Volume2 size={16} className={speakingMessageId === m.id ? "text-green-400 animate-pulse" : ""} />
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Embedded generated AI Image */}
                  {m.role === "npc" && messageImages[m.id] && (
                    <div className="mt-3 border-t border-white/5 pt-3">
                      <div className="relative aspect-video max-w-lg rounded-xl overflow-hidden border border-white/10 bg-black/40 group">
                        {messageImages[m.id].loading ? (
                          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/60">
                            <RefreshCw
                              size={18}
                              className="animate-spin text-amber-500"
                            />
                            <span className="text-[9px] font-mono tracking-widest text-amber-400 uppercase animate-pulse">
                              MEMVISUALISASIKAN SCENE...
                            </span>
                          </div>
                        ) : (
                          <>
                            <img
                              src={messageImages[m.id].url}
                              alt="Visualisasi Adegan"
                              className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-2.5 opacity-0 group-hover:opacity-100 transition-opacity flex justify-between items-center">
                              <span className="text-[9px] text-gray-400 font-medium">
                                Melukis visual adegan selesai
                              </span>
                              <button
                                onClick={async (e) => {
                                  e.stopPropagation();
                                  try {
                                    const response = await fetch(
                                      messageImages[m.id].url,
                                    );
                                    const blob = await response.blob();
                                    const blobUrl = URL.createObjectURL(blob);
                                    const link = document.createElement("a");
                                    link.href = blobUrl;
                                    link.download = `scene_${m.id}.jpg`;
                                    document.body.appendChild(link);
                                    link.click();
                                    document.body.removeChild(link);
                                    URL.revokeObjectURL(blobUrl);
                                  } catch (err) {
                                    window.open(
                                      messageImages[m.id].url,
                                      "_blank",
                                    );
                                  }
                                }}
                                className="px-2 py-1 bg-black/60 hover:bg-amber-500 hover:text-black rounded text-[9px] flex items-center gap-1 transition"
                              >
                                <Download size={10} /> Unduh
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
          {webllmProgress && (
            <div className="flex justify-start">
              <div className="w-full max-w-md space-y-1 bg-emerald-950/20 border border-emerald-500/20 rounded-2xl p-4">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest block mb-1">
                  MENGUNDUH/MEMUAT MODEL WEBLLM (HANYA SEKALI SAJA)
                </span>
                <div className="text-xs text-gray-300 font-mono leading-relaxed mb-2 break-words">
                  {webllmProgress.text}
                </div>
                <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full rounded-full transition-all duration-300 shadow-[0_0_8px_rgba(16,185,129,0.5)]"
                    style={{
                      width: `${Math.round(webllmProgress.progress * 100)}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between items-center text-[9px] text-gray-400 mt-1">
                  <span>
                    Progress: {Math.round(webllmProgress.progress * 100)}%
                  </span>
                  <span className="animate-pulse">
                    Harap tunggu, jangan tutup tab ini...
                  </span>
                </div>
              </div>
            </div>
          )}
          {loading && (
            <div className="flex justify-start">
              <div className="space-y-1">
                <span className="text-[10px] font-semibold text-gray-500 uppercase tracking-widest block px-1">
                  {character.name}
                </span>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce delay-100"></div>
                  <div className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce delay-200"></div>
                </div>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
          </div>
        </div>

        {/* Input Bar with Mobile Handphone Safe Area Padding */}
        <div className="p-2.5 sm:p-4 pb-[calc(0.65rem+env(safe-area-inset-bottom,0px))] border-t border-white/5 bg-black/40 backdrop-blur-md space-y-2 shrink-0">
          <div className="max-w-3xl mx-auto w-full space-y-2">
            {/* Lanjutkan button row */}
            <div className="flex justify-between items-center px-1 gap-2">
              <span className="text-[9px] sm:text-[10px] text-gray-500 font-mono tracking-wider truncate">
                SIAP MELANJUTKAN ALUR CERITA?
              </span>
              <button
                onClick={handleContinue}
                disabled={loading}
                className="px-3 py-1 sm:px-3.5 sm:py-1.5 bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 disabled:opacity-50 text-white font-extrabold text-[10px] sm:text-[11px] rounded-lg transition-all flex items-center gap-1.5 shadow-[0_0_12px_rgba(16,185,129,0.15)] cursor-pointer active:scale-95 uppercase tracking-wide shrink-0 min-h-[30px]"
              >
                <Zap
                  size={11}
                  className="text-yellow-300 animate-pulse fill-yellow-300"
                />{" "}
                <span className="hidden xs:inline sm:inline">Lanjutkan Tanpa Chat</span>
                <span className="xs:hidden sm:hidden">Lanjut</span> ➔
              </button>
            </div>
            <ChatInputArea
              onSend={(text) => sendMessage(text)}
              loading={loading}
            />
          </div>
        </div>
      </div>

      {/* Backdrop for mobile details drawer */}
      {showMobileDetails && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden animate-fade-in"
          onClick={() => setShowMobileDetails(false)}
        />
      )}

      {/* RIGHT SIDEBAR: SPECS & SECURE LOG DISPLAY */}
      <div
        className={`
        fixed inset-y-0 right-0 z-50 w-80 bg-[#0d0e14] border-l border-white/10 p-6 flex flex-col space-y-6 overflow-y-auto
        transform transition-transform duration-300 ease-in-out lg:static lg:w-80 lg:p-0 lg:z-auto lg:overflow-y-visible lg:h-auto lg:bg-transparent lg:border-l-0
        ${showMobileDetails ? "translate-x-0 shadow-[-5px_0_25px_rgba(0,0,0,0.5)]" : "translate-x-full lg:translate-x-0"}
      `}
      >
        {/* Mobile Close Header */}
        <div className="flex lg:hidden items-center justify-between border-b border-white/5 pb-3">
          <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">
            Detail & Log Enkripsi
          </span>
          <button
            onClick={() => setShowMobileDetails(false)}
            className="p-1.5 bg-white/5 border border-white/10 rounded-lg text-gray-400 hover:text-white transition"
            title="Tutup Detail"
          >
            <X size={14} />
          </button>
        </div>

        {/* TAB SWITCHER */}
        <div className="flex bg-black/40 p-1 rounded-xl border border-white/5 gap-0.5 shadow-inner shrink-0 overflow-x-auto scrollbar-none">
          <button
            onClick={() => {
              playAudioCue("reflect");
              setActiveSidebarTab('paste_chat');
            }}
            className={`flex-1 min-w-[70px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 relative ${
              activeSidebarTab === 'paste_chat'
                ? 'bg-gradient-to-r from-cyan-600/90 to-purple-600/90 text-white shadow-[0_0_15px_rgba(6,182,212,0.3)] border border-cyan-500/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            📋 PASTE
          </button>
          <button
            onClick={() => {
              playAudioCue("send");
              setActiveSidebarTab('secure_storage');
            }}
            className={`flex-1 min-w-[60px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 ${
              activeSidebarTab === 'secure_storage'
                ? 'bg-gradient-to-r from-emerald-600/90 to-teal-600/90 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)] border border-emerald-500/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            🔒 SECURE
          </button>
          {isGameMaster && (
            <button
              onClick={() => {
                playAudioCue("send");
                setActiveSidebarTab('npc');
              }}
              className={`flex-1 min-w-[70px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 ${
                activeSidebarTab === 'npc'
                  ? 'bg-gradient-to-r from-purple-600/90 to-indigo-600/90 text-white shadow-[0_0_15px_rgba(168,85,247,0.3)] border border-purple-500/30'
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              👥 NPC LIST
            </button>
          )}
          <button
            onClick={() => {
              playAudioCue("click");
              setActiveSidebarTab('npc_info');
              setEditedNpc({
                name: character.name,
                gender: character.gender,
                avatarUrl: character.avatarUrl,
                avatarPosition: character.avatarPosition || 50,
                background: character.background,
                personality: character.personality,
              });
              setIsEditingNpc(false);
            }}
            className={`flex-1 min-w-[70px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 ${
              activeSidebarTab === 'npc_info'
                ? 'bg-gradient-to-r from-pink-600/90 to-purple-600/90 text-white shadow-[0_0_15px_rgba(236,72,153,0.3)] border border-pink-500/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            ℹ️ NPC INFO
          </button>
          <button
            onClick={() => {
              playAudioCue("click");
              setActiveSidebarTab('ai_settings');
            }}
            className={`flex-1 min-w-[70px] py-2 text-center rounded-lg text-[9px] font-bold tracking-wider transition-all duration-300 flex items-center justify-center gap-0.5 ${
              activeSidebarTab === 'ai_settings'
                ? 'bg-gradient-to-r from-blue-600/90 to-cyan-600/90 text-white shadow-[0_0_15px_rgba(37,99,235,0.3)] border border-blue-500/30'
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
          >
            🤖 AI MODE
          </button>
        </div>

        {/* CONDITIONALLY RENDER VIEW BASED ON TAB */}
        {activeSidebarTab === 'npc' ? (
          <div className="p-4 bg-[#0a0a14]/95 border border-purple-500/25 rounded-2xl shadow-xl flex flex-col flex-1 min-h-0 text-left opacity-100">
            <div className="flex flex-col gap-1 shrink-0 mb-3 border-b border-white/5 pb-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
                  <h4 className="text-[10px] font-black uppercase tracking-wider text-purple-400 font-mono">
                    👥 DIRECTORY NPC & MONSTER ({getDisplayNpcs().length})
                  </h4>
                </div>
                <button
                  onClick={() => {
                    playAudioCue("click");
                    setShowAddNpcForm(!showAddNpcForm);
                    setAddFormName("");
                    setAddFormType("npc");
                    setAddFormDesc("");
                  }}
                  className="px-2 py-0.5 bg-purple-500/10 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 text-[9px] font-extrabold rounded font-mono transition-all cursor-pointer"
                >
                  {showAddNpcForm ? "✕ Tutup" : "➕ Tambah NPC"}
                </button>
              </div>
              <p className="text-[9px] text-gray-400 leading-normal mt-1">
                Daftar karakter, penduduk lokal, atau makhluk liar yang telah Anda temui sepanjang sesi petualangan ini beserta latar belakang otomatis yang berhasil terungkap dari riwayat chat.
              </p>
            </div>

            {/* Manual Add Form */}
            {showAddNpcForm && (
              <div className="p-3 bg-purple-950/20 border border-purple-500/30 rounded-xl mb-3 space-y-2 text-[11px] text-left shrink-0">
                <h5 className="text-[10px] font-bold text-purple-300 font-mono tracking-wide uppercase">➕ BUAT NPC / MONSTER MANUAL</h5>
                <div>
                  <label className="text-[8px] uppercase tracking-wider font-extrabold text-purple-400 block font-mono select-none mb-1">
                    Nama Karakter:
                  </label>
                  <input
                    type="text"
                    value={addFormName}
                    onChange={(e) => setAddFormName(e.target.value)}
                    placeholder="Contoh: Aris Sang Ksatria"
                    className="w-full bg-black/60 border border-white/10 rounded px-2 py-1 text-[11px] text-white focus:border-purple-400 outline-none"
                  />
                </div>

                <div>
                  <label className="text-[8px] uppercase tracking-wider font-extrabold text-purple-400 block font-mono select-none mb-1">
                    Tipe:
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setAddFormType('npc')}
                      className={`flex-1 py-1 px-2 rounded text-[10px] font-bold border transition-all ${
                        addFormType === 'npc'
                          ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300 border-cyan-500/50'
                          : 'bg-transparent border-white/10 text-gray-400 hover:text-white'
                      }`}
                    >
                      👤 NPC
                    </button>
                    <button
                      type="button"
                      onClick={() => setAddFormType('monster')}
                      className={`flex-1 py-1 px-2 rounded text-[10px] font-bold border transition-all ${
                        addFormType === 'monster'
                          ? 'bg-red-500/20 border-red-500/40 text-red-300 border-red-500/50'
                          : 'bg-transparent border-white/10 text-gray-400 hover:text-white'
                      }`}
                    >
                      👾 Monster
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-[8px] uppercase tracking-wider font-extrabold text-purple-400 block font-mono select-none mb-1">
                    Latar Belakang / Deskripsi:
                  </label>
                  <textarea
                    value={addFormDesc}
                    onChange={(e) => setAddFormDesc(e.target.value)}
                    rows={3}
                    placeholder="Deskripsikan latar belakang, kepribadian, atau penampilan..."
                    className="w-full bg-black/60 border border-white/10 rounded px-2 py-1 text-[11px] text-white focus:border-purple-400 outline-none resize-none leading-relaxed"
                  />
                </div>

                <div className="flex justify-end gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      playAudioCue("click");
                      setShowAddNpcForm(false);
                    }}
                    className="px-2.5 py-1 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 rounded text-[9px] font-bold transition-all cursor-pointer"
                  >
                    Batal
                  </button>
                  <button
                    type="button"
                    disabled={!addFormName.trim()}
                    onClick={() => {
                      if (!addFormName.trim()) return;
                      playAudioCue("send");
                      const newNpc: DiscoveredNpc = {
                        name: addFormName.trim(),
                        type: addFormType,
                        description: addFormDesc.trim() || "Karakter buatan petualang.",
                        avatarUrl: `https://api.dicebear.com/7.x/${addFormType === 'monster' ? 'identicon' : 'micah'}/svg?seed=${encodeURIComponent(addFormName.trim())}`,
                        firstMetTimestamp: Date.now()
                      };
                      const nextList = [newNpc, ...manualNpcList];
                      setManualNpcList(nextList);
                      localStorage.setItem(`rp_manual_npc_list_${userId}_${character.id}`, JSON.stringify(nextList));
                      setShowAddNpcForm(false);
                    }}
                    className="px-3 py-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded text-[9px] font-bold transition-all disabled:opacity-40 cursor-pointer"
                  >
                    Tambah NPC
                  </button>
                </div>
              </div>
            )}

            <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-1">
              {getDisplayNpcs().length === 0 ? (
                <div className="flex flex-col items-center justify-center text-center p-8 border border-white/5 bg-black/25 rounded-xl h-48 space-y-2">
                  <span className="text-3xl">👥</span>
                  <p className="text-[11px] text-gray-400 font-medium">Belum ada NPC atau monster yang ditemui.</p>
                  <p className="text-[9px] text-gray-500">Gunakan tombol "➕ Tambah NPC" di atas untuk menambahkan sendiri, atau ketik percakapan untuk mengungkap mereka secara otomatis!</p>
                </div>
              ) : (
                getDisplayNpcs().map((npc, idx) => (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border transition-all duration-300 ${
                      npc.type === 'monster'
                        ? 'bg-red-950/10 border-red-500/20 hover:border-red-500/40 shadow-[0_0_10px_rgba(239,68,68,0.02)]'
                        : 'bg-cyan-950/10 border-cyan-500/20 hover:border-cyan-500/40 shadow-[0_0_10px_rgba(6,182,212,0.02)]'
                    }`}
                  >
                    {editingNpcKey === npc.name.toLowerCase() ? (
                      <div className="space-y-3 p-1">
                        <div>
                          <label className="text-[8px] uppercase tracking-wider font-extrabold text-purple-400 block font-mono select-none mb-1">
                            Nama Karakter:
                          </label>
                          <input
                            type="text"
                            value={editFormName}
                            onChange={(e) => setEditFormName(e.target.value)}
                            className="w-full bg-black/60 border border-white/10 rounded px-2 py-1 text-[11px] text-white focus:border-purple-400 outline-none"
                          />
                        </div>

                        <div>
                          <label className="text-[8px] uppercase tracking-wider font-extrabold text-purple-400 block font-mono select-none mb-1">
                            Tipe:
                          </label>
                          <div className="flex gap-2">
                            <button
                              type="button"
                              onClick={() => setEditFormType('npc')}
                              className={`flex-1 py-1 px-2 rounded text-[10px] font-bold border transition-all ${
                                editFormType === 'npc'
                                  ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300 border-cyan-500/50'
                                  : 'bg-transparent border-white/10 text-gray-400 hover:text-white'
                              }`}
                            >
                              👤 NPC
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditFormType('monster')}
                              className={`flex-1 py-1 px-2 rounded text-[10px] font-bold border transition-all ${
                                editFormType === 'monster'
                                  ? 'bg-red-500/20 border-red-500/40 text-red-300 border-red-500/50'
                                  : 'bg-transparent border-white/10 text-gray-400 hover:text-white'
                              }`}
                            >
                              👾 Monster
                            </button>
                          </div>
                        </div>

                        <div>
                          <label className="text-[8px] uppercase tracking-wider font-extrabold text-purple-400 block font-mono select-none mb-1">
                            Latar Belakang / Deskripsi:
                          </label>
                          <textarea
                            value={editFormDesc}
                            onChange={(e) => setEditFormDesc(e.target.value)}
                            rows={4}
                            className="w-full bg-black/60 border border-white/10 rounded px-2 py-1 text-[11px] text-white focus:border-purple-400 outline-none resize-none leading-relaxed"
                            placeholder="Masukkan latar belakang atau deskripsi otomatis..."
                          />
                        </div>

                        <div className="flex justify-end gap-1.5 pt-1">
                          <button
                            type="button"
                            onClick={() => {
                              playAudioCue("click");
                              setEditingNpcKey(null);
                            }}
                            className="px-2.5 py-1 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 rounded text-[9px] font-bold transition-all cursor-pointer"
                          >
                            Batal
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              playAudioCue("send");
                              const nextEdits = {
                                ...manualNpcEdits,
                                [npc.name.toLowerCase()]: {
                                  name: editFormName,
                                  type: editFormType,
                                  description: editFormDesc,
                                }
                              };
                              setManualNpcEdits(nextEdits);
                              localStorage.setItem(`rp_manual_npc_edits_${userId}_${character.id}`, JSON.stringify(nextEdits));
                              setEditingNpcKey(null);
                            }}
                            className="px-3 py-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded text-[9px] font-bold transition-all shadow-[0_0_10px_rgba(168,85,247,0.2)] cursor-pointer"
                          >
                            Simpan
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex gap-3 items-start">
                          <img
                            src={npc.avatarUrl}
                            alt={npc.name}
                            className={`w-10 h-10 rounded-lg object-cover border shrink-0 ${
                              npc.type === 'monster' ? 'border-red-500/30' : 'border-cyan-500/30'
                            }`}
                          />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-2">
                              <h5 className="text-[12px] font-bold text-white truncate">{npc.name}</h5>
                              <span
                                className={`text-[8px] font-bold font-mono px-1.5 py-0.5 rounded uppercase ${
                                  npc.type === 'monster'
                                    ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                                    : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                                }`}
                              >
                                {npc.type}
                              </span>
                            </div>
                            <p className="text-[9px] text-gray-500 font-mono mt-0.5">
                              Met: {new Date(npc.firstMetTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                        </div>
                        
                        <div className="mt-2.5 pt-2 border-t border-white/5">
                          <span className="text-[8px] uppercase tracking-wider font-extrabold text-gray-400 block font-mono select-none">
                            📖 Latar Belakang / Deskripsi:
                          </span>
                          <p className="text-[10px] sm:text-[11px] text-gray-300 italic leading-relaxed mt-1 whitespace-pre-line bg-black/20 p-2 rounded-lg border border-white/5">
                            "{npc.description}"
                          </p>
                        </div>

                        <div className="mt-3 flex justify-between items-center gap-1">
                          <button
                            onClick={() => {
                              playAudioCue("reset");
                              // Remove from manual list
                              const nextList = manualNpcList.filter(n => n.name.toLowerCase() !== npc.name.toLowerCase());
                              setManualNpcList(nextList);
                              localStorage.setItem(`rp_manual_npc_list_${userId}_${character.id}`, JSON.stringify(nextList));

                              // Remove from manual edits
                              const nextEdits = { ...manualNpcEdits };
                              delete nextEdits[npc.name.toLowerCase()];
                              setManualNpcEdits(nextEdits);
                              localStorage.setItem(`rp_manual_npc_edits_${userId}_${character.id}`, JSON.stringify(nextEdits));

                              // Remove from discovered list if present
                              const nextDiscovered = discoveredNpcs.filter(n => n.name.toLowerCase() !== npc.name.toLowerCase());
                              setDiscoveredNpcs(nextDiscovered);
                              localStorage.setItem(`rp_discovered_npcs_${userId}_${character.id}`, JSON.stringify(nextDiscovered));
                            }}
                            className="text-[8px] font-bold font-mono uppercase px-2 py-1 rounded hover:bg-red-500/10 text-red-400 border border-red-500/20 cursor-pointer transition-all"
                            title="Hapus NPC ini dari daftar"
                          >
                            🗑️ Hapus
                          </button>

                          <div className="flex gap-1.5">
                            <button
                              onClick={() => {
                                playAudioCue("click");
                                setEditingNpcKey(npc.name.toLowerCase());
                                setEditFormName(npc.name);
                                setEditFormType(npc.type);
                                setEditFormDesc(npc.description);
                              }}
                              className={`text-[8px] font-extrabold font-mono uppercase px-2 py-1 rounded transition-all cursor-pointer bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10`}
                            >
                              ✏️ Edit NPC
                            </button>
                            <button
                              onClick={() => {
                                playAudioCue("click");
                                setInput(`*appraiser* ${npc.name}`);
                              }}
                              className={`text-[8px] font-extrabold font-mono uppercase px-2 py-1 rounded transition-all cursor-pointer ${
                                npc.type === 'monster'
                                  ? 'bg-red-500/10 hover:bg-red-500/20 text-red-300 border border-red-500/20'
                                  : 'bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/20'
                              }`}
                              title="Analisis status dan kelemahan karakter ini menggunakan kemampuan Appraiser"
                            >
                              🔍 Appraise Jati Diri
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        ) : activeSidebarTab === 'paste_chat' ? (
          <div className="p-4 bg-[#0a0a14]/95 border border-purple-500/25 rounded-2xl shadow-xl flex flex-col flex-1 min-h-0 text-left opacity-100">
            <div className="flex flex-col gap-2 shrink-0 mb-3 border-b border-white/5 pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <h4 className="text-[10px] font-black uppercase tracking-wider text-cyan-400 font-mono">
                    📋 MEMORY SYNCHRONIZER (PASTE CHAT)
                  </h4>
                </div>
                <span className={`text-[8px] border px-1.5 py-0.5 rounded font-mono font-bold ${
                  settings.pasteChatEnabled !== false && pastedChatText.trim()
                    ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300'
                    : 'bg-white/5 border-white/10 text-gray-400'
                }`}>
                  {settings.pasteChatEnabled !== false && pastedChatText.trim() ? 'AKTIF DI AI' : 'STANDBY'}
                </span>
              </div>
              <p className="text-[9px] text-gray-400 leading-normal">
                Tempel salinan percakapan, ringkasan lore, atau sesi chat sebelumnya di sini agar AI otomatis mengingat konteks cerita dan bertindak sesuai riwayat tersebut.
              </p>

              {/* Status and Active Toggle */}
              <div className="flex items-center justify-between p-2 bg-purple-950/25 border border-purple-500/20 rounded-xl mt-1">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className={`w-2 h-2 rounded-full shrink-0 ${
                    settings.pasteChatEnabled !== false && pastedChatText.trim()
                      ? 'bg-cyan-400 animate-pulse shadow-[0_0_8px_rgba(6,182,212,0.8)]'
                      : 'bg-gray-500'
                  }`} />
                  <span className="text-[9px] font-bold text-gray-200 truncate font-mono">
                    {settings.pasteChatEnabled !== false
                      ? (pastedChatText.trim() ? "AI Membaca Konteks Ini" : "Aktif (Menunggu Teks)")
                      : "Nonaktif (AI Mengabaikan Teks)"}
                  </span>
                </div>
                <button
                  onClick={() => {
                    playAudioCue("click");
                    if (onUpdateSettings) {
                      onUpdateSettings({ ...settings, pasteChatEnabled: settings.pasteChatEnabled === false });
                    }
                  }}
                  className={`px-2 py-0.5 rounded text-[8px] font-bold font-mono uppercase transition cursor-pointer ${
                    settings.pasteChatEnabled !== false
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-[0_0_8px_rgba(6,182,212,0.3)]'
                      : 'bg-white/5 text-gray-400 border border-white/10 hover:text-white'
                  }`}
                  title="Aktifkan atau nonaktifkan pengaruh Paste Chat ke AI"
                >
                  {settings.pasteChatEnabled !== false ? "TERHUBUNG AI" : "TERPUTUS"}
                </button>
              </div>
            </div>

            <div className="flex-1 flex flex-col min-h-0 space-y-3">
              <div className="flex-1 flex flex-col min-h-0 relative">
                <textarea
                  value={pastedChatText}
                  onChange={(e) => {
                    const val = e.target.value;
                    setPastedChatText(val);
                    localStorage.setItem(`rp_pasted_chat_${userId}_${character.id}`, val);
                  }}
                  placeholder={`Contoh format:
Anda: Halo, siapa kamu?
${character.name}: Saya adalah penjelajah biner...

*Atau cukup klik "Salin Obrolan Aktif" di bawah.*`}
                  className="flex-1 w-full bg-black/50 border border-purple-500/20 rounded-xl p-3 text-[11px] text-gray-100 font-mono focus:border-cyan-400/50 outline-none resize-none leading-relaxed custom-scrollbar"
                />
                {pastedChatText && (
                  <div className="absolute bottom-2 right-3 text-[8px] text-gray-500 font-mono bg-black/70 px-1.5 py-0.5 rounded border border-white/5 pointer-events-none">
                    {pastedChatText.trim().split(/\s+/).filter(Boolean).length} kata • {pastedChatText.length} huruf
                  </div>
                )}
              </div>

              <button 
                onClick={() => {
                  playAudioCue("click");
                  localStorage.setItem(`rp_pasted_chat_${userId}_${character.id}`, pastedChatText);
                  setMemorySyncToast("✅ Konteks Paste Chat tersimpan & terhubung ke AI!");
                  setTimeout(() => setMemorySyncToast(null), 3000);
                }}
                className="w-full py-2 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 rounded-xl text-[10px] font-bold text-white shadow-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <span>SIMPAN & SINKRONKAN KE AI</span>
              </button>

              <div className="grid grid-cols-2 gap-2 shrink-0">
                <button
                  onClick={handleLoadActiveChatToPaste}
                  className="py-2 px-2.5 bg-purple-950/40 hover:bg-purple-900/40 border border-purple-500/35 text-purple-300 hover:text-white rounded-xl text-[10px] font-bold transition flex items-center justify-center gap-1 cursor-pointer active:scale-95"
                  title="Salin semua pesan di ruang obrolan saat ini"
                >
                  📥 Salin Obrolan Aktif
                </button>
                <button
                  onClick={handleRestoreFromPaste}
                  disabled={!pastedChatText.trim()}
                  className="py-2 px-2.5 bg-cyan-950/40 hover:bg-cyan-900/40 border border-cyan-500/35 text-cyan-300 hover:text-white rounded-xl text-[10px] font-bold transition flex items-center justify-center gap-1 cursor-pointer disabled:opacity-30 active:scale-95"
                  title="Gantikan riwayat pesan aktif dengan teks di atas"
                >
                  🔄 Pulihkan Sesi Obrolan
                </button>
              </div>

              <div className="p-2.5 bg-[#120e24]/30 border border-purple-500/10 rounded-lg text-[9px] text-purple-300 leading-normal flex items-start gap-2">
                <span className="shrink-0 text-cyan-400 font-mono font-bold">INFO:</span>
                <span>Teks di atas otomatis dikirim ke model AI (Gemini, Groq, OpenRouter, Ollama, WebLLM) sebagai memori konteks prioritas tinggi agar AI memahami masa lalu cerita Anda.</span>
              </div>
            </div>
          </div>
        ) : activeSidebarTab === 'secure_storage' ? (
          <div className="p-5 bg-white/5 border border-white/10 rounded-2xl space-y-4 shadow-xl flex flex-col flex-1 min-h-0">
            <div className="flex items-center justify-between shrink-0">
              <h4 className="text-xs font-bold uppercase tracking-wider text-gray-400 flex items-center gap-1.5">
                <Lock size={12} className="text-emerald-400" /> Secure Storage Logs
              </h4>
              <button
                onClick={() => {
                  setIsDecryptingLogs(true);
                  playAudioCue("send");
                  setTimeout(() => {
                    setShowEncryptedLog(!showEncryptedLog);
                    setIsDecryptingLogs(false);
                    playAudioCue("reflect");
                  }, 400);
                }}
                className="p-1.5 bg-white/5 border border-white/10 hover:border-emerald-500/30 text-gray-400 hover:text-emerald-300 rounded-lg transition"
              >
                {showEncryptedLog ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>

            {isDecryptingLogs ? (
              <div className="text-center py-12 text-emerald-400 font-mono text-xs flex items-center justify-center gap-2 flex-1">
                <RefreshCw className="animate-spin" size={14} />
                <span>SINKRONISASI & DEKRIPSI...</span>
              </div>
            ) : showEncryptedLog ? (
              <div className="space-y-2 flex-1 overflow-y-auto bg-black/40 border border-white/5 p-3 rounded-xl custom-scrollbar min-h-0">
                <div className="text-[9px] text-emerald-400 font-mono mb-2 border-b border-white/5 pb-1 flex justify-between">
                  <span>RAW PLAINTEXT DECRYPTED</span>
                  <span>STATUS: SECURE</span>
                </div>
                {messages.map((m, i) => (
                  <div
                    key={m.id || i}
                    className="text-[10px] border-b border-white/5 pb-2 mb-2 text-gray-300 relative group"
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-sans font-semibold text-gray-500 mr-1 text-[9px] uppercase">
                        [{m.role}]:
                      </span>
                      <div className="hidden group-hover:flex items-center gap-1">
                        <button
                          onClick={() => {
                            setEditingLogId(m.id);
                            setEditingLogText(m.content);
                          }}
                          className="p-1 hover:bg-white/10 rounded text-cyan-400 transition"
                          title="Edit Log"
                        >
                          <Edit3 size={10} />
                        </button>
                        <button
                          onClick={() => handleDeleteLog(m.id)}
                          className="p-1 hover:bg-red-500/20 rounded text-red-400 transition"
                          title="Delete Log"
                        >
                          <Trash2 size={10} />
                        </button>
                      </div>
                    </div>
                    {editingLogId === m.id ? (
                      <div className="space-y-1 mt-1">
                        <textarea
                          rows={3}
                          value={editingLogText}
                          onChange={(e) => setEditingLogText(e.target.value)}
                          className="w-full bg-black/60 border border-white/10 p-1.5 rounded text-[9px] font-mono text-white outline-none resize-none"
                        />
                        <div className="flex justify-end gap-1">
                          <button
                            onClick={() => setEditingLogId(null)}
                            className="px-2 py-0.5 bg-white/5 border border-white/10 hover:bg-white/10 rounded text-[9px]"
                          >
                            Batal
                          </button>
                          <button
                            onClick={() => handleSaveLog(m.id)}
                            className="px-2 py-0.5 bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 rounded text-[9px] text-white font-bold cursor-pointer"
                          >
                            Simpan
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="font-serif leading-tight">{m.content}</div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2 flex-1 overflow-y-auto bg-black/40 border border-white/5 p-3 rounded-xl font-mono text-[9px] text-gray-600 break-all select-none leading-normal custom-scrollbar min-h-0">
                <div className="text-[9px] text-gray-500 mb-2 border-b border-white/5 pb-1 flex justify-between">
                  <span>CIPHERTEXT AES/B64 ENCRYPTED</span>
                  <span>STATUS: ENCRYPTED</span>
                </div>
                {messages.map((m, i) => (
                  <div key={i} className="mb-2">
                    <span className="text-blue-500/50">
                      [{m.role === "user" ? "USR_CIPHER" : "NPC_CIPHER"}]:
                    </span>
                    <div className="text-gray-500 bg-white/[0.01] p-1 rounded mt-0.5 font-mono">
                      {encryptMessage(m.content).slice(0, 120)}...
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="text-[10px] text-gray-500 leading-relaxed shrink-0">
              Semua riwayat terenkripsi otomatis di tingkat lokal & cloud secara
              asinkron agar aman dari intervensi luar.
            </div>
          </div>
        ) : activeSidebarTab === 'npc_info' ? (
          <div className="p-4 bg-[#0a0a14]/95 border border-purple-500/25 rounded-2xl shadow-xl flex flex-col flex-1 min-h-0 text-left opacity-100">
            <div className="flex flex-col gap-1 shrink-0 mb-3 border-b border-white/5 pb-2">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-pink-400 animate-pulse" />
                <h4 className="text-[10px] font-black uppercase tracking-wider text-pink-400 font-mono">
                  ℹ️ NPC INFORMATION & LORE
                </h4>
              </div>
              <p className="text-[9px] text-gray-400 leading-normal">
                Lihat informasi, biografi, kepribadian, serta definisi detail untuk karakter pendamping Anda saat ini. Anda juga bisa menyunting informasi ini secara bebas.
              </p>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 custom-scrollbar pr-1">
              {isEditingNpc ? (
                <div className="space-y-4 bg-black/25 p-3 rounded-xl border border-white/5">
                  <h5 className="text-[10px] font-bold text-pink-300 font-mono tracking-wide uppercase">✏️ SUNTING INFORMASI KARAKTER</h5>
                  
                  <div>
                    <span className="text-[9px] text-purple-400 font-bold uppercase tracking-widest block mb-1">
                      Nama Karakter
                    </span>
                    <input
                      value={editedNpc.name || ""}
                      onChange={(e) =>
                        setEditedNpc({ ...editedNpc, name: e.target.value })
                      }
                      className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white focus:border-pink-500 outline-none"
                    />
                  </div>

                  <div>
                    <span className="text-[9px] text-purple-400 font-bold uppercase tracking-widest block mb-1">
                      Gender / Peran
                    </span>
                    <input
                      value={editedNpc.gender || ""}
                      onChange={(e) =>
                        setEditedNpc({ ...editedNpc, gender: e.target.value as any })
                      }
                      className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white focus:border-pink-500 outline-none"
                      placeholder="Contoh: Perempuan, Dungeon Master, dll."
                    />
                  </div>

                  <div>
                    <span className="text-[9px] text-purple-400 font-bold uppercase tracking-widest block mb-1">
                      Latar Belakang & Lore (Definisi)
                    </span>
                    <textarea
                      rows={5}
                      value={editedNpc.background || ""}
                      onChange={(e) =>
                        setEditedNpc({
                          ...editedNpc,
                          background: e.target.value,
                        })
                      }
                      className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white focus:border-pink-500 outline-none resize-none leading-relaxed"
                      placeholder="Latar belakang otomatis..."
                    />
                  </div>

                  <div>
                    <span className="text-[9px] text-purple-400 font-bold uppercase tracking-widest block mb-1">
                      Kepribadian
                    </span>
                    <textarea
                      rows={3}
                      value={editedNpc.personality || ""}
                      onChange={(e) =>
                        setEditedNpc({
                          ...editedNpc,
                          personality: e.target.value,
                        })
                      }
                      className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white focus:border-pink-500 outline-none resize-none leading-relaxed"
                      placeholder="Rincian kepribadian karakter..."
                    />
                  </div>

                  {character.aiMode === 'gamemaster' && (
                    <div>
                      <span className="text-[9px] text-cyan-400 font-bold uppercase tracking-widest block mb-1 font-mono">
                        ❖ Aturan Dunia / Laws of Universe
                      </span>
                      <textarea
                        rows={3}
                        value={editedNpc.worldRules || ""}
                        onChange={(e) =>
                          setEditedNpc({
                            ...editedNpc,
                            worldRules: e.target.value,
                          })
                        }
                        className="w-full bg-black/40 border border-cyan-500/20 p-2 rounded-xl text-xs text-white focus:border-cyan-400 outline-none resize-none leading-relaxed"
                        placeholder="Aturan absolut dunia RPG..."
                      />
                    </div>
                  )}

                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      onClick={() => {
                        playAudioCue("click");
                        setIsEditingNpc(false);
                      }}
                      className="px-2.5 py-1.5 bg-white/5 border border-white/10 hover:bg-white/10 text-[10px] text-gray-300 rounded-lg cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      onClick={() => {
                        playAudioCue("send");
                        handleSaveNpc();
                      }}
                      className="px-3 py-1.5 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-[10px] text-white font-bold rounded-lg cursor-pointer shadow-[0_0_10px_rgba(236,72,153,0.2)]"
                    >
                      Simpan Perubahan
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Character Header Info */}
                  <div className="flex gap-3 items-center p-3 bg-black/20 rounded-xl border border-white/5">
                    {character.avatarUrl ? (
                      <img
                        src={character.avatarUrl}
                        alt={character.name}
                        className="w-12 h-12 rounded-xl object-cover border border-pink-500/30 shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-xl bg-purple-950/40 border border-pink-500/30 flex items-center justify-center text-xl font-bold text-pink-300 shrink-0">
                        {character.name.charAt(0)}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <h5 className="text-[14px] font-bold text-white truncate">{character.name}</h5>
                      <span className="text-[9px] font-bold font-mono px-1.5 py-0.5 rounded uppercase bg-pink-500/10 text-pink-300 border border-pink-500/20">
                        {character.gender || "Active NPC"}
                      </span>
                    </div>
                  </div>

                  <div>
                    <span className="text-[8px] uppercase tracking-wider font-extrabold text-gray-400 block font-mono select-none mb-1">
                      📖 Latar Belakang & Lore:
                    </span>
                    <p className="text-[11px] text-gray-300 leading-relaxed bg-black/20 p-2.5 rounded-lg border border-white/5 whitespace-pre-wrap font-sans">
                      {character.background || "Belum ada deskripsi latar belakang."}
                    </p>
                  </div>

                  <div>
                    <span className="text-[8px] uppercase tracking-wider font-extrabold text-gray-400 block font-mono select-none mb-1">
                      🎭 Kepribadian:
                    </span>
                    <p className="text-[11px] text-gray-300 leading-relaxed bg-black/20 p-2.5 rounded-lg border border-white/5 whitespace-pre-wrap font-sans">
                      {character.personality || "Belum ada rincian kepribadian."}
                    </p>
                  </div>

                  {character.aiMode === 'gamemaster' && (
                    <div>
                      <span className="text-[8px] uppercase tracking-wider font-extrabold text-cyan-400 block font-mono select-none mb-1">
                        ❖ Aturan Dunia / Laws of Universe:
                      </span>
                      <p className="text-[11px] text-cyan-100/90 leading-relaxed bg-[#0d222e]/40 p-2.5 rounded-lg border border-cyan-500/15 whitespace-pre-wrap font-sans">
                        {character.worldRules || "Belum ada aturan dunia khusus."}
                      </p>
                    </div>
                  )}

                  <div className="flex justify-end pt-1">
                    <button
                      onClick={() => {
                        playAudioCue("click");
                        setEditedNpc({
                          name: character.name,
                          gender: character.gender,
                          avatarUrl: character.avatarUrl,
                          avatarPosition: character.avatarPosition || 50,
                          background: character.background,
                          personality: character.personality,
                          worldRules: character.worldRules || "",
                        });
                        setIsEditingNpc(true);
                      }}
                      className="px-3 py-1.5 bg-pink-500/10 hover:bg-pink-500/20 text-pink-300 border border-pink-500/30 text-[10px] font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1.5"
                    >
                      ✏️ Edit Information
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : activeSidebarTab === 'ai_settings' ? (
          <div className="p-4 bg-[#0a0a14]/95 border border-purple-500/25 rounded-2xl shadow-xl flex flex-col flex-1 min-h-0 text-left overflow-y-auto custom-scrollbar space-y-4">
             {/* Beautiful Header */}
             <div className="flex flex-col gap-1 border-b border-white/5 pb-2">
               <div className="flex items-center gap-1.5">
                 <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
                 <h4 className="text-[10px] font-black uppercase tracking-wider text-blue-400 font-mono">
                   🤖 AI COGNITIVE CORE & MODE
                 </h4>
               </div>
               <p className="text-[9px] text-gray-400 leading-normal">
                 Sesuaikan model otak neural, gaya permainan perang peran, dan kreativitas kecerdasan buatan secara real-time.
               </p>
             </div>

             {/* 0. Paste Chat Toggle */}
             <div className="space-y-1.5 border-b border-white/5 pb-3">
               <div className="bg-white/5 rounded-xl p-2.5 border border-white/5 flex items-center justify-between">
                 <div>
                   <span className="text-[9px] text-gray-300 uppercase tracking-wider font-mono font-bold block">Paste Chat (Konteks)</span>
                   <span className="text-[8px] text-gray-500 block">Sertakan konteks tempel dalam ingatan AI</span>
                 </div>
                 <button 
                   onClick={() => {
                     playAudioCue("click");
                     if (onUpdateSettings) {
                       onUpdateSettings({...settings, pasteChatEnabled: !settings.pasteChatEnabled});
                     }
                   }}
                   className={`w-9 h-4.5 rounded-full relative border transition-all duration-300 ${
                     settings.pasteChatEnabled 
                       ? 'bg-cyan-950/40 border-cyan-500/50 shadow-[0_0_8px_rgba(6,182,212,0.3)]' 
                       : 'bg-neutral-800 border-white/10'
                   }`}
                 >
                   <div className={`absolute top-[2px] w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                     settings.pasteChatEnabled 
                       ? 'right-1 bg-cyan-500 shadow-[0_0_6px_rgba(6,182,212,0.8)]' 
                       : 'left-1 bg-gray-400'
                   }`}></div>
                 </button>
               </div>
             </div>

             {/* 1. Model Provider */}
             <div className="space-y-1.5">
               <label className="text-[9px] font-extrabold uppercase tracking-wider text-gray-400 font-mono block">Brain Provider (Penyedia AI)</label>
               <div className="grid grid-cols-2 gap-1.5">
                 {[
                   { id: 'gemini', label: 'Google Gemini' },
                   { id: 'groq', label: 'Groq Cloud' },
                   { id: 'openrouter', label: 'OpenRouter' },
                   { id: 'ollama', label: 'Ollama (Lokal)' },
                   { id: 'webllm', label: 'WebLLM (GPU)' }
                 ].map((prov) => {
                   const isSel = (settings.provider || 'gemini') === prov.id;
                   return (
                     <button
                       key={prov.id}
                       onClick={() => {
                         playAudioCue("click");
                         if (onUpdateSettings) {
                           let initialModel = 'gemini-3.8-flash';
                           if (prov.id === 'groq') initialModel = 'llama-3.3-70b-versatile';
                           if (prov.id === 'ollama') initialModel = 'llama3';
                           if (prov.id === 'webllm') initialModel = 'Phi-3-mini-4k-instruct-q4f16_1-MLC';
                           if (prov.id === 'openrouter') initialModel = 'openai/gpt-4o-mini';

                           onUpdateSettings({
                             ...settings,
                             provider: prov.id as any,
                             model: initialModel,
                             ollamaUrl: prov.id === 'ollama' ? (settings.ollamaUrl || 'http://localhost:11434') : settings.ollamaUrl
                           });
                         }
                       }}
                       className={`py-1.5 px-2 rounded-lg text-[9px] font-bold transition-all text-center border cursor-pointer ${
                         isSel
                           ? 'bg-gradient-to-r from-blue-600 to-cyan-500 text-white border-blue-400/30 shadow-[0_0_12px_rgba(37,99,235,0.2)]'
                           : 'bg-black/30 text-gray-400 border-white/5 hover:bg-black/50 hover:text-white'
                       }`}
                     >
                       {prov.label}
                     </button>
                   );
                 })}
               </div>
             </div>

             {/* 2. Model Selection Dropdown */}
             <div className="space-y-1.5 bg-white/[0.02] border border-white/5 p-2.5 rounded-xl">
               <label className="text-[9px] font-extrabold uppercase tracking-wider text-gray-400 font-mono block">Neural Model (Model Otak)</label>
               <select
                 value={settings.model || 'gemini-3.8-flash'}
                 onChange={(e) => {
                   if (onUpdateSettings) {
                     onUpdateSettings({ ...settings, model: e.target.value });
                   }
                 }}
                 className="w-full bg-black/60 border border-white/10 rounded-lg p-2 text-[10px] text-white focus:border-cyan-400/50 transition outline-none"
               >
                 {(settings.provider || 'gemini') === 'gemini' && [
                   { id: 'gemini-3.8-flash', name: 'Gemini 3.8 Flash (Deep Reasoning - Sangat Direkomendasikan)' },
                   { id: 'gemini-3.5-flash', name: 'Gemini 3.5 Flash (Default)' },
                   { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash (Stabil & Cepat)' },
                   { id: 'gemini-3.1-flash-lite', name: 'Gemini 3.1 Flash Lite (Super Cepat & Hemat Kuota)' },
                 ].map(m => <option key={m.id} value={m.id} className="bg-neutral-950">{m.name}</option>)}

                 {(settings.provider || 'gemini') === 'groq' && [
                   { id: 'llama-3.3-70b-versatile', name: 'Llama 3.3 70B' },
                   { id: 'llama-3.1-8b-instant', name: 'Llama 3.1 8B (Fast)' },
                 ].map(m => <option key={m.id} value={m.id} className="bg-neutral-950">{m.name}</option>)}

                 {(settings.provider || 'gemini') === 'ollama' && [
                   { id: 'llama3', name: 'Llama 3 (8B)' },
                   { id: 'llama3.1', name: 'Llama 3.1' },
                   { id: 'gemma2', name: 'Gemma 2' },
                   { id: 'mistral', name: 'Mistral' },
                   { id: 'phi3', name: 'Phi 3' },
                   { id: 'qwen2', name: 'Qwen 2' },
                   { id: 'custom', name: 'Custom Model' },
                 ].map(m => <option key={m.id} value={m.id} className="bg-neutral-950">{m.name}</option>)}

                 {(settings.provider || 'gemini') === 'openrouter' && [
                   { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini (OpenAI)' },
                   { id: 'openai/gpt-4o', name: 'GPT-4o (OpenAI)' },
                   { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet' },
                   { id: 'anthropic/claude-3-haiku', name: 'Claude 3 Haiku' },
                   { id: 'google/gemini-flash-1.5', name: 'Gemini 1.5 Flash' },
                   { id: 'google/gemini-pro-1.5', name: 'Gemini 1.5 Pro' },
                   { id: 'meta-llama/llama-3-8b-instruct', name: 'Llama 3 8B' },
                   { id: 'meta-llama/llama-3-70b-instruct', name: 'Llama 3 70B' }
                 ].map(m => <option key={m.id} value={m.id} className="bg-neutral-950">{m.name}</option>)}

                 {(settings.provider || 'gemini') === 'webllm' && [
                   { id: 'Phi-3-mini-4k-instruct-q4f16_1-MLC', name: 'Phi 3 Mini (3.8B)' },
                   { id: 'gemma-2b-it-q4f16_1-MLC', name: 'Gemma 2B' },
                   { id: 'TinyLlama-1.1B-Chat-v1.0-q4f16_1-MLC', name: 'TinyLlama (1.1B)' },
                   { id: 'Qwen2-0.5B-Instruct-q4f16_1-MLC', name: 'Qwen 2 (0.5B)' },
                   { id: 'Llama-3-8B-Instruct-q4f16_1-MLC', name: 'Llama 3 (8B)' },
                 ].map(m => <option key={m.id} value={m.id} className="bg-neutral-950">{m.name}</option>)}
               </select>

               {/* Additional suboptions for Ollama & WebLLM inside sidebar */}
               {settings.provider === 'ollama' && (
                 <div className="space-y-1.5 mt-2 pt-2 border-t border-white/5">
                   <div>
                     <label className="text-[8px] text-gray-500 block uppercase font-mono">Ollama API URL</label>
                     <input
                       type="text"
                       value={settings.ollamaUrl || 'http://localhost:11434'}
                       onChange={(e) => {
                         if (onUpdateSettings) onUpdateSettings({ ...settings, ollamaUrl: e.target.value });
                       }}
                       placeholder="http://localhost:11434"
                       className="w-full bg-black/40 border border-white/10 rounded px-1.5 py-1 text-[9px] text-white font-mono"
                     />
                   </div>
                   {settings.model === 'custom' && (
                     <div>
                       <label className="text-[8px] text-gray-500 block uppercase font-mono">Custom Model Name</label>
                       <input
                         type="text"
                         placeholder="Contoh: llama3:8b, mistral"
                         onChange={(e) => {
                           if (onUpdateSettings) onUpdateSettings({ ...settings, model: e.target.value });
                         }}
                         className="w-full bg-black/40 border border-white/10 rounded px-1.5 py-1 text-[9px] text-white font-mono"
                       />
                     </div>
                   )}
                 </div>
               )}

               {settings.provider === 'webllm' && (
                 <div className="text-[8px] text-emerald-400 leading-normal mt-1 flex items-center gap-1">
                   <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                   <span>Model disimpan lokal di cache peramban GPU Anda.</span>
                 </div>
               )}
             </div>

             {/* 3. AI Mode (Gaya Permainan) */}
             <div className="space-y-1.5">
               <label className="text-[9px] font-extrabold uppercase tracking-wider text-cyan-400 font-mono block flex items-center gap-1">
                 <span>❖ AI Mode (Gaya Permainan)</span>
               </label>
               <div className="grid grid-cols-2 gap-1.5">
                 {[
                   { id: 'narrative', label: 'Narrative', desc: 'Descriptive' },
                   { id: 'gamemaster', label: 'GM Mode', desc: 'Consequences' },
                   { id: 'chat', label: 'Casual', desc: 'Conversational' },
                   { id: 'assistant', label: 'Assistant', desc: 'Writing help' }
                 ].map((mode) => {
                   const activeMode = character.aiMode || settings.aiMode || 'narrative';
                   const isSel = activeMode === mode.id;
                   return (
                     <button
                       key={mode.id}
                       onClick={() => {
                         playAudioCue("click");
                         // Update active character's mode
                         if (onUpdateCharacter) {
                           onUpdateCharacter({ ...character, aiMode: mode.id as any });
                         }
                         // Also sync with global session settings if present
                         if (onUpdateSettings) {
                           onUpdateSettings({ ...settings, aiMode: mode.id as any });
                         }
                       }}
                       className={`p-2 rounded-xl border text-left flex flex-col justify-between h-14 transition-all duration-300 cursor-pointer ${
                         isSel
                           ? 'bg-gradient-to-b from-purple-950/40 to-cyan-950/20 border-cyan-400 text-white shadow-[0_0_12px_rgba(6,182,212,0.15)] scale-[1.02]'
                           : 'bg-black/30 text-gray-400 border-white/5 hover:bg-black/50 hover:text-white'
                       }`}
                     >
                       <div>
                         <div className="font-extrabold text-[9px] uppercase tracking-wide truncate text-white">{mode.label}</div>
                         <div className="text-[8px] text-gray-500 mt-0.5 line-clamp-1">{mode.desc}</div>
                       </div>
                     </button>
                   );
                 })}
               </div>
             </div>

             {/* 4. Type AI (Tingkat Kreativitas) */}
             <div className="space-y-1.5">
               <label className="text-[9px] font-extrabold uppercase tracking-wider text-cyan-400 font-mono block">❖ Type AI (Kreativitas)</label>
               <div className="grid grid-cols-3 gap-1">
                 {[
                   { id: 'creative', label: 'Creative', icon: '🔮' },
                   { id: 'balanced', label: 'Balanced', icon: '⚖️' },
                   { id: 'precise', label: 'Precise', icon: '🎯' }
                 ].map((type) => {
                   const activeType = character.typeAi || settings.typeAi || 'balanced';
                   const isSel = activeType === type.id;
                   return (
                     <button
                       key={type.id}
                       onClick={() => {
                         playAudioCue("click");
                         if (onUpdateCharacter) {
                           onUpdateCharacter({ ...character, typeAi: type.id as any });
                         }
                         if (onUpdateSettings) {
                           onUpdateSettings({ ...settings, typeAi: type.id as any });
                         }
                       }}
                       className={`py-2 px-1 rounded-xl border text-center transition-all duration-300 cursor-pointer ${
                         isSel
                           ? 'bg-gradient-to-b from-purple-950/40 to-cyan-950/20 border-cyan-400 text-white shadow-[0_0_12px_rgba(6,182,212,0.15)]'
                           : 'bg-black/30 border-white/5 text-gray-400 hover:text-white'
                       }`}
                     >
                       <div className="font-extrabold text-[9px] uppercase tracking-wide truncate">{type.label} {type.icon}</div>
                     </button>
                   );
                 })}
               </div>
             </div>

             {/* 5. Sliders (Text Length & Mature 18+) */}
             <div className="space-y-3 pt-2 border-t border-white/5">
               {/* Text Length Slider */}
               <div className="bg-white/5 rounded-xl p-2.5 border border-white/5">
                 <div className="flex justify-between items-center mb-1">
                   <span className="text-[9px] text-gray-300 uppercase tracking-wider font-mono font-bold">Text Length (Panjang Teks)</span>
                   <span className="text-[10px] text-cyan-400 font-mono font-bold">LVL {settings.textLength}</span>
                 </div>
                 <input 
                   type="range" 
                   min="1" 
                   max="5" 
                   value={settings.textLength}
                   onChange={(e) => {
                     if (onUpdateSettings) {
                       onUpdateSettings({...settings, textLength: parseInt(e.target.value) as any});
                     }
                   }}
                   className="w-full accent-cyan-400 h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer"
                 />
                 <div className="flex justify-between text-[8px] text-gray-500 mt-1">
                   <span>Short</span>
                   <span>Balanced</span>
                   <span>Descriptive</span>
                 </div>
               </div>

               {/* Mature 18+ Toggle */}
               <div className="bg-white/5 rounded-xl p-2.5 border border-white/5 flex items-center justify-between">
                 <div>
                   <span className="text-[9px] text-gray-300 uppercase tracking-wider font-mono font-bold block">Mature Language (18+)</span>
                   <span className="text-[8px] text-gray-500 block">Izinkan ekspresi eksplisit dewasa</span>
                 </div>
                 <button 
                   onClick={() => {
                     playAudioCue("click");
                     if (onUpdateSettings) {
                       onUpdateSettings({...settings, allow18Plus: !settings.allow18Plus});
                     }
                   }}
                   className={`w-9 h-4.5 rounded-full relative border transition-all duration-300 ${
                     settings.allow18Plus 
                       ? 'bg-red-950/40 border-red-500/50 shadow-[0_0_8px_rgba(239,68,68,0.3)]' 
                       : 'bg-neutral-800 border-white/10'
                   }`}
                 >
                   <div className={`absolute top-[2px] w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                     settings.allow18Plus 
                       ? 'right-1 bg-red-500 shadow-[0_0_6px_rgba(239,68,68,0.8)]' 
                       : 'left-1 bg-gray-400'
                   }`}></div>
                 </button>
               </div>
             </div>
          </div>
        ) : (
          <div className="bg-[#130f24]/50 border border-purple-500/15 rounded-2xl shadow-xl overflow-hidden flex flex-col flex-1 min-h-0">
            {/* Profile */}
            <div className="relative h-24 sm:h-32 bg-purple-950/40 shrink-0">
              {character.avatarUrl ? (
                <img
                  src={character.avatarUrl}
                  alt={character.name}
                  style={{
                    objectPosition: `center ${character.avatarPosition ?? 50}%`,
                  }}
                  className="w-full h-full object-cover opacity-70"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-4xl italic font-serif text-purple-300/30">
                  {character.name.charAt(0)}
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0e0a1c] via-transparent to-transparent"></div>

              <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
                <div>
                  <h4 className="text-lg font-bold text-white drop-shadow-md">
                    {character.name}
                  </h4>
                  <p className="text-[10px] text-cyan-400 flex items-center gap-1 drop-shadow-md font-semibold">
                    <UserCheck size={12} /> Active NPC{" "}
                    {character.gender ? `• ${character.gender}` : ""}
                  </p>
                </div>

                {!character.isDefault && (
                  <button
                    onClick={() => {
                      if (isEditingNpc) {
                        handleSaveNpc();
                      } else {
                        setEditedNpc({
                          name: character.name,
                          gender: character.gender,
                          avatarUrl: character.avatarUrl,
                          avatarPosition: character.avatarPosition || 50,
                          background: character.background,
                          personality: character.personality,
                        });
                        setIsEditingNpc(true);
                      }
                    }}
                    className="p-1.5 bg-black/40 border border-white/20 rounded-lg text-gray-300 hover:text-white hover:bg-black/60 transition backdrop-blur-md mb-1 cursor-pointer"
                    title={isEditingNpc ? "Simpan Perubahan" : "Edit Karakter"}
                  >
                    {isEditingNpc ? (
                      <Check size={14} className="text-emerald-400" />
                    ) : (
                      <Edit3 size={14} />
                    )}
                  </button>
                )}
              </div>
            </div>

            <div className="p-4 space-y-4 flex-1 overflow-y-auto custom-scrollbar">
              <div className="space-y-3">
                {isEditingNpc ? (
                  <>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                        Profile Image
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload}
                        className="w-full text-xs text-gray-400 file:mr-2 file:py-1 file:px-2 file:rounded file:border-0 file:text-[10px] file:bg-white/10 file:text-white hover:file:bg-white/20"
                      />
                      {editedNpc.avatarUrl && (
                        <div className="mt-2 space-y-2">
                          <div className="w-full h-16 rounded-xl overflow-hidden border border-white/10">
                            <img
                              src={editedNpc.avatarUrl}
                              alt="Preview"
                              style={{
                                objectPosition: `center ${editedNpc.avatarPosition ?? 50}%`,
                              }}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[9px] text-gray-500">
                              Posisi:
                            </span>
                            <input
                              type="range"
                              min="0"
                              max="100"
                              value={editedNpc.avatarPosition ?? 50}
                              onChange={(e) =>
                                setEditedNpc({
                                  ...editedNpc,
                                  avatarPosition: parseInt(e.target.value),
                                })
                              }
                              className="flex-1 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                        Nama
                      </span>
                      <input
                        value={editedNpc.name || ""}
                        onChange={(e) =>
                          setEditedNpc({ ...editedNpc, name: e.target.value })
                        }
                        className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white focus:border-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                        Gender
                      </span>
                      <select
                        value={editedNpc.gender || "Bebas"}
                        onChange={(e) =>
                          setEditedNpc({
                            ...editedNpc,
                            gender: e.target.value as any,
                          })
                        }
                        className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white focus:border-blue-500 outline-none"
                      >
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                        <option value="Non-biner (Game Master)">
                          Non-biner (Game Master)
                        </option>
                        <option value="Bebas">Bebas</option>
                      </select>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                        Definisi Karakter
                      </span>
                      <textarea
                        rows={4}
                        value={editedNpc.background || ""}
                        onChange={(e) =>
                          setEditedNpc({
                            ...editedNpc,
                            background: e.target.value,
                          })
                        }
                        className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white focus:border-blue-500 outline-none resize-none leading-relaxed"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                        Kepribadian
                      </span>
                      <textarea
                        rows={4}
                        value={editedNpc.personality || ""}
                        onChange={(e) =>
                          setEditedNpc({
                            ...editedNpc,
                            personality: e.target.value,
                          })
                        }
                        className="w-full bg-black/40 border border-white/10 p-2 rounded-xl text-xs text-white focus:border-blue-500 outline-none resize-none leading-relaxed"
                      />
                    </div>
                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        onClick={() => setIsEditingNpc(false)}
                        className="px-2 py-1 bg-white/5 border border-white/10 hover:bg-white/10 text-[10px] text-gray-300 rounded"
                      >
                        Batal
                      </button>
                      <button
                        onClick={handleSaveNpc}
                        className="px-2 py-1 bg-blue-600 hover:bg-blue-500 text-[10px] text-white rounded"
                      >
                        Simpan
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                        Definisi Karakter
                      </span>
                      <p className="text-xs text-gray-300 leading-relaxed font-sans bg-black/20 p-2.5 rounded border border-white/5 whitespace-pre-wrap">
                        {character.background || "Belum ada definisi karakter."}
                      </p>
                    </div>
                    <div>
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest block mb-0.5">
                        Kepribadian
                      </span>
                      <p className="text-xs text-gray-300 leading-relaxed font-sans bg-black/20 p-2.5 rounded border border-white/5 whitespace-pre-wrap">
                        {character.personality ||
                          "Belum ada rincian kepribadian."}
                      </p>
                    </div>
                  </>
                )}

                {/* NPC Auto-saved Neural Memories Section */}
                <div className="border-t border-white/5 pt-3 space-y-2">
                  <span className="text-[10px] text-purple-400 uppercase tracking-widest block font-bold font-mono">
                    🧠 Memori Enkripsi NPC
                  </span>
                  <p className="text-[9px] text-gray-400 leading-relaxed font-sans">
                    *Memori biner diekstrak & disimpan secara otomatis dari
                    petualangan Anda.*
                  </p>
                  {character.memories && character.memories.length > 0 ? (
                    <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1 custom-scrollbar">
                      {character.memories.map((memory, index) => (
                        <div
                          key={index}
                          className="bg-purple-950/20 border border-purple-500/20 p-2.5 rounded-xl text-[11px] text-gray-300 font-sans leading-relaxed relative overflow-hidden group hover:border-cyan-500/30 transition-all"
                        >
                          <div className="absolute top-0 right-0 w-1.5 h-full bg-purple-500 group-hover:bg-cyan-500 transition-colors" />
                          <span className="block font-semibold text-[9px] text-cyan-400 mb-0.5 font-mono">
                            #MEMORI_{index + 1}
                          </span>
                          {memory}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="bg-black/30 border border-dashed border-white/5 p-3 rounded-xl text-center text-[10px] text-gray-500">
                      Belum ada ingatan terenkripsi. Terus ajak {character.name}{" "}
                      berbicara untuk merajut benang memori!
                    </div>
                  )}
                </div>


              </div>

              {/* Delete Character Option for custom NPCs */}
              {!character.isDefault && (
                <div className="border-t border-white/5 pt-4 shrink-0">
                  <button
                    onClick={() => setShowDeleteConfirm(true)}
                    className="w-full py-2 bg-red-950/20 hover:bg-red-950/40 text-red-400 border border-red-500/10 rounded-xl text-xs flex items-center justify-center gap-2 transition"
                  >
                    <Trash2 size={13} /> Delete Character Completely
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

      </div>

      {/* Custom Confirmation Modals for safe iframe-compatible prompts */}
      {showResetConfirm && (
        <div
          id="reset-confirm-modal"
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        >
          <div className="bg-[#12141d] border border-red-500/20 max-w-md w-full rounded-2xl p-6 space-y-6 shadow-[0_0_50px_rgba(239,68,68,0.15)] relative">
            <div className="flex items-center gap-3 border-b border-white/5 pb-3">
              <div className="p-2 bg-red-500/10 rounded-xl text-red-400">
                <Trash2 size={20} />
              </div>
              <h3 className="text-base font-bold text-white">
                Reset Memori Karakter?
              </h3>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed">
              Apakah Anda yakin ingin menghapus seluruh riwayat percakapan
              dengan <strong>{character.name}</strong>? Tindakan ini akan
              mengosongkan semua memori percakapan, sehingga karakter akan
              melupakan pembicaraan sebelumnya dan memulai kembali dari sapaan
              awal.
            </p>

            <div className="flex justify-end gap-3 pt-2">
              <button
                id="btn-cancel-reset"
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-semibold rounded-xl text-gray-300 transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                id="btn-confirm-reset"
                onClick={clearHistory}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-xs font-semibold rounded-xl text-white shadow-lg transition-all cursor-pointer"
              >
                Hapus & Setel Ulang
              </button>
            </div>
          </div>
        </div>
      )}

      {showDeleteConfirm && (
        <div
          id="delete-confirm-modal"
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in"
        >
          <div className="bg-[#12141d] border border-red-500/20 max-w-md w-full rounded-2xl p-6 space-y-6 shadow-[0_0_50px_rgba(239,68,68,0.15)] relative">
            <div className="flex items-center gap-3 border-b border-white/5 pb-3">
              <div className="p-2 bg-red-500/10 rounded-xl text-red-400">
                <Trash2 size={20} />
              </div>
              <h3 className="text-base font-bold text-white">
                Hapus Karakter Permanen?
              </h3>
            </div>

            <p className="text-xs text-gray-300 leading-relaxed">
              Apakah Anda yakin ingin menghapus sepenuhnya karakter{" "}
              <strong>{character.name}</strong> beserta semua berkas log
              percakapannya? Tindakan ini bersifat permanen dan tidak dapat
              dibatalkan.
            </p>

            <div className="flex justify-end gap-3 pt-2">
              <button
                id="btn-cancel-delete"
                onClick={() => setShowDeleteConfirm(false)}
                className="px-4 py-2 bg-white/5 border border-white/10 hover:bg-white/10 text-xs font-semibold rounded-xl text-gray-300 transition-all cursor-pointer"
              >
                Batal
              </button>
              <button
                id="btn-confirm-delete"
                onClick={handleDeleteCharacter}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-xs font-semibold rounded-xl text-white shadow-lg transition-all cursor-pointer"
              >
                Hapus Permanen
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
