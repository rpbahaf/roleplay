export type TextLengthLevel = 1 | 2 | 3 | 4 | 5;

export type WorldGenre = 'FANTASY' | 'MODERN' | 'HIGH FANTASY' | 'CYBERPUNK';

export interface Character {
  id: string;
  userId: string;
  name: string;
  gender?: 'Laki-laki' | 'Perempuan' | 'Non-biner (Game Master)' | 'Bebas';
  avatarUrl?: string;
  avatarPosition?: number;
  personality: string;
  background: string;
  speakingStyle: string;
  intro: string;
  strengths?: string;
  specialization?: string;
  isDefault: boolean;
  isPermanent?: boolean;
  isGamemasterWorld?: boolean;
  selectedGenre?: WorldGenre;
  destiny?: string;
  currentPosition?: string;
  persona?: 'fantasy' | 'normal' | 'cyberpunk' | 'medieval' | 'detective' | 'horror' | 'high_fantasy';
  aiMode?: 'narrative' | 'gamemaster' | 'chat' | 'assistant';
  typeAi?: 'creative' | 'balanced' | 'precise';
  memories?: string[];
  worldRules?: string;
}

export interface Message {
  id: string;
  role: 'user' | 'npc';
  content: string;
  timestamp: number;
}

export interface ChatSettings {
  textLength: TextLengthLevel;
  allow18Plus: boolean;
  provider?: 'gemini' | 'groq' | 'ollama' | 'webllm' | 'openrouter' | 'openai';
  model?: string;
  ollamaUrl?: string;
  ollamaApiKey?: string;
  geminiApiKey?: string;
  openaiApiKey?: string;
  aiMode?: 'narrative' | 'gamemaster' | 'chat' | 'assistant';
  typeAi?: 'creative' | 'balanced' | 'precise';
  pasteChatEnabled: boolean;
}

export interface ChatSession {
  id: string;
  characterId: string;
  userId: string;
  settings: ChatSettings;
  updatedAt: number;
}

