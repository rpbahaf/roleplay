import { useState, useEffect } from "react";
import Chat from "./components/Chat";
import Settings from "./components/Settings";
import CharacterCreation from "./components/CharacterCreation";
import Toast from "./components/ui/Toast";
import LoginGate from "./components/auth/LoginGate";
import Sidebar from "./components/navigation/Sidebar";
import Header from "./components/navigation/Header";
import HomeView from "./components/home/HomeView";
import IsekaiPortal from "./components/IsekaiPortal";
import DeleteConfirmModal from "./components/modals/DeleteConfirmModal";
import CharacterProfileModal from "./components/modals/CharacterProfileModal";
import SettingsModal from "./components/modals/SettingsModal";
import { Character, ChatSettings } from "./types";
import {
  loadCharacters,
  saveCharacter,
  deleteCharacter,
} from "./lib/storage";
import { defaultCharacters } from "./constants/gameData";
import { playAudioCue } from "./utils/audio";
import { personaDisplayNames, personaBackgrounds } from "./utils/dialogue";
import { PersonaType } from "./components/home/InstantSummoner";
import { GenreTab } from "./components/home/CharacterList";

export default function App() {
  const [view, setView] = useState<"home" | "chat" | "settings" | "create" | "rebirth">("home");

  const [settings, setSettings] = useState<ChatSettings>(() => {
    const saved = localStorage.getItem("nova_rp_settings");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        let model = parsed.model ?? "gemini-3.8-flash";
        if (model === "gemini-2.5-pro") {
          model = "gemini-3.8-flash";
        }
        return {
          textLength: parsed.textLength ?? 2,
          allow18Plus: parsed.allow18Plus ?? false,
          provider: parsed.provider ?? "gemini",
          model,
          pasteChatEnabled: parsed.pasteChatEnabled ?? true,
        };
      } catch (e) {
        console.error("Failed to parse settings:", e);
      }
    }
    return {
      textLength: 2,
      allow18Plus: false,
      provider: "gemini",
      model: "gemini-3.8-flash",
      pasteChatEnabled: true,
    };
  });

  const [character, setCharacter] = useState<Character | null>(null);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [user, setUser] = useState<{
    uid: string;
    displayName: string;
    photoURL?: string;
  } | null>(null);

  const [loadingChars, setLoadingChars] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [mainPromptInput, setMainPromptInput] = useState("");
  const [startPrompt, setStartPrompt] = useState<string | null>(null);

  // Genre filter and dynamic states
  const [activeTab, setActiveTab] = useState<GenreTab>("all");
  const [isSummoning, setIsSummoning] = useState(false);
  const [summonPersona, setSummonPersona] = useState<PersonaType>("fantasy");
  const [summonError, setSummonError] = useState<string | null>(null);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [charToDelete, setCharToDelete] = useState<string | null>(null);
  const [selectedProfileChar, setSelectedProfileChar] = useState<Character | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleInstantAISummon = async () => {
    if (!user) return;
    const customCount = characters.length;
    if (customCount >= 3) {
      showToast(
        "⚠️ Batas tercapai! Anda hanya dapat memiliki maksimal 3 karakter AI. Silakan hapus salah satu karakter terlebih dahulu."
      );
      return;
    }
    setIsSummoning(true);
    setSummonError(null);
    playAudioCue("reflect");

    try {
      const response = await fetch("/api/generate-character", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ persona: summonPersona, settings }),
      });

      if (!response.ok) {
        throw new Error(
          "Gagal menghubungi Neural Gate. Pastikan koneksi server atau API Key aktif."
        );
      }

      const characterData = await response.json();

      const newChar: Character = {
        ...characterData,
        id: `custom_ai_${Date.now()}`,
        userId: user.uid,
        isDefault: false,
        persona: summonPersona,
        aiMode: "narrative",
        typeAi: "balanced",
      };

      await saveCharacter(user.uid, newChar);
      setCharacters((prev) => [...prev, newChar]);
      setCharacter(newChar);
      setView("chat");
      setIsSummoning(false);
      showToast(
        `Berhasil! ${newChar.name} telah dipanggil melalui Neural Gate.`
      );
    } catch (err: unknown) {
      console.error(err);
      const errMsg =
        err instanceof Error
          ? err.message
          : "Gagal memanggil karakter. Silakan coba lagi.";
      setSummonError(errMsg);
      setIsSummoning(false);
    }
  };

  // Save settings on update
  useEffect(() => {
    localStorage.setItem("nova_rp_settings", JSON.stringify(settings));
  }, [settings]);

  // Whenever the view changes, automatically close the mobile sidebar
  useEffect(() => {
    setIsSidebarOpen(false);
  }, [view]);

  // Load user from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem("nova_rp_user");
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error("Failed to parse stored user:", e);
      }
    }
  }, []);

  // Fetch characters when user state changes
  useEffect(() => {
    async function fetchCharacters() {
      if (!user) return;
      setLoadingChars(true);
      const uid = user.uid;
      const loaded = await loadCharacters(uid);

      const mergedDefaults = defaultCharacters.map((dc) => {
        const serverVer = loaded.find((lc) => lc.id === dc.id);
        const baseChar = serverVer ? { ...dc, ...serverVer } : dc;
        return {
          ...baseChar,
          intro: dc.intro, // Force latest template intro from code updates
          isDefault: true,
        };
      });

      const customChars = loaded
        .filter((lc) => !defaultCharacters.some((dc) => dc.id === lc.id))
        .map((cc) => {
          return {
            ...cc,
            isDefault: false,
          };
        });

      const allChars = [...mergedDefaults, ...customChars];
      setCharacters(allChars);
      setCharacter((prev) => {
        if (!prev) return allChars.length > 0 ? allChars[0] : null;
        const updated = allChars.find((c) => c.id === prev.id);
        return updated || prev;
      });
      setLoadingChars(false);
    }
    fetchCharacters();
  }, [user]);

  const handleLogin = (newUser: { uid: string; displayName: string; photoURL?: string }) => {
    setUser(newUser);
    localStorage.setItem("nova_rp_user", JSON.stringify(newUser));
  };

  const handleSendMainPrompt = () => {
    if (!mainPromptInput.trim()) return;
    let target = character;
    if (!target) {
      if (characters.length > 0) {
        target = characters[0];
        setCharacter(target);
      } else {
        showToast(
          "⚠️ Anda belum memiliki karakter. Silakan buat karakter baru atau pilih salah satu kartu skenario!"
        );
        return;
      }
    }
    playAudioCue("receive");
    setStartPrompt(mainPromptInput.trim());
    setMainPromptInput("");
    setView("chat");
  };

  const handleSuggestionClick = async (persona: string, promptText: string) => {
    if (!user) return;
    playAudioCue("receive");
    let targetChar = characters.find((c) => c.persona === persona);
    if (!targetChar) {
      const customCount = characters.length;
      if (customCount >= 3) {
        showToast(
          "⚠️ Batas tercapai! Anda hanya dapat memiliki maksimal 3 karakter AI. Silakan hapus salah satu karakter terlebih dahulu."
        );
        return;
      }

      const newChar: Character = {
        id: `default_${persona}_${Date.now()}`,
        name: personaDisplayNames[persona] || "Penduduk Dimensi",
        background:
          personaBackgrounds[persona] || "Seorang karakter misterius.",
        personality: "Misterius, responsif, dan siap membantu petualangan Anda.",
        speakingStyle: "Bahasa Indonesia formal, deskriptif, dan sastrawi tingkat tinggi.",
        intro:
          "Selamat datang kembali di dimensi takdir biner. Silakan mulai petualangan bersamaku...",
        avatarUrl: "",
        avatarPosition: 50,
        userId: user.uid,
        isDefault: false,
        persona: persona as PersonaType,
        aiMode: "narrative",
        typeAi: "balanced",
      };
      await saveCharacter(user.uid, newChar);
      setCharacters((prev) => [...prev, newChar]);
      targetChar = newChar;
    }

    setStartPrompt(promptText);
    setCharacter(targetChar);
    setView("chat");
  };

  const handleCreateCharacter = async (
    newData: Omit<Character, "id" | "userId" | "isDefault">
  ) => {
    if (!user) return;
    const customCount = characters.length;
    if (customCount >= 3) {
      showToast(
        "⚠️ Batas tercapai! Anda hanya dapat memiliki maksimal 3 karakter AI. Silakan hapus salah satu karakter terlebih dahulu."
      );
      return;
    }
    const uid = user.uid;
    const newChar: Character = {
      ...newData,
      id: `custom_${Date.now()}`,
      userId: uid,
      isDefault: false,
      aiMode: newData.aiMode || "narrative",
      typeAi: newData.typeAi || "balanced",
    };

    await saveCharacter(uid, newChar);
    setCharacters((prev) => [...prev, newChar]);
    setCharacter(newChar);
    setView("chat");
  };

  const handleDeleteCharacter = async (charId: string) => {
    if (!user) return;
    await deleteCharacter(user.uid, charId);
    setCharacters((prev) => prev.filter((c) => c.id !== charId));
    setCharacter(null);
    setView("home");
  };

  const handleUpdateCharacter = async (updatedChar: Character) => {
    if (!user) return;
    await saveCharacter(user.uid, updatedChar);
    setCharacters((prev) =>
      prev.map((c) => (c.id === updatedChar.id ? updatedChar : c))
    );
    setCharacter(updatedChar);
  };

  // If user is not logged in, display the gorgeous Lock Screen Gate
  if (!user) {
    return <LoginGate onLogin={handleLogin} />;
  }

  // Active Authenticated App Layout
  return (
    <div className="flex flex-col md:flex-row h-screen h-[100dvh] w-full overflow-hidden bg-[#07050e] text-gray-100 font-sans relative animate-fade-in">
      {/* SIDEBAR */}
      <Sidebar
        isOpen={isSidebarOpen}
        isCollapsed={isSidebarCollapsed}
        onClose={() => setIsSidebarOpen(false)}
        onToggleCollapse={() => setIsSidebarCollapsed((prev) => !prev)}
        characters={characters}
        selectedCharacter={character}
        onSelectCharacter={(char) => {
          playAudioCue("receive");
          setCharacter(char);
          setView("chat");
        }}
        onNewChat={() => {
          playAudioCue("click");
          setCharacter(null);
          setView("home");
        }}
        user={user}
        onOpenSettings={() => {
          playAudioCue("click");
          setIsSettingsModalOpen(true);
        }}
      />

      {/* MAIN SCREEN AREA */}
      <main className="flex-1 flex flex-col bg-[radial-gradient(circle_at_center,_#140d2b_0%,_#07050e_100%)] overflow-hidden">
        {/* Navigation Bar */}
        <Header
          view={view}
          onOpenMobileSidebar={() => setIsSidebarOpen(true)}
          onNavigateHome={() => setView("home")}
          onOpenSettings={() => setView("settings")}
        />

        {/* Dynamic Display Stage */}
        <div
          className={`flex-1 ${
            view === "chat" ? "p-0 overflow-hidden" : "p-4 sm:p-6 md:p-8 overflow-y-auto"
          }`}
        >
          {/* HOME VIEW */}
          {view === "home" && (
            <HomeView
              user={user}
              character={character}
              characters={characters}
              loadingChars={loadingChars}
              mainPromptInput={mainPromptInput}
              onChangePromptInput={setMainPromptInput}
              onSubmitPrompt={handleSendMainPrompt}
              onSelectSuggestion={handleSuggestionClick}
              onSelectCharacter={(char) => {
                playAudioCue("click");
                setCharacter(char);
              }}
              onOpenCreate={() => {
                playAudioCue("click");
                const customCount = characters.filter((c) => !c.isDefault).length;
                if (customCount >= 3) {
                  showToast(
                    "⚠️ Batas tercapai! Anda hanya dapat memiliki maksimal 3 karakter kustom. Silakan hapus salah satu karakter kustom terlebih dahulu."
                  );
                } else {
                  setView("create");
                }
              }}
              onOpenRebirth={() => setView("rebirth")}
              isSummoning={isSummoning}
              summonPersona={summonPersona}
              onPersonaChange={(p) => {
                playAudioCue("click");
                setSummonPersona(p);
              }}
              onInstantSummon={handleInstantAISummon}
              summonError={summonError}
              activeTab={activeTab}
              onTabChange={(tab) => {
                playAudioCue("click");
                setActiveTab(tab);
              }}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onSelectProfile={(char) => setSelectedProfileChar(char)}
              onStartChat={(char) => {
                playAudioCue("receive");
                setCharacter(char);
                setView("chat");
              }}
              onConfirmDelete={(charId) => setCharToDelete(charId)}
              playAudioCue={playAudioCue}
              showToast={showToast}
            />
          )}

          {/* CREATE CHARACTER VIEW */}
          {view === "create" && (
            <CharacterCreation
              onCreate={handleCreateCharacter}
              onBack={() => setView("home")}
              isLimitReached={characters.length >= 3}
            />
          )}

          {/* ISEKAI REBIRTH PORTAL VIEW */}
          {view === "rebirth" && (
            <IsekaiPortal
              userId={user.uid}
              onRebirthComplete={async (newChar) => {
                await saveCharacter(user.uid, newChar);
                setCharacters((prev) => [...prev, newChar]);
                setCharacter(newChar);
                setView("chat");
                showToast(`🔮 Reinkarnasi berhasil! Karunia "${newChar.specialization?.replace("Karunia:", "")?.trim()}" telah bersemayam di jiwamu.`);
              }}
              onBack={() => setView("home")}
              playAudioCue={playAudioCue}
              showToast={showToast}
            />
          )}

          {/* ACTIVE CHAT VIEW */}
          {view === "chat" && character && (
            <Chat
              character={character}
              settings={settings}
              userId={user.uid}
              onBack={() => setView("home")}
              onOpenSidebar={() => setIsSidebarOpen(true)}
              onDeleteCharacter={handleDeleteCharacter}
              onUpdateCharacter={handleUpdateCharacter}
              characters={characters}
              onSelectCharacter={(char) => setCharacter(char)}
              onUpdateSettings={setSettings}
              startPrompt={startPrompt}
              onClearStartPrompt={() => setStartPrompt(null)}
            />
          )}

          {/* SETTINGS VIEW */}
          {view === "settings" && (
            <Settings settings={settings} onUpdate={setSettings} />
          )}
        </div>
      </main>

      {/* Delete Character Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={!!charToDelete}
        onCancel={() => setCharToDelete(null)}
        onConfirm={() => {
          if (charToDelete) {
            handleDeleteCharacter(charToDelete);
            setCharToDelete(null);
          }
        }}
      />

      {/* Character Profile Modal */}
      <CharacterProfileModal
        character={selectedProfileChar}
        onClose={() => setSelectedProfileChar(null)}
        onStartChat={(char) => {
          playAudioCue("receive");
          setCharacter(char);
          setSelectedProfileChar(null);
          setView("chat");
        }}
      />

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        settings={settings}
        onUpdate={setSettings}
        onClose={() => setIsSettingsModalOpen(false)}
        onAudioCue={playAudioCue}
      />

      {/* Toast Banner */}
      <Toast message={toastMessage} />
    </div>
  );
}
