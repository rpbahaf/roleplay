import { CreateMLCEngine, prebuiltAppConfig } from "@mlc-ai/web-llm";

let activeEngine: any = null;
let activeModelId: string | null = null;

export interface ProgressReport {
  progress: number;
  text: string;
}

export async function getWebLLMEngine(
  modelId: string,
  onProgress?: (report: ProgressReport) => void
): Promise<any> {
  if (activeEngine && activeModelId === modelId) {
    return activeEngine;
  }

  // If there's an existing engine running a different model, we can unload/stop it
  if (activeEngine) {
    try {
      await activeEngine.unload();
    } catch (e) {
      console.warn("Unloading previous engine failed:", e);
    }
    activeEngine = null;
    activeModelId = null;
  }

  console.log(`Initializing WebLLM engine for model: ${modelId}`);
  try {
    const engine = await CreateMLCEngine(modelId, {
      initProgressCallback: (report) => {
        if (onProgress) {
          onProgress({
            progress: report.progress,
            text: report.text,
          });
        }
      },
    });

    activeEngine = engine;
    activeModelId = modelId;
    return engine;
  } catch (firstError: any) {
    console.warn("[WebLLM Init Attempt 1 Failed]:", firstError?.message || firstError);
    console.log("[WebLLM Fallback]: Retrying with disk caching disabled to stream 100% over the internet directly...");
    
    const engine = await CreateMLCEngine(modelId, {
      initProgressCallback: (report) => {
        if (onProgress) {
          onProgress({
            progress: report.progress,
            text: `[Direct Internet Mode] ${report.text}`,
          });
        }
      },
      appConfig: {
        ...prebuiltAppConfig,
        useIndexedDBCache: false,
      } as any
    });

    activeEngine = engine;
    activeModelId = modelId;
    return engine;
  }
}

export async function resetWebLLMChat(): Promise<void> {
  if (activeEngine) {
    try {
      await activeEngine.resetChat();
    } catch (e) {
      console.warn("Failed to reset WebLLM chat state:", e);
    }
  }
}
